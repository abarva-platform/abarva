# Synthetic Build Commands

```bash
node out/enterprise-intake-v2/build-owner-packs-v2-2.mjs
find out/enterprise-intake-v2/workbooks/v2_2_2b-semantic-mapping-pilot -name "*.xlsx" -print0 | xargs -0 -n1 unzip -t
rg -n "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|synthetic source-backed value|example value" out/enterprise-intake-v2/workbooks/v2_2_2b-semantic-mapping-pilot
```

# Synthetic Assumptions And Gaps

- Synthetic rows are not client-attested.
- Unknowns and pending review states are intentional pre-review states.
- D&A uses summary-level workload volumetrics, not row-level report/job/script capture.
- Finance validation is required before Tower value or commercial opportunity claims become approved.
- Interview notes are synthetic examples that demonstrate director-and-above collection design.

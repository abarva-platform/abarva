# How We Did It - Strategy & Operating Model

Package version: V2.2.2b

## Client Execution Model

The client does not need to complete every field or reshape native exports into AbarVa schemas.

1. Send native extracts or documents already available to the source owner.
2. Review the rows AbarVa maps into this workbook.
3. Confirm, correct, reject, or mark Unknown / Not Applicable.
4. Use Known Gaps to explain missing facts instead of inventing values.
5. Do not send vendor-licensed or vendor-confidential materials. Do not attach vendor-licensed or vendor-confidential material: product documentation, screenshots, data dictionaries, schema/configuration exports, or contract clause text. Describe your own operational facts instead. If a field can only be answered from vendor documentation, mark Unknown and explain in Known Gaps.

## What Was Simulated

This synthetic pre-review package simulates a small source-backed payload plus a known-gap payload for each business tab. It proves the workflow without pretending a client has attested to the facts.

## Mapping Pattern

| Table | Native Source Pattern | Mapped Review Grain | Proof State |
|---|---|---|---|
| ES01 Enterprise Identity & Footprint | native owner export for this row grain | one legal entity or major enterprise entity | Source-backed row plus known-gap row |
| ES02 Business Segments & Operating Model | native owner export for this row grain | one line of business, business segment or major service line | Source-backed row plus known-gap row |
| ES03 Strategy & Priorities | native owner export for this row grain | one strategic priority or objective | Source-backed row plus known-gap row |
| ES04 Capabilities & Services | native owner export for this row grain | one material enterprise capability or service | Source-backed row plus known-gap row |
| ES05 Organization Structure | native owner export for this row grain | one organization unit | Source-backed row plus known-gap row |
| ES06 Decision Rights & Governance | native owner export for this row grain | one material decision, authority or governance forum | Source-backed row plus known-gap row |

## Interview Rule

CXO and senior leader interviews capture strategy, investment appetite, enterprise constraints, measurable outcomes and AI meaning. Director-level interviews capture current procedures, tools, team shape, tactical process pain, quality/governance maturity and realistic AI opportunities at the team level.

## What This Supports

Home uses the synthesized executive and current-state context. Source uses vendor, contract, scope and commercial evidence. Tower uses finance, value, KPI and evidence state. Moves uses priorities, programs, owners and constraints. AI solutioning uses use-case readiness, adoption, governance and data-dependency evidence.

# Strategy & Operating Model

Audience: CEO/COO office, strategy, corporate development, business owners

Purpose: Capture enterprise identity, business segments, priorities, capabilities, org and decision rights.

## Workbook Contents

- 00_START_HERE: owner instructions and rules for blanks, unknowns and evidence.
- 01_MY_REVIEW: formula-driven completion/readiness view that counts data rows, not example rows.
- 02_SOURCE_PULL_GUIDE: source owner, exact extract, native key, grain, fields, joins, filters, validation, fallback, and raw-to-mapped examples.
- Business tabs: V2.2.1 review sheets with real illustrative examples outside the load table.
- 98_FIELD_GUIDE: field-level definitions, owners, preferred source, extraction method and downstream use.
- 99_REFERENCE_VALUES: controlled values used by review/status fields.

## Business Tabs

| Code | Tab | Owner | Grain |
|---|---|---|---|
| ES01 | Enterprise Identity & Footprint | Enterprise Strategy / Corporate Development | one legal entity or major enterprise entity |
| ES02 | Business Segments & Operating Model | Enterprise Strategy / Corporate Development | one line of business, business segment or major service line |
| ES03 | Strategy & Priorities | Enterprise Strategy / Corporate Development | one strategic priority or objective |
| ES04 | Capabilities & Services | Enterprise Strategy / Corporate Development | one material enterprise capability or service |
| ES05 | Organization Structure | Enterprise Strategy / Corporate Development | one organization unit |
| ES06 | Decision Rights & Governance | Enterprise Strategy / Corporate Development | one material decision, authority or governance forum |

## Rule

Do not invent missing values. Use blank, Unknown, Not Applicable or Known Gaps when the source does not provide the fact. Do not attach vendor-licensed or vendor-confidential material: product documentation, screenshots, data dictionaries, schema/configuration exports, or contract clause text. Describe your own operational facts instead. If a field can only be answered from vendor documentation, mark Unknown and explain in Known Gaps.

Illustrative examples are marked NOT LOADED and are outside the active data table. They show what good looks like without creating dashboard records.

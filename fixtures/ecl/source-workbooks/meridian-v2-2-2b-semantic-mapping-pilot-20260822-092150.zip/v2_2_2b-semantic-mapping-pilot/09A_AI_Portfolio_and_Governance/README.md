# AI Portfolio, Tools & Governance

Audience: AI office, CDAO, AI governance, model/tool owners

Purpose: Capture AI programs, use cases, tools, models/agents, governance and platform readiness.

## Workbook Contents

- 00_START_HERE: owner instructions and rules for blanks, unknowns and evidence.
- 01_MY_REVIEW: formula-driven completion/readiness view that counts data rows, not example rows.
- 02_SOURCE_PULL_GUIDE: source owner, exact extract, native key, grain, fields, joins, filters, validation, fallback, and raw-to-mapped examples.
- Business tabs: V2.2.1 review sheets with real illustrative examples outside the load table.
- 98_FIELD_GUIDE: field-level definitions, owners, preferred source, extraction method and downstream use.
- 99_REFERENCE_VALUES: controlled values used by review/status fields.

## Business Tabs

| Code | Tab | Owner | Grain |
|---|---|---|---|
| AI01 | AI Portfolio Programs | AI Portfolio / Governance Owner | one AI program/project/investment initiative |
| AI02 | AI Use Cases & Deployments | AI Portfolio / Governance Owner | one AI use case or business deployment |
| AI03 | AI Tools & Embedded Capabilities | AI Portfolio / Governance Owner | one purchased, embedded, custom, candidate or discovered AI capability |
| AI04 | AI Models, Agents & Endpoints | AI Portfolio / Governance Owner | one model, agent, endpoint or governed component |
| AI08 | AI Governance, Risk & Approval | AI Portfolio / Governance Owner | one AI item and governance decision/control state |
| AI09 | AI Platform & MLOps / LLMOps Readiness | AI Portfolio / Governance Owner | one platform capability or maturity dimension |

## Rule

Do not invent missing values. Use blank, Unknown, Not Applicable or Known Gaps when the source does not provide the fact. Do not attach vendor-licensed or vendor-confidential material: product documentation, screenshots, data dictionaries, schema/configuration exports, or contract clause text. Describe your own operational facts instead. If a field can only be answered from vendor documentation, mark Unknown and explain in Known Gaps.

Illustrative examples are marked NOT LOADED and are outside the active data table. They show what good looks like without creating dashboard records.

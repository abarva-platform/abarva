# AI Usage, Investment & Value

Audience: AI operations, finance, value office, platform administrators

Purpose: Capture AI investment attribution, usage/adoption telemetry, benefits and value claims.

## Workbook Contents

- 00_START_HERE: owner instructions and rules for blanks, unknowns and evidence.
- 01_MY_REVIEW: formula-driven completion/readiness view that counts data rows, not example rows.
- 02_SOURCE_PULL_GUIDE: source owner, exact extract, native key, grain, fields, joins, filters, validation, fallback, and raw-to-mapped examples.
- Business tabs: V2.2.1 review sheets with real illustrative examples outside the load table.
- 98_FIELD_GUIDE: field-level definitions, owners, preferred source, extraction method and downstream use.
- 99_REFERENCE_VALUES: controlled values used by review/status fields.

## Business Tabs

| Code | Tab | Owner | Grain |
|---|---|---|---|
| AI05 | AI Investment Attribution | IT Finance + AI Portfolio Owner | one mapping from a Pack 4 financial fact to an AI item |
| AI06 | AI Usage & Adoption | AI Operations / Platform Administrator | AI tool/use case/scope/period |
| AI07 | AI Benefits, Outcomes & Value Claims | Business Value Owner + Finance/Tower Reviewer | one outcome claim for an AI use case and measurement period |

## Rule

Do not invent missing values. Use blank, Unknown, Not Applicable or Known Gaps when the source does not provide the fact. Do not attach vendor-licensed or vendor-confidential material: product documentation, screenshots, data dictionaries, schema/configuration exports, or contract clause text. Describe your own operational facts instead. If a field can only be answered from vendor documentation, mark Unknown and explain in Known Gaps.

Illustrative examples are marked NOT LOADED and are outside the active data table. They show what good looks like without creating dashboard records.

# How We Did It - AI Usage, Investment & Value

Package version: V2.2.2b

## Client Execution Model

The client does not need to complete every field or reshape native exports into AbarVa schemas.

1. Send native extracts or documents already available to the source owner.
2. Review the rows AbarVa maps into this workbook.
3. Confirm, correct, reject, or mark Unknown / Not Applicable.
4. Use Known Gaps to explain missing facts instead of inventing values.
5. Do not send vendor-licensed or vendor-confidential materials. Do not attach vendor-licensed or vendor-confidential material: product documentation, screenshots, data dictionaries, schema/configuration exports, or contract clause text. Describe your own operational facts instead. If a field can only be answered from vendor documentation, mark Unknown and explain in Known Gaps.

## What Was Simulated

This synthetic pre-review package simulates a small source-backed payload plus a known-gap payload for each business tab. It proves the workflow without pretending a client has attested to the facts.

## Mapping Pattern

| Table | Native Source Pattern | Mapped Review Grain | Proof State |
|---|---|---|---|
| AI05 AI Investment Attribution | finance allocation export mapped to AI program/use case/tool | one mapping from a Pack 4 financial fact to an AI item | Source-backed row plus known-gap row |
| AI06 AI Usage & Adoption | normalized AI usage aggregate by tool/use case/scope/period | AI tool/use case/scope/period | Source-backed row plus known-gap row |
| AI07 AI Benefits, Outcomes & Value Claims | AI value claim / benefits proof tracker | one outcome claim for an AI use case and measurement period | Source-backed row plus known-gap row |

## Interview Rule

CXO and senior leader interviews capture strategy, investment appetite, enterprise constraints, measurable outcomes and AI meaning. Director-level interviews capture current procedures, tools, team shape, tactical process pain, quality/governance maturity and realistic AI opportunities at the team level.

## What This Supports

Home uses the synthesized executive and current-state context. Source uses vendor, contract, scope and commercial evidence. Tower uses finance, value, KPI and evidence state. Moves uses priorities, programs, owners and constraints. AI solutioning uses use-case readiness, adoption, governance and data-dependency evidence.

# Data, Analytics, Reporting & Pipeline Volumetrics

Audience: CDAO, BI/reporting leads, data engineering, analytics platform teams

Purpose: Capture data, reporting, analytics and processing volumetrics by function/tool/mart, without collecting every pipeline/report/script row.

## Workbook Contents

- 00_START_HERE: owner instructions and rules for blanks, unknowns and evidence.
- 01_MY_REVIEW: formula-driven completion/readiness view that counts data rows, not example rows.
- 02_SOURCE_PULL_GUIDE: source owner, exact extract, native key, grain, fields, joins, filters, validation, fallback, and raw-to-mapped examples.
- Business tabs: V2.2.1 review sheets with real illustrative examples outside the load table.
- 98_FIELD_GUIDE: field-level definitions, owners, preferred source, extraction method and downstream use.
- 99_REFERENCE_VALUES: controlled values used by review/status fields.

## Business Tabs

| Code | Tab | Owner | Grain |
|---|---|---|---|
| TD01 | Enterprise D&A by Business Function | Data & Analytics Leader | one business function or major sub-function |
| TD05 | Data Platforms, Domains & Products | Technology Owner | one data platform, domain, product, mart, warehouse, lake/lakehouse or governed analytical asset |
| DA01 | Reporting Tool & User Volumes | CDAO, BI/reporting leads, data engineering, analytics platform teams | one business function + reporting technology/tool + period |
| DA02 | ETL ELT Script Volumes | CDAO, BI/reporting leads, data engineering, analytics platform teams | one business function + mart/data product + processing technology + period |
| DA03 | Analytics Workload Volumes | CDAO, BI/reporting leads, data engineering, analytics platform teams | one business function + analytics technology + workload type + period |
| DA04 | Data Quality Governance Readiness | Data Governance Lead + Data Owner | one data domain/product/mart + business function + use-case criticality |
| DA05 | Solutioning Data Dependency Map | AbarVa Solution Lead + Data Owner | one product outcome/use case/workflow + required data dependency |

## Rule

Do not invent missing values. Use blank, Unknown, Not Applicable or Known Gaps when the source does not provide the fact. Do not attach vendor-licensed or vendor-confidential material: product documentation, screenshots, data dictionaries, schema/configuration exports, or contract clause text. Describe your own operational facts instead. If a field can only be answered from vendor documentation, mark Unknown and explain in Known Gaps.

Illustrative examples are marked NOT LOADED and are outside the active data table. They show what good looks like without creating dashboard records.

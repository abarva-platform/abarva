# How We Did It - Commercial Scope, Performance & Value

Package version: V2.2.2b

## Client Execution Model

The client does not need to complete every field or reshape native exports into AbarVa schemas.

1. Send native extracts or documents already available to the source owner.
2. Review the rows AbarVa maps into this workbook.
3. Confirm, correct, reject, or mark Unknown / Not Applicable.
4. Use Known Gaps to explain missing facts instead of inventing values.
5. Do not send vendor-licensed or vendor-confidential materials. Do not attach vendor-licensed or vendor-confidential material: product documentation, screenshots, data dictionaries, schema/configuration exports, or contract clause text. Describe your own operational facts instead. If a field can only be answered from vendor documentation, mark Unknown and explain in Known Gaps.

## What Was Simulated

This synthetic pre-review package simulates a small source-backed payload plus a known-gap payload for each business tab. It proves the workflow without pretending a client has attested to the facts.

## Mapping Pattern

| Table | Native Source Pattern | Mapped Review Grain | Proof State |
|---|---|---|---|
| VC03 Contract Service Lines | native owner export for this row grain | one service tower, line item, product or scope component | Source-backed row plus known-gap row |
| VC04 Application & Service Scope | native owner export for this row grain | one contract-to-application/platform/service relationship | Source-backed row plus known-gap row |
| VC05 Rate Cards & Labor Mix | native owner export for this row grain | one effective role/rate/location line | Source-backed row plus known-gap row |
| VC06 Invoice & Spend Ledger | invoice/AP/PO line export linked to contract/vendor | invoice line, PO line or governed period rollup | Source-backed row plus known-gap row |
| VC07 SLA & Service Performance Ledger | SLA/service performance report export | one SLA/KPI and measurement period | Source-backed row plus known-gap row |
| VC12 Commercial Opportunity & Value Proof | commercial opportunity worksheet derived from contract/invoice/SLA evidence | one commercial value opportunity with evidence and finance-realization state | Source-backed row plus known-gap row |

## Interview Rule

CXO and senior leader interviews capture strategy, investment appetite, enterprise constraints, measurable outcomes and AI meaning. Director-level interviews capture current procedures, tools, team shape, tactical process pain, quality/governance maturity and realistic AI opportunities at the team level.

## What This Supports

Home uses the synthesized executive and current-state context. Source uses vendor, contract, scope and commercial evidence. Tower uses finance, value, KPI and evidence state. Moves uses priorities, programs, owners and constraints. AI solutioning uses use-case readiness, adoption, governance and data-dependency evidence.

# Commercial Scope, Performance & Value

Audience: Procurement, AP, finance reviewers, service owners

Purpose: Capture contract service scope, app scope, rate cards, spend mapping, SLA performance and commercial opportunities.

## Workbook Contents

- 00_START_HERE: owner instructions and rules for blanks, unknowns and evidence.
- 01_MY_REVIEW: formula-driven completion/readiness view that counts data rows, not example rows.
- 02_SOURCE_PULL_GUIDE: source owner, exact extract, native key, grain, fields, joins, filters, validation, fallback, and raw-to-mapped examples.
- Business tabs: V2.2.1 review sheets with real illustrative examples outside the load table.
- 98_FIELD_GUIDE: field-level definitions, owners, preferred source, extraction method and downstream use.
- 99_REFERENCE_VALUES: controlled values used by review/status fields.

## Business Tabs

| Code | Tab | Owner | Grain |
|---|---|---|---|
| VC03 | Contract Service Lines | Vendor Management / Procurement / Legal | one service tower, line item, product or scope component |
| VC04 | Application & Service Scope | Vendor Management / Procurement / Legal | one contract-to-application/platform/service relationship |
| VC05 | Rate Cards & Labor Mix | Vendor Management / Procurement / Legal | one effective role/rate/location line |
| VC06 | Invoice & Spend Ledger | Accounts Payable / IT Finance | invoice line, PO line or governed period rollup |
| VC07 | SLA & Service Performance Ledger | Service Owner / Vendor Manager | one SLA/KPI and measurement period |
| VC12 | Commercial Opportunity & Value Proof | Sourcing Owner + Finance/Tower Reviewer | one commercial value opportunity with evidence and finance-realization state |

## Rule

Do not invent missing values. Use blank, Unknown, Not Applicable or Known Gaps when the source does not provide the fact. Do not attach vendor-licensed or vendor-confidential material: product documentation, screenshots, data dictionaries, schema/configuration exports, or contract clause text. Describe your own operational facts instead. If a field can only be answered from vendor documentation, mark Unknown and explain in Known Gaps.

Illustrative examples are marked NOT LOADED and are outside the active data table. They show what good looks like without creating dashboard records.

# How We Did It - Engagement Control, Discovery & Interviews

Package version: V2.2.2b

## Client Execution Model

The client does not need to complete every field or reshape native exports into AbarVa schemas.

1. Send native extracts or documents already available to the source owner.
2. Review the rows AbarVa maps into this workbook.
3. Confirm, correct, reject, or mark Unknown / Not Applicable.
4. Use Known Gaps to explain missing facts instead of inventing values.
5. Do not send vendor-licensed or vendor-confidential materials. Do not attach vendor-licensed or vendor-confidential material: product documentation, screenshots, data dictionaries, schema/configuration exports, or contract clause text. Describe your own operational facts instead. If a field can only be answered from vendor documentation, mark Unknown and explain in Known Gaps.

## What Was Simulated

This synthetic pre-review package simulates a small source-backed payload plus a known-gap payload for each business tab. It proves the workflow without pretending a client has attested to the facts.

## Mapping Pattern

| Table | Native Source Pattern | Mapped Review Grain | Proof State |
|---|---|---|---|
| EC01 Workstreams & Owners | native owner export for this row grain | one row per workbook/table/review unit | Source-backed row plus known-gap row |
| EC02 Source Requests & Uploads | native owner export for this row grain | one row per requested or received source | Source-backed row plus known-gap row |
| EC03 Interviews & Workshops | native owner export for this row grain | one row per stakeholder session | Source-backed row plus known-gap row |
| EC04 Questions, Conflicts & Exceptions | native owner export for this row grain | one row per unresolved issue | Source-backed row plus known-gap row |
| EC05 Review & Attestation | native owner export for this row grain | one row per material review scope | Source-backed row plus known-gap row |
| EC06 Coverage & Readiness | native owner export for this row grain | one row per workbook/table/domain | Source-backed row plus known-gap row |
| IN01 Interview Roster Director and Above | native owner export for this row grain | one planned or completed interview participant | Source-backed row plus known-gap row |
| IN02 Strategic Leadership Interview Notes | native owner export for this row grain | one strategic question-and-answer theme from CXO or senior leader interview | Source-backed row plus known-gap row |
| IN03 Director Operating Interview Notes | native owner export for this row grain | one tactical current-state operating observation from director-level interview | Source-backed row plus known-gap row |
| IN04 Interview Theme and Evidence Synthesis | native owner export for this row grain | one synthesized theme linked to interview evidence and downstream use | Source-backed row plus known-gap row |

## Interview Rule

CXO and senior leader interviews capture strategy, investment appetite, enterprise constraints, measurable outcomes and AI meaning. Director-level interviews capture current procedures, tools, team shape, tactical process pain, quality/governance maturity and realistic AI opportunities at the team level.

## What This Supports

Home uses the synthesized executive and current-state context. Source uses vendor, contract, scope and commercial evidence. Tower uses finance, value, KPI and evidence state. Moves uses priorities, programs, owners and constraints. AI solutioning uses use-case readiness, adoption, governance and data-dependency evidence.

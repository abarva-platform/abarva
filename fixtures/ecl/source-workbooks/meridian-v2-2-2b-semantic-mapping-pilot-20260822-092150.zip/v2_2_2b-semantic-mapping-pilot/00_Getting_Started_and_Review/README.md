# Engagement Control, Discovery & Interviews

Audience: Client PMO, AbarVa engagement lead, workstream owners

Purpose: Run the intake: source requests, receipt, facilitated interviews, questions, review, attestation and readiness.

## Workbook Contents

- 00_START_HERE: owner instructions and rules for blanks, unknowns and evidence.
- 01_MY_REVIEW: formula-driven completion/readiness view that counts data rows, not example rows.
- 02_SOURCE_PULL_GUIDE: source owner, exact extract, native key, grain, fields, joins, filters, validation, fallback, and raw-to-mapped examples.
- Business tabs: V2.2.1 review sheets with real illustrative examples outside the load table.
- 98_FIELD_GUIDE: field-level definitions, owners, preferred source, extraction method and downstream use.
- 99_REFERENCE_VALUES: controlled values used by review/status fields.

## Business Tabs

| Code | Tab | Owner | Grain |
|---|---|---|---|
| EC01 | Workstreams & Owners | Engagement Lead / Client PMO | one row per workbook/table/review unit |
| EC02 | Source Requests & Uploads | Engagement Lead / Client PMO | one row per requested or received source |
| EC03 | Interviews & Workshops | Engagement Lead / Client PMO | one row per stakeholder session |
| EC04 | Questions, Conflicts & Exceptions | Engagement Lead / Client PMO | one row per unresolved issue |
| EC05 | Review & Attestation | Engagement Lead / Client PMO | one row per material review scope |
| EC06 | Coverage & Readiness | Engagement Lead / Client PMO | one row per workbook/table/domain |
| IN01 | Interview Roster Director and Above | Client PMO, AbarVa engagement lead, workstream owners | one planned or completed interview participant |
| IN02 | Strategic Leadership Interview Notes | Client PMO, AbarVa engagement lead, workstream owners | one strategic question-and-answer theme from CXO or senior leader interview |
| IN03 | Director Operating Interview Notes | Client PMO, AbarVa engagement lead, workstream owners | one tactical current-state operating observation from director-level interview |
| IN04 | Interview Theme and Evidence Synthesis | Client PMO, AbarVa engagement lead, workstream owners | one synthesized theme linked to interview evidence and downstream use |

## Rule

Do not invent missing values. Use blank, Unknown, Not Applicable or Known Gaps when the source does not provide the fact. Do not attach vendor-licensed or vendor-confidential material: product documentation, screenshots, data dictionaries, schema/configuration exports, or contract clause text. Describe your own operational facts instead. If a field can only be answered from vendor documentation, mark Unknown and explain in Known Gaps.

Illustrative examples are marked NOT LOADED and are outside the active data table. They show what good looks like without creating dashboard records.

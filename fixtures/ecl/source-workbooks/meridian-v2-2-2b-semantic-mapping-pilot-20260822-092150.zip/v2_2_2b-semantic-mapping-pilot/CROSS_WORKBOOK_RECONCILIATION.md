# Cross-Workbook Reconciliation

Package version: V2.2.2b

- Application/vendor pairings are sourced from SP03 CMDB rows.
- AI spend rows trace to SP06 finance and SP11 usage telemetry.
- D&A summary rows trace to SP04 reporting/ETL/analytics volumes.
- Infrastructure rows include Teradata, mainframe, VMware/private cloud, SQL Server, Azure and M365 platform records.
- No dense population has been attempted; this is a semantic mapping pilot.

Traceability rows: 2749
Golden assertions: 25/25 PASS
Enterprise model SHA-256: 2f87a026cc3c4cfe7ac01fd8114210806958960e2263872d8c2cf4fd5bbac452

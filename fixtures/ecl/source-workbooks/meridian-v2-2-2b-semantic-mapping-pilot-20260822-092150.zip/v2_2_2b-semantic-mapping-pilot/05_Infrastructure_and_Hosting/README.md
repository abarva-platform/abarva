# Infrastructure, Platforms & Hosting

Audience: Infrastructure, cloud, mainframe, Teradata, database and platform owners

Purpose: Capture hosting estates including data centers, mainframe, Teradata, VMware/private cloud, database platforms and public cloud.

## Workbook Contents

- 00_START_HERE: owner instructions and rules for blanks, unknowns and evidence.
- 01_MY_REVIEW: formula-driven completion/readiness view that counts data rows, not example rows.
- 02_SOURCE_PULL_GUIDE: source owner, exact extract, native key, grain, fields, joins, filters, validation, fallback, and raw-to-mapped examples.
- Business tabs: V2.2.1 review sheets with real illustrative examples outside the load table.
- 98_FIELD_GUIDE: field-level definitions, owners, preferred source, extraction method and downstream use.
- 99_REFERENCE_VALUES: controlled values used by review/status fields.

## Business Tabs

| Code | Tab | Owner | Grain |
|---|---|---|---|
| TD07 | Infrastructure & Hosting | Infrastructure / Cloud / Mainframe Owner | one major hosting estate or infrastructure platform |

## Rule

Do not invent missing values. Use blank, Unknown, Not Applicable or Known Gaps when the source does not provide the fact. Do not attach vendor-licensed or vendor-confidential material: product documentation, screenshots, data dictionaries, schema/configuration exports, or contract clause text. Describe your own operational facts instead. If a field can only be answered from vendor documentation, mark Unknown and explain in Known Gaps.

Illustrative examples are marked NOT LOADED and are outside the active data table. They show what good looks like without creating dashboard records.

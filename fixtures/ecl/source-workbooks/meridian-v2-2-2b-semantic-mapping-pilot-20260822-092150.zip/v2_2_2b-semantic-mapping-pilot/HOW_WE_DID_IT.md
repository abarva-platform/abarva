# V2.2.2b Synthetic Pre-Review Package

This package proves the future intake path without asking a client to fill perfect templates.

## Operating Principle

Clients send native extracts, documents and interview evidence. AbarVa maps what is available, preserves gaps, and asks owners to confirm, correct or reject the mapped review rows.

## Proof Chain

Synthetic enterprise truth creates native-style sample extracts in `__synthetic_sources__`. The V2.2.1 mapping rules project those extracts into the 14 client review folders. Traceability is recorded in `SOURCE_TO_REVIEW_PACK_TRACEABILITY.csv`, and cross-domain test stories are recorded in `SYNTHETIC_SCENARIO_REGISTRY.csv`.

## Client Simplicity

The client-facing workflow remains: send what you have, review what was mapped, mark unknowns explicitly. Complete enterprise data is not assumed.

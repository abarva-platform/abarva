# Vendor & Contract Core

Audience: Vendor management, legal, contract operations

Purpose: Capture vendor identity, contract identity, amendments, terms, renewals and contract evidence.

## Workbook Contents

- 00_START_HERE: owner instructions and rules for blanks, unknowns and evidence.
- 01_MY_REVIEW: formula-driven completion/readiness view that counts data rows, not example rows.
- 02_SOURCE_PULL_GUIDE: source owner, exact extract, native key, grain, fields, joins, filters, validation, fallback, and raw-to-mapped examples.
- Business tabs: V2.2.1 review sheets with real illustrative examples outside the load table.
- 98_FIELD_GUIDE: field-level definitions, owners, preferred source, extraction method and downstream use.
- 99_REFERENCE_VALUES: controlled values used by review/status fields.

## Business Tabs

| Code | Tab | Owner | Grain |
|---|---|---|---|
| VC01 | Vendor Master | Vendor Management / Procurement / Legal | one vendor/supplier |
| VC02 | Contract Master | Vendor Management / Procurement / Legal | one governing agreement |
| VC08 | Change Order Ledger | Vendor Management / Procurement / Legal | one change order, amendment or scope-change event |
| VC09 | Obligations & Key Terms | Vendor Management / Procurement / Legal | one obligation, right, clause or material term |
| VC10 | Renewal & Sourcing Events | Vendor Management / Procurement / Legal | one renewal, sourcing, proposal, evaluation, BAFO or commercial event |
| VC11 | Contract Evidence Register | Vendor Management / Procurement / Legal | one contract artifact or source extract |

## Rule

Do not invent missing values. Use blank, Unknown, Not Applicable or Known Gaps when the source does not provide the fact. Do not attach vendor-licensed or vendor-confidential material: product documentation, screenshots, data dictionaries, schema/configuration exports, or contract clause text. Describe your own operational facts instead. If a field can only be answered from vendor documentation, mark Unknown and explain in Known Gaps.

Illustrative examples are marked NOT LOADED and are outside the active data table. They show what good looks like without creating dashboard records.

# How We Did It - Vendor & Contract Core

Package version: V2.2.2b

## Client Execution Model

The client does not need to complete every field or reshape native exports into AbarVa schemas.

1. Send native extracts or documents already available to the source owner.
2. Review the rows AbarVa maps into this workbook.
3. Confirm, correct, reject, or mark Unknown / Not Applicable.
4. Use Known Gaps to explain missing facts instead of inventing values.
5. Do not send vendor-licensed or vendor-confidential materials. Do not attach vendor-licensed or vendor-confidential material: product documentation, screenshots, data dictionaries, schema/configuration exports, or contract clause text. Describe your own operational facts instead. If a field can only be answered from vendor documentation, mark Unknown and explain in Known Gaps.

## What Was Simulated

This synthetic pre-review package simulates a small source-backed payload plus a known-gap payload for each business tab. It proves the workflow without pretending a client has attested to the facts.

## Mapping Pattern

| Table | Native Source Pattern | Mapped Review Grain | Proof State |
|---|---|---|---|
| VC01 Vendor Master | vendor master | one vendor/supplier | Source-backed row plus known-gap row |
| VC02 Contract Master | contract register / CLM agreement export | one governing agreement | Source-backed row plus known-gap row |
| VC08 Change Order Ledger | native owner export for this row grain | one change order, amendment or scope-change event | Source-backed row plus known-gap row |
| VC09 Obligations & Key Terms | native owner export for this row grain | one obligation, right, clause or material term | Source-backed row plus known-gap row |
| VC10 Renewal & Sourcing Events | native owner export for this row grain | one renewal, sourcing, proposal, evaluation, BAFO or commercial event | Source-backed row plus known-gap row |
| VC11 Contract Evidence Register | contract document register plus owner-approved term extraction output; no clause text | one contract artifact or source extract | Source-backed row plus known-gap row |

## Interview Rule

CXO and senior leader interviews capture strategy, investment appetite, enterprise constraints, measurable outcomes and AI meaning. Director-level interviews capture current procedures, tools, team shape, tactical process pain, quality/governance maturity and realistic AI opportunities at the team level.

## What This Supports

Home uses the synthesized executive and current-state context. Source uses vendor, contract, scope and commercial evidence. Tower uses finance, value, KPI and evidence state. Moves uses priorities, programs, owners and constraints. AI solutioning uses use-case readiness, adoption, governance and data-dependency evidence.

# Validation Report

Status: **pass**

- FY2027 budget: $2,350,000,000
- FY2026 prior-year actuals: $2,180,000,000
- Contract annual value: $1,480,500,000 (63.0% of FY2027 budget)
- Contract-backed FY2027 spend: $1,480,500,000
- Internal/noncontracted FY2027 spend: $869,500,000
- Interview statements: 1314 (minimum per interview: 20)
- Vendor contracts: 119
- Risk/control rows: 80
- Relationship hints: 42
- Clean raw CSV tables: 28
- Clean raw CSV rows: 9656

## Mention Distribution

- initiative: 40.0%
- application: 25.0%
- platform: 15.0%
- vendor: 20.0%
- kpi: 15.0%

## Issues
- No unexplained failures.
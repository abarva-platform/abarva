# Validation Replay

This package includes a standalone replay validator for offline verification after unzip.

## Commands

```bash
python3 scripts/validate_package.py .
python3 scripts/load_workbooks_to_postgres.py --csv-root csv --dry-run
```

The first command checks validation status, required CSV row counts, exact budget totals, OpEx/CapEx totals, Run/Grow/Transform totals, and workbook readability/doc-sheet placement.

The second command verifies the generic PostgreSQL loader plan without requiring DATABASE_URL or psycopg.

## Expected Result

- `validate_package.py`: status `pass`, 25 checked CSV files, 3 checked workbooks.
- `load_workbooks_to_postgres.py --dry-run`: one dry-run table line per CSV mirror.

## Boundary

Replay validation is package-local. It does not perform PostgreSQL writes, canonical transformation, publication, deployment, or signed-in product proof.

## v3 Checks

The replay validator checks 28 clean CSV mirrors, FY2026/FY2027 budget separation, 60-65% contract-backed spend coverage, control/date consistency, sparse mention distributions, funding/conviction inversion cohorts, messy value mappings, workbook INTAKE_GUIDE sheets, and the client sign-off gate.

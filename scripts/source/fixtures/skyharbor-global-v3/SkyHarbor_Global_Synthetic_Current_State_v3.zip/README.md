# SkyHarbor Global Synthetic Current-State Package v3

This package is a fully synthetic, deterministic current-state assessment dataset with v3 correction additions for a fictional global airline.

- Company: SkyHarbor Global Airlines Group
- Assessment date: 2027-06-30
- Random seed: 20260802
- Reporting currency: USD
- Enterprise IT budget: $2,350,000,000

The workbooks are not mandatory client-submission templates. They are a realistic target-state representation, test corpus, and benchmark for Abarva Intelligence, Moves, Source, Tower, Knowledge Explorer, contextual reasoning, 1:1 PostgreSQL worksheet loading, and simple serving-view reconciliation.

Real technology and vendor product names appear only to make the synthetic estate credible. No real airline organization, executives, confidential facts, contract terms, or operating data were copied.

## v3 Correction Additions

- Every CXO/executive interview has at least 20 statement-level questions; IT/technology interviews include deeper coverage with no fixed cap.
- Application and data-platform sheets include practical technical-depth fields such as version, hosting/deployment detail, users, transaction/job volume, storage, capacity, integrations, support model, and evidence source.
- Mention fields are sparse and conviction-driven rather than 100% populated.
- Contract annual value is a contract-backed subset of FY2027 spend, not total IT budget.
- Controls use explicit `never_tested` state when no test date exists.
- `INTAKE_GUIDE` worksheets describe interview-led and document-led collection plus client sign-off before raw loading.
- `scripts/load_workbooks_to_postgres.py` lands 28 clean CSVs 1:1 as text with lineage and source-row JSON.

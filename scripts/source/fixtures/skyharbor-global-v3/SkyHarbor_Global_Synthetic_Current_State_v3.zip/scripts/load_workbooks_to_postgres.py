#!/usr/bin/env python3
"""1:1 raw CSV loader for the SkyHarbor synthetic package.

The loader intentionally lands every source field as text, adds only technical
lineage, and performs no business normalization before loading.
"""
import argparse
import csv
import hashlib
import json
import os
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path

SCHEMA_BY_FOLDER = {
    "enterprise_it": "raw_enterprise_it",
    "data_analytics": "raw_data_analytics",
    "cloud_hybrid": "raw_cloud_hybrid",
}

TECHNICAL_COLUMNS = [
    "_source_file",
    "_source_sheet",
    "_source_row_number",
    "_source_row_jsonb",
    "_load_run_id",
    "_loaded_at",
    "_row_hash",
    "_synthetic_data_flag",
]

def snake(name):
    return re.sub(r"_+", "_", re.sub(r"[^A-Za-z0-9]+", "_", str(name).replace("*", "")).strip("_").lower()) or "column"

def table_name(path):
    return re.sub(r"^\d+[a-z]?_", "", snake(path.stem))

def normalized_headers(headers):
    seen = {}
    out = []
    for idx, header in enumerate(headers, 1):
        base = snake(header or f"blank_header_{idx}")
        seen[base] = seen.get(base, 0) + 1
        out.append(base if seen[base] == 1 else f"{base}_{seen[base]}")
    return out

def row_hash(row, headers):
    payload = json.dumps({h: row.get(h, "") for h in headers}, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()

def discover(csv_root, include_messy=False):
    root = Path(csv_root)
    plan = []
    for folder, schema in SCHEMA_BY_FOLDER.items():
        for path in sorted((root / folder).glob("*.csv")):
            with path.open(newline="", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                rows = list(reader)
                headers = reader.fieldnames or []
            plan.append({"schema": schema, "table": table_name(path), "path": path, "headers": headers, "columns": normalized_headers(headers), "rows": rows})
    if include_messy:
        messy_root = root.parent / "csv_messy" if root.name == "csv" else Path("csv_messy")
        for path in sorted(messy_root.glob("*.csv")):
            if path.name in {"EXPECTED_MAPPING.json"}:
                continue
            with path.open(newline="", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                rows = list(reader)
                headers = reader.fieldnames or []
            plan.append({"schema": "raw_mapping_test", "table": table_name(path), "path": path, "headers": headers, "columns": normalized_headers(headers), "rows": rows})
    return plan

def ddl_ident(name):
    return '"' + name.replace('"', '""') + '"'

def load_plan(conn, plan, load_run_id):
    with conn.cursor() as cur:
        for item in plan:
            schema = item["schema"]
            table = item["table"]
            cur.execute(f"CREATE SCHEMA IF NOT EXISTS {ddl_ident(schema)}")
            cur.execute(f"""
                CREATE TABLE IF NOT EXISTS {ddl_ident(schema)}._column_map (
                    _load_run_id uuid,
                    _source_file text,
                    _source_sheet text,
                    ordinal integer,
                    original_header text,
                    snake_name text,
                    required_flag boolean
                )
            """)
            source_defs = ", ".join(f"{ddl_ident(col)} text" for col in item["columns"])
            lineage_defs = ", ".join([
                '"_source_file" text',
                '"_source_sheet" text',
                '"_source_row_number" bigint',
                '"_source_row_jsonb" jsonb',
                '"_load_run_id" uuid',
                '"_loaded_at" timestamptz',
                '"_row_hash" text',
                '"_synthetic_data_flag" boolean',
            ])
            cur.execute(f"CREATE TABLE IF NOT EXISTS {ddl_ident(schema)}.{ddl_ident(table)} ({source_defs}, {lineage_defs})")
            cur.execute(f"DELETE FROM {ddl_ident(schema)}.{ddl_ident(table)} WHERE _load_run_id = %s", (load_run_id,))
            cur.execute(f"DELETE FROM {ddl_ident(schema)}._column_map WHERE _load_run_id = %s AND _source_file = %s", (load_run_id, str(item["path"])))
            for ordinal, (original, normalized) in enumerate(zip(item["headers"], item["columns"]), 1):
                cur.execute(
                    f"INSERT INTO {ddl_ident(schema)}._column_map (_load_run_id, _source_file, _source_sheet, ordinal, original_header, snake_name, required_flag) VALUES (%s,%s,%s,%s,%s,%s,%s)",
                    (load_run_id, str(item["path"]), item["path"].stem, ordinal, original, normalized, "*" in original),
                )
            names = item["columns"] + TECHNICAL_COLUMNS
            placeholders = ", ".join(["%s"] * len(names))
            insert_sql = f"INSERT INTO {ddl_ident(schema)}.{ddl_ident(table)} ({', '.join(ddl_ident(n) for n in names)}) VALUES ({placeholders})"
            loaded_at = datetime.now(timezone.utc)
            for source_row_number, row in enumerate(item["rows"], 2):
                raw_json = {h: row.get(h, "") for h in item["headers"]}
                values = [row.get(h, "") for h in item["headers"]] + [
                    str(item["path"]),
                    item["path"].stem,
                    source_row_number,
                    json.dumps(raw_json, ensure_ascii=False),
                    load_run_id,
                    loaded_at,
                    row_hash(row, item["headers"]),
                    True,
                ]
                cur.execute(insert_sql, values)
            for idx_col in ["_load_run_id", "_source_file", "_source_sheet", "_source_row_number", "_row_hash"]:
                cur.execute(f"CREATE INDEX IF NOT EXISTS {ddl_ident(table + '_' + idx_col.strip('_') + '_idx')} ON {ddl_ident(schema)}.{ddl_ident(table)} ({ddl_ident(idx_col)})")
            for col in item["columns"]:
                if col.endswith("_id") or col.endswith("_ref") or "period" in col or "date" in col:
                    cur.execute(f"CREATE INDEX IF NOT EXISTS {ddl_ident(table + '_' + col + '_idx')} ON {ddl_ident(schema)}.{ddl_ident(table)} ({ddl_ident(col)})")
            cur.execute(f"CREATE OR REPLACE VIEW {ddl_ident(schema)}.{ddl_ident('current_' + table)} AS SELECT * FROM {ddl_ident(schema)}.{ddl_ident(table)} WHERE _loaded_at = (SELECT MAX(_loaded_at) FROM {ddl_ident(schema)}.{ddl_ident(table)})")
    conn.commit()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv-root", default="csv")
    ap.add_argument("--database-url", default=os.environ.get("DATABASE_URL"))
    ap.add_argument("--load-run-id", default=str(uuid.uuid4()))
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--include-messy", action="store_true")
    args = ap.parse_args()
    plan = discover(args.csv_root, include_messy=args.include_messy)
    total_rows = sum(len(item["rows"]) for item in plan)
    if args.dry_run:
        for item in plan:
            print(f"DRY RUN {item['schema']}.{item['table']}: {len(item['rows'])} rows from {item['path']} ({len(item['headers'])} source columns as text)")
        print(f"DRY RUN summary: {len(plan)} tables, {total_rows} rows, load_run_id={args.load_run_id}")
        return
    if not args.database_url:
        raise SystemExit("DATABASE_URL or --database-url is required unless --dry-run is used")
    import psycopg
    with psycopg.connect(args.database_url) as conn:
        load_plan(conn, plan, args.load_run_id)
    print(f"Loaded {len(plan)} raw tables and {total_rows} rows with load_run_id={args.load_run_id}")

if __name__ == "__main__":
    main()

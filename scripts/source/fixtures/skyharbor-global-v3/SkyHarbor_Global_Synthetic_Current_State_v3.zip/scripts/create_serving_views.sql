-- SkyHarbor Global synthetic serving views
-- These examples keep exact reporting deterministic and compact. Claude should reason over these governed results, not calculate financial totals from narrative text.

CREATE SCHEMA IF NOT EXISTS serving_skyharbor;

-- Row grain: one IT portfolio and budget owner. Measures: budget, forecast, actual. Dimensions: portfolio, owner.
CREATE OR REPLACE VIEW serving_skyharbor.it_budget_by_portfolio_owner AS
SELECT it_portfolio, budget_owner, currency, SUM(budget_amount)::numeric AS budget_amount, SUM(forecast_amount)::numeric AS forecast_amount, SUM(actual_amount)::numeric AS actual_amount
FROM raw_enterprise_it."5_it_budget_allocations"
GROUP BY it_portfolio, budget_owner, currency;

-- Row grain: accounting treatment. Reconciliation rule: sum equals enterprise budget.
CREATE OR REPLACE VIEW serving_skyharbor.opex_capex_distribution AS
SELECT accounting_treatment, SUM(budget_amount)::numeric AS budget_amount
FROM raw_enterprise_it."5_it_budget_allocations"
GROUP BY accounting_treatment;

-- Row grain: investment purpose. Reconciliation rule: sum equals enterprise budget.
CREATE OR REPLACE VIEW serving_skyharbor.run_grow_transform_distribution AS
SELECT investment_purpose, SUM(budget_amount)::numeric AS budget_amount
FROM raw_enterprise_it."5_it_budget_allocations"
GROUP BY investment_purpose;

-- Row grain: project. Measures: approved, opex, capex, forecast, actual, variance.
CREATE OR REPLACE VIEW serving_skyharbor.project_investment_variance AS
SELECT initiative_project_name, status, funding_status, approved_budget, opex_budget, capex_budget, forecast_at_completion, actual_to_date, (forecast_at_completion - approved_budget) AS forecast_variance
FROM raw_enterprise_it."6_projects_investments";

-- Row grain: function/criticality/domain/lifecycle/hosting. Measure: application count.
CREATE OR REPLACE VIEW serving_skyharbor.applications_by_function_criticality_domain_lifecycle_hosting AS
SELECT primary_business_function, business_criticality, application_domain, lifecycle_status, hosting_model, COUNT(*) AS application_count
FROM raw_enterprise_it."4_applications_portfolio"
GROUP BY primary_business_function, business_criticality, application_domain, lifecycle_status, hosting_model;

-- Row grain: distribution basis/environment/domain. Measures: quantity and percent.
CREATE OR REPLACE VIEW serving_skyharbor.workload_distribution AS
SELECT snapshot_period, distribution_basis, application_technology_domain, hosting_environment, SUM(quantity)::numeric AS quantity, SUM(distribution_percent)::numeric AS distribution_percent
FROM raw_cloud_hybrid."4_workload_distribution"
GROUP BY snapshot_period, distribution_basis, application_technology_domain, hosting_environment;

-- Row grain: provider and business portfolio. Measures: budget, spend, forecast, incidents.
CREATE OR REPLACE VIEW serving_skyharbor.cloud_spend_by_provider_function AS
SELECT estate_provider, business_it_portfolio, SUM(budget)::numeric AS budget, SUM(actual_spend)::numeric AS actual_spend, SUM(forecast)::numeric AS forecast, SUM(sev1_sev2_incidents)::numeric AS sev1_sev2_incidents
FROM raw_cloud_hybrid."6_cloud_operations_economics"
GROUP BY estate_provider, business_it_portfolio;

-- Row grain: function/domain. Measures: source systems, jobs, incidents, reports, users.
CREATE OR REPLACE VIEW serving_skyharbor.data_analytics_workload_volumetrics AS
SELECT business_function, major_estate_domain, SUM(approx_source_systems)::numeric AS source_systems, SUM(approx_active_etl_elt_jobs)::numeric AS active_jobs, AVG(job_success_rate)::numeric AS avg_job_success_rate, SUM(approx_monthly_incidents)::numeric AS monthly_incidents
FROM raw_data_analytics."5_function_volumetrics"
GROUP BY business_function, major_estate_domain;

-- Row grain: KPI. Measures: current, prior, target.
CREATE OR REPLACE VIEW serving_skyharbor.kpi_current_vs_target AS
SELECT kpi_name, business_function, kpi_type, unit, direction, current_value, prior_value, target_value, reporting_period, confidence
FROM raw_enterprise_it."7_kpis_outcomes";

-- Row grain: reporting period/tool/function. Measures: seats, active users, rate, cost, activity.
CREATE OR REPLACE VIEW serving_skyharbor.ai_adoption AS
SELECT reporting_period, tool_agent_product, vendor_provider, business_function, seats_purchased, seats_assigned, active_users, active_rate, estimated_use_cost, primary_activity_count, policy_governance_status, confidence
FROM raw_enterprise_it."10_ai_adoption_usage";

-- Row grain: provider/period. Measures: incidents, change failure, backup success, vulnerabilities.
CREATE OR REPLACE VIEW serving_skyharbor.incidents_and_service_health AS
SELECT reporting_period, estate_provider, SUM(sev1_sev2_incidents)::numeric AS sev1_sev2_incidents, AVG(change_failure_rate)::numeric AS avg_change_failure_rate, AVG(backup_success_rate)::numeric AS avg_backup_success_rate, SUM(critical_vulnerability_exposure)::numeric AS critical_vulnerability_exposure
FROM raw_cloud_hybrid."6_cloud_operations_economics"
GROUP BY reporting_period, estate_provider;


-- V3 extension. Row grain: vendor contract. Measures: annual and committed value.
CREATE OR REPLACE VIEW serving_skyharbor.vendor_contract_exposure AS
SELECT vendor_id, vendor_name, category, renewal_decision_state, auto_renew, benchmarking_clause,
       SUM(annual_value)::numeric AS annual_value,
       SUM(total_committed_value)::numeric AS total_committed_value,
       MIN(end_date) AS nearest_end_date
FROM raw_enterprise_it."vendors_contracts"
GROUP BY vendor_id, vendor_name, category, renewal_decision_state, auto_renew, benchmarking_clause;

-- V3 extension. Row grain: risk domain/control status. Measures: count and never-tested controls.
CREATE OR REPLACE VIEW serving_skyharbor.risk_control_coverage AS
SELECT risk_domain, control_status, residual_severity,
       COUNT(*) AS risk_count,
       SUM(CASE WHEN control_last_tested_date IS NULL THEN 1 ELSE 0 END) AS never_tested_controls
FROM raw_enterprise_it."risks_controls"
GROUP BY risk_domain, control_status, residual_severity;

-- V3 extension. Row grain: KPI/quarter. Measures: current, prior, target.
CREATE OR REPLACE VIEW serving_skyharbor.kpi_trend_by_quarter AS
SELECT kpi_id, kpi_name, business_function, reporting_period, unit, direction,
       current_value, prior_value, target_value, confidence
FROM raw_enterprise_it."kpis_outcomes";

-- V3 extension. Row grain: fiscal year/scenario/portfolio. Measures: budget, forecast, actual.
CREATE OR REPLACE VIEW serving_skyharbor.budget_year_over_year AS
SELECT fiscal_year, scenario, it_portfolio,
       SUM(budget_amount)::numeric AS budget_amount,
       SUM(forecast_amount)::numeric AS forecast_amount,
       SUM(actual_amount)::numeric AS actual_amount
FROM raw_enterprise_it."it_budget_allocations"
GROUP BY fiscal_year, scenario, it_portfolio;

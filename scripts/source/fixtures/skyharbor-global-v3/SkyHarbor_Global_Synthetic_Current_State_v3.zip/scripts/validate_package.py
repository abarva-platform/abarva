#!/usr/bin/env python3
import csv, json, re, zipfile
from collections import Counter
from pathlib import Path
from openpyxl import load_workbook

EXPECTED = {
  "csv/enterprise_it/1_enterprise_context.csv": 1,
  "csv/enterprise_it/2_business_functions.csv": 49,
  "csv/enterprise_it/3_it_portfolios_organization.csv": 22,
  "csv/enterprise_it/4_applications_portfolio.csv": 720,
  "csv/enterprise_it/5_it_budget_allocations.csv": 3600,
  "csv/enterprise_it/6_projects_investments.csv": 150,
  "csv/enterprise_it/7_kpis_outcomes.csv": 960,
  "csv/enterprise_it/8_cxo_function_interviews.csv": 48,
  "csv/enterprise_it/8b_interview_statements.csv": 1314,
  "csv/enterprise_it/9_operational_usage_feeds.csv": 19,
  "csv/enterprise_it/10_ai_adoption_usage.csv": 480,
  "csv/enterprise_it/11_vendors_contracts.csv": 119,
  "csv/enterprise_it/12_risks_controls.csv": 80,
  "csv/data_analytics/1_function_analytics_profile.csv": 42,
  "csv/data_analytics/2_platform_tech_stack.csv": 45,
  "csv/data_analytics/3_function_platform_map.csv": 240,
  "csv/data_analytics/4_source_to_consumption.csv": 72,
  "csv/data_analytics/5_function_volumetrics.csv": 84,
  "csv/data_analytics/6_findings_maturity.csv": 336,
  "csv/data_analytics/7_initiatives_roadmap.csv": 55,
  "csv/cloud_hybrid/1_cloud_strategy_placement.csv": 16,
  "csv/cloud_hybrid/2_data_center_private_cloud.csv": 10,
  "csv/cloud_hybrid/3_public_cloud_estates.csv": 12,
  "csv/cloud_hybrid/4_workload_distribution.csv": 720,
  "csv/cloud_hybrid/5_cloud_platform_capabilities.csv": 80,
  "csv/cloud_hybrid/6_cloud_operations_economics.csv": 240,
  "csv/cloud_hybrid/7_cloud_findings_maturity.csv": 100,
  "csv/cloud_hybrid/8_cloud_initiatives_roadmap.csv": 42
}
FY2027_TOTAL = 2350000000
FY2026_TOTAL = 2180000000
CONTRACT_COVERAGE_TARGET = 0.63

def rows(path):
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def num(v):
    return int(float(str(v or 0).replace(",", "").replace("$", "")))

def mention_report(statements):
    fields = {
        "initiative": "initiative_mentioned",
        "application": "application_mentioned",
        "platform": "platform_mentioned",
        "vendor": "vendor_mentioned",
        "kpi": "kpi_mentioned",
    }
    counts = [sum(1 for col in fields.values() if r.get(col)) for r in statements]
    return {
        "rates": {field: sum(1 for r in statements if r.get(col)) / len(statements) for field, col in fields.items()},
        "no_mentions": sum(1 for c in counts if c == 0) / len(statements),
        "zero_or_one": sum(1 for c in counts if c <= 1) / len(statements),
        "three_plus": sum(1 for c in counts if c >= 3) / len(statements),
        "initiative_counts": Counter(r.get("initiative_mentioned", "") for r in statements if r.get("initiative_mentioned")),
    }

def main():
    root = Path(".")
    issues = []
    for rel, expected in EXPECTED.items():
        actual = len(rows(root / rel))
        if actual != expected:
            issues.append(f"{rel} rows {actual} != {expected}")
    budget = rows(root / "csv/enterprise_it/5_it_budget_allocations.csv")
    fy2027 = sum(num(r["Budget Amount *"]) for r in budget if r["Fiscal Year *"] == "2027")
    fy2026 = sum(num(r["Budget Amount *"]) for r in budget if r["Fiscal Year *"] == "2026")
    if fy2027 != FY2027_TOTAL: issues.append(f"FY2027 budget {fy2027} != {FY2027_TOTAL}")
    if fy2026 != FY2026_TOTAL: issues.append(f"FY2026 budget {fy2026} != {FY2026_TOTAL}")
    fy2027_rows = [r for r in budget if r["Fiscal Year *"] == "2027"]
    contract_backed = sum(num(r.get("contract_backed_amount")) for r in fy2027_rows)
    internal_noncontracted = sum(num(r.get("internal_noncontracted_amount")) for r in fy2027_rows)
    vc = Counter()
    for r in rows(root / "csv/enterprise_it/11_vendors_contracts.csv"):
        vc[r["vendor_name"]] += num(r["annual_value"])
    contract_total = sum(vc.values())
    coverage = contract_total / FY2027_TOTAL
    if not (0.60 <= coverage <= 0.65): issues.append(f"contract coverage {coverage:.2%} outside 60-65%")
    if contract_total != contract_backed: issues.append("contract total does not tie to contract_backed_amount")
    if contract_backed + internal_noncontracted != FY2027_TOTAL: issues.append("contract-backed plus internal/noncontracted does not equal FY2027 budget")
    risks = rows(root / "csv/enterprise_it/12_risks_controls.csv")
    blank_ratio = sum(1 for r in risks if not r["control_last_tested_date"]) / len(risks)
    if not (0.20 <= blank_ratio <= 0.30): issues.append("risk blank control test ratio outside range")
    for r in risks:
        if not r["control_last_tested_date"] and (r["control_test_result"] != "never_tested" or r.get("control_test_evidence_ref")):
            issues.append(f"never-tested contradiction {r.get('risk_id')}")
    statements = rows(root / "csv/enterprise_it/8b_interview_statements.csv")
    by_interview = Counter(r["interview_id"] for r in statements)
    if min(by_interview.values()) < 20: issues.append("an interview has fewer than 20 statements")
    mr = mention_report(statements)
    bounds = {"initiative": (0.38, 0.47), "application": (0.23, 0.32), "platform": (0.13, 0.22), "vendor": (0.18, 0.27), "kpi": (0.13, 0.22)}
    for field, (lo, hi) in bounds.items():
        if not (lo <= mr["rates"][field] <= hi): issues.append(f"{field} mention rate outside target")
    if not (0.18 <= mr["no_mentions"] <= 0.27): issues.append("no structured mention rate outside target")
    if mr["zero_or_one"] < 0.70: issues.append("zero-or-one structured entity rate below 70%")
    if mr["three_plus"] > 0.10: issues.append("three-plus structured entity rate above 10%")
    projects = rows(root / "csv/enterprise_it/6_projects_investments.csv")
    high_mentions = [n for n, c in mr["initiative_counts"].most_common(10)]
    under = [p for p in projects if p["Initiative / Project Name *"] in high_mentions and (p["Status *"] in {"On hold", "Awaiting decision", "At risk"} or p["Funding Status"] in {"Unfunded", "Partially funded", "Approved with constraint"})]
    quiet_funded = [p for p in projects if p.get("v3_conviction_funding_note") == "well_funded_low_conviction" and mr["initiative_counts"].get(p["Initiative / Project Name *"], 0) <= 1]
    if len(under) < 3: issues.append("fewer than 3 high-conviction underfunded initiatives")
    if len(quiet_funded) < 3: issues.append("fewer than 3 well-funded low-conviction initiatives")
    hints = json.loads((root / "metadata/relationship_hints.json").read_text())
    if len(hints) < 40: issues.append("relationship hints below 40")
    mapping = json.loads((root / "csv_messy/EXPECTED_MAPPING.json").read_text())
    if not any(v.get("value_mappings") for v in mapping.get("files", {}).values()): issues.append("messy value mappings missing")
    manifest = json.loads((root / "metadata/dataset_manifest.json").read_text())
    if not manifest.get("client_signoff_required_before_load"): issues.append("client sign-off gate missing from manifest")
    for wb_path in ["workbooks/SkyHarbor_Global_Enterprise_IT_Current_State_SYNTHETIC_v3.xlsx","workbooks/SkyHarbor_Global_Data_Analytics_Current_State_SYNTHETIC_v3.xlsx","workbooks/SkyHarbor_Global_Cloud_Hybrid_Current_State_SYNTHETIC_v3.xlsx"]:
        wb = load_workbook(root / wb_path, read_only=True, data_only=False)
        if "SYNTHETIC_SCENARIO" not in wb.sheetnames[:5]: issues.append(f"missing scenario sheet in {wb_path}")
        if "INTAKE_GUIDE" not in wb.sheetnames: issues.append(f"missing INTAKE_GUIDE in {wb_path}")
        wb.close()
    status = "pass" if not issues else "fail"
    print(json.dumps({"status": status, "issues": issues, "checked_csv_files": len(EXPECTED), "clean_csv_rows": sum(EXPECTED.values()), "relationship_hints": len(hints), "contract_coverage": round(coverage, 4), "minimum_interview_statements": min(by_interview.values())}, indent=2))
    raise SystemExit(0 if not issues else 1)

if __name__ == "__main__":
    main()

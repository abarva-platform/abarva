#!/usr/bin/env python3
"""Generate the SkyHarbor Global synthetic current-state assessment package.

This script intentionally operates at the source-intake/workbook layer. It copies
the supplied Abarva templates, populates them with deterministic fictional
records, exports CSV mirrors, writes metadata and reports, validates the package,
and creates the final ZIP artifact.
"""

from __future__ import annotations

import csv
import hashlib
import html
import importlib.util
import json
import os
import random
import re
import shutil
import tempfile
import zipfile
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.cell.cell import MergedCell
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


SEED = 20260802
RNG = random.Random(SEED)
TOTAL_IT_BUDGET = 2_350_000_000
ASSESSMENT_DATE = date(2027, 6, 30)
FY = 2027
COMPANY = "SkyHarbor Global Airlines Group"
SHORT = "SkyHarbor Global"
BASE = Path(__file__).resolve().parents[1]
SOURCE_ARCHIVE = Path("/Users/anand/Downloads/Abarva_All_Generated_Assessment_Artifacts_2026-08-02.zip")
SOURCE_ROOT = Path(os.environ.get("SKYHARBOR_SOURCE_ROOT", "/tmp/skyharbor_assessment_inspect.x4UsFP/01_LATEST_RECOMMENDED"))
DOWNLOADS_ZIP = Path("/Users/anand/Downloads/SkyHarbor_Global_Synthetic_Current_State_v3.zip")

TEMPLATE_FILES = {
    "enterprise_it": "Abarva_Enterprise_IT_Strategy_Budget_Adoption_Intake_v6.xlsx",
    "data_analytics": "Abarva_Function_Led_Data_Analytics_Current_State_Assessment_v5.xlsx",
    "cloud_hybrid": "Abarva_Cloud_Hybrid_Infrastructure_Current_State_Assessment_v1.xlsx",
}

OUTPUT_WORKBOOKS = {
    "enterprise_it": "SkyHarbor_Global_Enterprise_IT_Current_State_SYNTHETIC_v3.xlsx",
    "data_analytics": "SkyHarbor_Global_Data_Analytics_Current_State_SYNTHETIC_v3.xlsx",
    "cloud_hybrid": "SkyHarbor_Global_Cloud_Hybrid_Current_State_SYNTHETIC_v3.xlsx",
}

STRATEGIC_PRIORITIES = [
    "Improve operational reliability and irregular-operations recovery",
    "Protect safety, cybersecurity, and regulatory compliance",
    "Modernize the customer and loyalty experience",
    "Improve aircraft, crew, gate, and maintenance productivity",
    "Reduce technology complexity and operating cost",
    "Modernize legacy data, analytics, and integration platforms",
    "Establish a pragmatic hybrid and multicloud operating model",
    "Scale governed AI and agent adoption",
    "Improve project execution and investment transparency",
    "Strengthen enterprise resilience and disaster recovery",
]

HUBS = [
    "Dallas-Fort Worth", "Atlanta", "Chicago", "New York",
    "Los Angeles", "Miami", "London", "Tokyo",
]

FUNCTIONS = [
    ("Commercial Strategy", "Commercial and Customer", "Front Office"),
    ("Network Planning", "Commercial and Customer", "Front Office"),
    ("Schedule Planning", "Commercial and Customer", "Middle Office/Core Operations"),
    ("Revenue Management", "Commercial and Customer", "Front Office"),
    ("Pricing", "Commercial and Customer", "Front Office"),
    ("Sales", "Commercial and Customer", "Front Office"),
    ("Distribution", "Commercial and Customer", "Front Office"),
    ("Digital Commerce", "Commercial and Customer", "Front Office"),
    ("Customer Experience", "Commercial and Customer", "Front Office"),
    ("Contact Centers", "Commercial and Customer", "Front Office"),
    ("Loyalty", "Commercial and Customer", "Front Office"),
    ("Marketing", "Commercial and Customer", "Front Office"),
    ("Partnerships and Alliances", "Commercial and Customer", "Front Office"),
    ("Flight Operations", "Airline Operations", "Middle Office/Core Operations"),
    ("Crew Planning", "Airline Operations", "Middle Office/Core Operations"),
    ("Crew Scheduling", "Airline Operations", "Middle Office/Core Operations"),
    ("Crew Operations", "Airline Operations", "Middle Office/Core Operations"),
    ("Operations Control", "Airline Operations", "Middle Office/Core Operations"),
    ("Airport and Ground Operations", "Airline Operations", "Middle Office/Core Operations"),
    ("Baggage Operations", "Airline Operations", "Middle Office/Core Operations"),
    ("Passenger Service", "Airline Operations", "Front Office"),
    ("Dispatch", "Airline Operations", "Middle Office/Core Operations"),
    ("Maintenance and Engineering", "Airline Operations", "Middle Office/Core Operations"),
    ("Technical Operations", "Airline Operations", "Middle Office/Core Operations"),
    ("Fleet Planning", "Airline Operations", "Middle Office/Core Operations"),
    ("Safety", "Airline Operations", "Shared Enterprise"),
    ("Regulatory Compliance", "Airline Operations", "Shared Enterprise"),
    ("Cargo Operations", "Airline Operations", "Front Office"),
    ("Finance", "Corporate Functions", "Back Office/Corporate"),
    ("Treasury", "Corporate Functions", "Back Office/Corporate"),
    ("Procurement", "Corporate Functions", "Back Office/Corporate"),
    ("Human Resources", "Corporate Functions", "Back Office/Corporate"),
    ("Legal", "Corporate Functions", "Back Office/Corporate"),
    ("Corporate Strategy", "Corporate Functions", "Back Office/Corporate"),
    ("Risk", "Corporate Functions", "Shared Enterprise"),
    ("Internal Audit", "Corporate Functions", "Shared Enterprise"),
    ("Real Estate and Facilities", "Corporate Functions", "Back Office/Corporate"),
    ("Communications", "Corporate Functions", "Back Office/Corporate"),
    ("Digital Technology", "Technology", "Technology Foundation"),
    ("Corporate Applications", "Technology", "Technology Foundation"),
    ("Operations Technology", "Technology", "Technology Foundation"),
    ("Data, Analytics and AI", "Technology", "Technology Foundation"),
    ("Cloud and Infrastructure", "Technology", "Technology Foundation"),
    ("Cybersecurity", "Technology", "Technology Foundation"),
    ("Enterprise Architecture", "Technology", "Technology Foundation"),
    ("Integration and API", "Technology", "Technology Foundation"),
    ("IT Service Management", "Technology", "Technology Foundation"),
    ("Application Managed Services", "Technology", "Technology Foundation"),
    ("Technology Finance and PMO", "Technology", "Technology Foundation"),
]

PORTFOLIO_DISTRIBUTION = {
    "Infrastructure and Cloud": 22,
    "Corporate Applications": 16,
    "Data, Analytics and AI": 14,
    "Digital and Customer Technology": 12,
    "Application Managed Services": 11,
    "Cybersecurity": 10,
    "Network and Workplace": 8,
    "Architecture and Integration": 4,
    "Technology Strategy, Finance and PMO": 3,
}

PORTFOLIOS = [
    ("Office of the CIO", "Chief Information Officer", "Board Technology Committee", 350, "Technology strategy, portfolio governance, vendor accountability, and enterprise technology outcomes"),
    ("Technology Platforms", "Chief Technology Officer", "Chief Information Officer", 620, "Engineering standards, core platforms, reliability, integration, and hybrid-cloud operating model"),
    ("Data, Analytics and AI", "Chief Data and AI Officer", "Chief Information Officer", 780, "Data platforms, analytics products, semantic governance, AI products, and measured adoption"),
    ("Cybersecurity", "Chief Information Security Officer", "Chief Information Officer", 540, "Cyber defense, identity, third-party risk, operational technology security, and AI governance"),
    ("Digital and Customer Technology", "SVP Digital and Customer Technology", "Chief Information Officer", 860, "Digital commerce, mobile, customer care, loyalty, and customer disruption products"),
    ("Operations Technology", "SVP Operations Technology", "Chief Information Officer", 940, "Flight, crew, station, operations control, baggage, MRO, and cargo platforms"),
    ("Corporate Applications", "SVP Corporate Applications", "Chief Information Officer", 690, "ERP, finance, procurement, HR, legal, risk, and corporate workflow platforms"),
    ("Application Managed Services", "SVP Application Managed Services", "Chief Information Officer", 1650, "Managed application support towers, vendor operations, knowledge transition, and service levels"),
    ("Infrastructure and Cloud", "SVP Cloud and Infrastructure", "Chief Technology Officer", 1180, "Private cloud, public cloud, data centers, backup, storage, compute, and platform operations"),
    ("Network and Workplace", "SVP Network and Workplace", "Chief Technology Officer", 880, "Global network, airport connectivity, endpoint, collaboration, and contact-center workplace services"),
    ("Architecture and Integration", "SVP Enterprise Architecture and Integration", "Chief Technology Officer", 330, "Architecture governance, API platform, integration standards, and modernization patterns"),
    ("Technology Strategy, Finance and PMO", "SVP Technology Strategy, Finance and PMO", "Chief Information Officer", 360, "Technology finance, portfolio transparency, capital governance, and delivery assurance"),
    ("Data Platforms", "VP Data Platforms", "Chief Data and AI Officer", 290, "EDW, data lake, data engineering platforms, metadata, quality, and migration execution"),
    ("Analytics and BI", "VP Analytics and BI", "Chief Data and AI Officer", 260, "Enterprise BI, semantic models, operational dashboards, and reporting rationalization"),
    ("AI Products and Enablement", "VP AI Products and Enablement", "Chief Data and AI Officer", 230, "Copilot adoption, internal agents, AI gateway, model governance, and use-case measurement"),
    ("ERP and Corporate Platforms", "VP ERP and Corporate Platforms", "SVP Corporate Applications", 330, "SAP, Workday, Oracle EPM, procurement, legal, risk, and audit platforms"),
    ("Passenger Service Systems", "VP Passenger Service Systems", "SVP Digital and Customer Technology", 310, "Reservations, ticketing, departure control, inventory, and disruption re-accommodation"),
    ("Operations Platforms", "VP Operations Platforms", "SVP Operations Technology", 360, "Crew, flight, dispatch, maintenance, station, baggage, and cargo applications"),
    ("Cloud Platform Engineering", "VP Cloud Platform Engineering", "SVP Cloud and Infrastructure", 270, "Landing zones, Kubernetes, platform automation, IaC, and cloud guardrails"),
    ("Infrastructure Operations", "VP Infrastructure Operations", "SVP Cloud and Infrastructure", 460, "Data-center operations, private cloud, storage, backup, and legacy compute"),
    ("Service Management", "VP Service Management", "SVP Application Managed Services", 290, "ITSM, CMDB/APM, SRE practices, incident, change, and service analytics"),
    ("Cyber Engineering", "VP Cyber Engineering", "Chief Information Security Officer", 260, "IAM, detection engineering, vulnerability management, cloud security, and cyber automation"),
]

FIRST_NAMES = [
    "Maya", "Julian", "Priya", "Evan", "Nadia", "Marcus", "Elena", "Caleb", "Tessa", "Jordan",
    "Ari", "Sofia", "Lena", "Theo", "Amara", "Miles", "Rina", "Derek", "Noor", "Vivian",
    "Kian", "Helena", "Samira", "Owen", "Camila", "Rafael", "Iris", "Gavin", "Leila", "Simon",
    "Anika", "Rowan", "Mei", "Dante", "Claire", "Nolan", "Farah", "Jules", "Nico", "Mira",
    "Vera", "Adrian", "Lydia", "Quinn", "Selene", "Hugo", "Isabel", "Jonah", "Asha", "Reid",
]
LAST_NAMES = [
    "Marin", "Hale", "Voss", "Bennett", "Kapur", "Reyes", "Whitaker", "Sato", "Collins", "Ivers",
    "Moretti", "Shah", "Langford", "Navarro", "Bellamy", "Cho", "Ellis", "Sterling", "Kovacs", "Patel",
    "Harrington", "Okafor", "Vega", "Lin", "Calloway", "Frost", "Mendoza", "Pierce", "Sinclair", "Rosetti",
    "Mehra", "Donovan", "Keller", "Yamamoto", "Bishop", "Rossi", "Nair", "Sullivan", "Avery", "Monroe",
]

DOMAINS = [
    "Passenger Service and Reservations", "Ticketing", "Departure Control", "Revenue Management", "Pricing",
    "Loyalty", "Digital Commerce", "Customer Service", "Crew Planning and Scheduling", "Flight Operations",
    "Operations Control", "Dispatch", "Airport and Station Operations", "Baggage", "Maintenance Repair and Overhaul",
    "Fleet Planning", "Cargo", "Safety and Regulatory Reporting", "ERP Finance", "Treasury", "Procurement",
    "HR and Workforce", "Legal", "Risk and Compliance", "Service Management", "Cybersecurity", "Data and Analytics",
    "Integration and APIs", "Cloud and Infrastructure", "Collaboration and Productivity", "Marketing", "Network Planning",
]

TECH_PRODUCTS = [
    ("Amadeus Altéa", "Amadeus"), ("SabreSonic", "Sabre"), ("Jeppesen Crew Pairing", "Boeing Jeppesen"),
    ("TRAX eMRO", "TRAX"), ("AMOS", "Swiss-AS"), ("SAP S/4HANA", "SAP"), ("Workday HCM", "Workday"),
    ("ServiceNow ITSM", "ServiceNow"), ("Salesforce Service Cloud", "Salesforce"), ("Informatica PowerCenter", "Informatica"),
    ("Ab Initio", "Ab Initio"), ("IBM DataStage", "IBM"), ("Apache Kafka", "Confluent"), ("MuleSoft Anypoint", "Salesforce"),
    ("Teradata Vantage", "Teradata"), ("IBM Netezza", "IBM"), ("Cloudera Data Platform", "Cloudera"),
    ("Microsoft Azure", "Microsoft"), ("Amazon Web Services", "Amazon"), ("Google Cloud", "Google"),
    ("Databricks", "Databricks"), ("Snowflake", "Snowflake"), ("Microsoft Power BI", "Microsoft"),
    ("SAP BusinessObjects", "SAP"), ("Tableau", "Salesforce"), ("SAS Viya", "SAS"), ("GitHub Enterprise", "GitHub"),
    ("Microsoft 365", "Microsoft"), ("Oracle EPM", "Oracle"), ("Okta Workforce Identity", "Okta"),
]

AI_TOOLS = [
    ("Microsoft 365 Copilot", "Microsoft", "Productivity copilot", "Prompts"),
    ("GitHub Copilot", "GitHub", "Coding assistant", "Suggestions accepted"),
    ("ChatGPT Enterprise", "OpenAI", "Enterprise chat", "Conversations"),
    ("ServiceNow Now Assist", "ServiceNow", "ITSM assistant", "Summaries generated"),
    ("SAP Joule", "SAP", "ERP copilot", "Transactions assisted"),
    ("Power BI Copilot", "Microsoft", "BI copilot", "Reports assisted"),
    ("Customer Recovery Agent", "SkyHarbor Global", "Internal customer-service agent", "Cases resolved"),
    ("Maintenance Knowledge Agent", "SkyHarbor Global", "Internal maintenance-knowledge agent", "Answers cited"),
    ("Operations Recovery Agent", "SkyHarbor Global", "Internal operations-recovery agent", "Recovery plans drafted"),
    ("Data Engineering Assistant", "SkyHarbor Global", "Internal data-engineering assistant", "Pull requests drafted"),
    ("Enterprise AI Gateway", "SkyHarbor Global", "AI control plane", "Requests brokered"),
    ("Agent Workbench", "SkyHarbor Global", "Internal agent platform", "Agent runs"),
]


def money(value: int | float | Decimal) -> int:
    return int(Decimal(value).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def snake(name: str) -> str:
    text = re.sub(r"[^A-Za-z0-9]+", "_", name.replace("*", "")).strip("_").lower()
    return re.sub(r"_+", "_", text) or "column"


def unique_names(n: int) -> list[str]:
    names = []
    for first in FIRST_NAMES:
        for last in LAST_NAMES:
            names.append(f"{first} {last}")
    RNG.shuffle(names)
    return names[:n]


def pick(seq):
    return RNG.choice(seq)


def join(items, max_items=3):
    vals = list(items)
    RNG.shuffle(vals)
    return "; ".join(vals[:max_items])


def allocate(total: int, n: int, min_each: int = 0) -> list[int]:
    if n <= 0:
        return []
    base = min_each * n
    if base > total:
        min_each = 0
        base = 0
    remaining = total - base
    weights = [RNG.random() ** 1.7 + 0.05 for _ in range(n)]
    raw = [Decimal(remaining) * Decimal(str(w)) / Decimal(str(sum(weights))) for w in weights]
    vals = [min_each + int(x) for x in raw]
    vals[-1] += total - sum(vals)
    RNG.shuffle(vals)
    return vals


def pct(value: int, total: int) -> float:
    return round(value / total, 4) if total else 0.0


def make_dirs():
    for sub in ["workbooks", "csv/enterprise_it", "csv/data_analytics", "csv/cloud_hybrid", "metadata", "validation", "reports", "scripts"]:
        (BASE / sub).mkdir(parents=True, exist_ok=True)


def setup_source_root():
    global SOURCE_ROOT
    if all((SOURCE_ROOT / name).exists() for name in TEMPLATE_FILES.values()):
        return
    if not SOURCE_ARCHIVE.exists():
        raise FileNotFoundError(f"Source archive not found: {SOURCE_ARCHIVE}")
    tmp = Path(tempfile.mkdtemp(prefix="skyharbor_assessment_templates."))
    with zipfile.ZipFile(SOURCE_ARCHIVE) as z:
        z.extractall(tmp)
    SOURCE_ROOT = tmp / "01_LATEST_RECOMMENDED"
    missing = [name for name in TEMPLATE_FILES.values() if not (SOURCE_ROOT / name).exists()]
    if missing:
        raise FileNotFoundError(f"Latest recommended templates missing from archive: {missing}")


@dataclass
class Scenario:
    leaders: dict[str, str]
    leader_titles: dict[str, str]
    portfolio_leaders: dict[str, str]
    functions: list[dict]
    portfolios: list[dict]
    vendors: list[str]
    applications: list[dict]
    projects: list[dict]
    budget_rows: list[dict]
    kpis: list[dict]
    interviews: list[dict]
    feeds: list[dict]
    ai_rows: list[dict]
    data_platforms: list[dict]
    function_platform_map: list[dict]
    flows: list[dict]
    volumetrics: list[dict]
    da_findings: list[dict]
    da_initiatives: list[dict]
    cloud_strategy: list[dict]
    private_infra: list[dict]
    public_clouds: list[dict]
    workload_distribution: list[dict]
    cloud_capabilities: list[dict]
    cloud_economics: list[dict]
    cloud_findings: list[dict]
    cloud_initiatives: list[dict]


def build_scenario() -> Scenario:
    names = unique_names(140)
    name_iter = iter(names)
    leaders = {
        "CEO": next(name_iter), "CFO": next(name_iter), "COO": next(name_iter),
        "Chief Commercial Officer": next(name_iter), "Chief Customer Officer": next(name_iter),
        "Chief People Officer": next(name_iter), "Chief Information Officer": next(name_iter),
        "Chief Technology Officer": next(name_iter), "Chief Data and AI Officer": next(name_iter),
        "Chief Information Security Officer": next(name_iter), "Chief Digital Officer": next(name_iter),
        "Chief Strategy Officer": next(name_iter),
    }
    leader_titles = {v: k for k, v in leaders.items()}

    portfolio_leaders = {}
    portfolios = []
    for i, (portfolio, title, reports_to_title, team, mandate) in enumerate(PORTFOLIOS, 1):
        leader = leaders.get(title) or next(name_iter)
        portfolio_leaders[portfolio] = leader
        leader_titles[leader] = title
        top_budget = PORTFOLIO_DISTRIBUTION.get(portfolio, 0)
        budget = money(TOTAL_IT_BUDGET * top_budget / 100) if top_budget else money(TOTAL_IT_BUDGET * (team / 9200) * 0.4)
        portfolios.append({
            "name": portfolio, "leader": leader, "title": title,
            "reports_to": leaders.get(reports_to_title, reports_to_title),
            "team": team, "mandate": mandate, "budget": budget,
            "functions_served": "", "apps_owned": [], "projects": [],
        })

    functions = []
    for idx, (name, parent, layer) in enumerate(FUNCTIONS, 1):
        exec_name = next(name_iter)
        leader_titles[exec_name] = f"SVP {name}" if parent != "Technology" else f"VP {name}"
        if parent == "Technology":
            it_partner = portfolio_leaders.get(name, portfolio_leaders.get("Technology Platforms"))
        elif name in ["Digital Commerce", "Customer Experience", "Loyalty", "Sales", "Distribution", "Marketing"]:
            it_partner = portfolio_leaders["Digital and Customer Technology"]
        elif parent == "Airline Operations":
            it_partner = portfolio_leaders["Operations Technology"]
        elif name in ["Finance", "Treasury", "Procurement", "Human Resources", "Legal", "Risk", "Internal Audit"]:
            it_partner = portfolio_leaders["Corporate Applications"]
        else:
            it_partner = portfolio_leaders["Data, Analytics and AI"]
        functions.append({
            "id": f"FUNC-{idx:03d}", "name": name, "parent": parent, "layer": layer,
            "executive": exec_name, "it_partner": it_partner,
            "criticality": pick(["Critical", "High", "High", "Medium"]),
            "processes": [],
        })

    vendors = sorted({v for _, v in TECH_PRODUCTS} | {
        "SkyBridge AMS", "NorthPeak Consulting", "AeroCore Systems", "GlobalLink Telecom",
        "FortifyOne Security", "CloudPeak Managed Services", "DataVista Partners",
        "RunwayEdge Networks", "TerminalPoint Services", "AeroCloud Ops",
    })

    applications = build_applications(functions, portfolio_leaders)
    projects = build_projects(functions, portfolio_leaders, applications)
    budget_rows = build_budget_rows(functions, portfolio_leaders, applications, projects)
    reconcile_project_budgets(projects, budget_rows)
    kpis = build_kpis(functions, applications, projects)
    interviews = build_interviews(functions, portfolios, projects, applications, leaders, leader_titles)
    feeds = build_feeds(portfolio_leaders)
    ai_rows = build_ai_rows(functions, portfolio_leaders)
    data_platforms = build_data_platforms(portfolio_leaders)
    function_platform_map = build_function_platform_map(functions, data_platforms)
    flows = build_flows(functions, applications, data_platforms)
    volumetrics = build_volumetrics(functions)
    da_findings = build_da_findings(functions, data_platforms)
    da_initiatives = build_da_initiatives(functions, data_platforms, projects)
    cloud_strategy = build_cloud_strategy(portfolio_leaders)
    private_infra = build_private_infra(portfolio_leaders)
    public_clouds = build_public_clouds(portfolio_leaders)
    workload_distribution = build_workload_distribution(applications)
    cloud_capabilities = build_cloud_capabilities(portfolio_leaders)
    cloud_economics = build_cloud_economics(functions, portfolio_leaders)
    cloud_findings = build_cloud_findings(portfolio_leaders)
    cloud_initiatives = build_cloud_initiatives(functions, portfolio_leaders, projects)

    for p in portfolios:
        p["functions_served"] = join([f["name"] for f in functions if f["it_partner"] == p["leader"]], 8)
        p["apps_owned"] = [a["name"] for a in applications if a["portfolio"] == p["name"]][:14]
        p["projects"] = [pr["name"] for pr in projects if pr["it_portfolio"] == p["name"]][:8]

    return Scenario(
        leaders, leader_titles, portfolio_leaders, functions, portfolios, vendors, applications, projects,
        budget_rows, kpis, interviews, feeds, ai_rows, data_platforms, function_platform_map, flows,
        volumetrics, da_findings, da_initiatives, cloud_strategy, private_infra, public_clouds,
        workload_distribution, cloud_capabilities, cloud_economics, cloud_findings, cloud_initiatives
    )


def build_applications(functions, portfolio_leaders):
    apps = []
    criticalities = ["Tier 1/Critical"] * 130 + ["Tier 2/High"] * 209 + ["Tier 3/Medium"] * 252 + ["Tier 4/Low"] * 129
    hosting = ["On-premises traditional"] * 245 + ["Private cloud"] * 158 + ["Public-cloud IaaS/PaaS"] * 187 + ["SaaS"] * 130
    RNG.shuffle(criticalities)
    RNG.shuffle(hosting)
    lifecycle = ["Strategic"] * 145 + ["Maintain"] * 210 + ["Modernize"] * 205 + ["Replace"] * 82 + ["Retire"] * 51 + ["Decision disputed"] * 27
    RNG.shuffle(lifecycle)
    app_types = ["Custom application", "COTS", "SaaS", "Platform", "Data and analytics", "Integration"]
    product_cycle = TECH_PRODUCTS * 30
    for i in range(720):
        func = functions[i % len(functions)]
        domain = DOMAINS[i % len(DOMAINS)]
        product, vendor = product_cycle[i]
        if "Digital" in domain or "Customer" in domain:
            portfolio = "Digital and Customer Technology"
        elif any(x in domain for x in ["Crew", "Flight", "Operations", "Dispatch", "Airport", "Baggage", "Maintenance", "Cargo"]):
            portfolio = "Operations Technology"
        elif any(x in domain for x in ["ERP", "Treasury", "Procurement", "HR", "Legal", "Risk"]):
            portfolio = "Corporate Applications"
        elif any(x in domain for x in ["Data", "Analytics"]):
            portfolio = "Data, Analytics and AI"
        elif any(x in domain for x in ["Cloud", "Infrastructure", "Collaboration"]):
            portfolio = "Infrastructure and Cloud"
        elif "Cybersecurity" in domain:
            portfolio = "Cybersecurity"
        else:
            portfolio = pick(list(PORTFOLIO_DISTRIBUTION))
        host = hosting[i]
        provider = {
            "On-premises traditional": pick(["DFW Enterprise Data Center", "Atlanta Operations Data Center", "Chicago Resilience Data Center"]),
            "Private cloud": pick(["SkyHarbor Private Cloud East", "SkyHarbor Private Cloud Central", "Tokyo Regional Edge"]),
            "Public-cloud IaaS/PaaS": pick(["Azure East US", "Azure West Europe", "AWS us-east-1", "AWS eu-west-2", "Google Cloud us-central1"]),
            "SaaS": "Vendor SaaS",
        }[host]
        cost_known = RNG.random() > 0.055
        apps.append({
            "id": f"APP-{i+1:04d}",
            "name": f"{domain} {product} {i+1:03d}",
            "description": f"Fictional {domain.lower()} capability supporting {func['name']} across the global airline network.",
            "function": func["name"],
            "process": pick(["plan", "sell", "serve", "recover", "settle", "operate", "monitor", "analyze"]).title() + " workflow",
            "layer": func["layer"],
            "domain": domain,
            "business_owner": func["executive"],
            "portfolio": portfolio,
            "technical_owner": portfolio_leaders.get(portfolio, pick(list(portfolio_leaders.values()))),
            "criticality": criticalities[i],
            "lifecycle": lifecycle[i],
            "type": pick(app_types),
            "product": product,
            "vendor": vendor,
            "stack": pick(["Java/Spring", ".NET", "SAP ABAP", "Python", "React/Node", "Mainframe COBOL", "Oracle PL/SQL", "Databricks/Spark"]),
            "database": pick(["Oracle", "SQL Server", "PostgreSQL", "Teradata", "DB2", "Snowflake", "Cosmos DB", "DynamoDB", "Unknown"]),
            "integration": pick(["Batch file", "API", "Kafka event", "MuleSoft API", "ETL workflow", "Message queue", "Direct database extract"]),
            "hosting": host,
            "location": provider,
            "users": RNG.randint(35, 65000),
            "sla": pick(["99.5%", "99.7%", "99.9%", "99.95%", "Business hours", "Best effort"]),
            "annual_cost": money(RNG.randint(80_000, 9_000_000)) if cost_known else None,
            "data_class": pick(["Public", "Internal", "Confidential", "Restricted"]),
            "recovery": pick(["Tier 0", "Tier 1", "Tier 2", "Tier 3"]),
            "planned_action": pick(["Modernize", "Maintain", "Consolidate", "Retire candidate", "Replace", "Move to managed service", "Decision pending"]),
            "works": f"{func['name']} users understand {domain.lower()} workflows on {product}, and support paths are accountable for {host.lower()} operations.",
            "pain": pick([
                "Batch dependencies slow recovery during irregular operations.",
                "Ownership and KPI lineage are not consistently visible.",
                "Vendor release cadence constrains airline-specific changes.",
                "Manual reconciliation remains in peak operational windows.",
                "Cloud tags and CMDB records are incomplete for this estate.",
            ]),
            "cmdb": pick(["Yes", "Partial", "No", "Disputed"]),
            "source": pick(["ServiceNow CMDB synthetic extract", "Application portfolio interview", "APM export estimate", "Architecture workshop"]),
        })
    return apps


def build_projects(functions, portfolio_leaders, applications):
    themes = [
        "Operational Resilience", "Crew Recovery", "Airport Turnaround", "Baggage Visibility",
        "Customer Disruption Management", "Digital Booking Modernization", "Loyalty Modernization",
        "Contact Center Transformation", "ERP Modernization", "Finance Transformation",
        "Data Center Consolidation", "Cloud Landing Zone Modernization", "Application Rationalization",
        "Data Platform Modernization", "Teradata Optimization", "ETL Modernization",
        "KPI Semantic Standardization", "Data Governance", "Identity Modernization",
        "Network Modernization", "MRO Modernization", "Cargo Modernization", "AI Assistant Scaleout",
        "Coding Copilot Enablement", "ITSM AI", "Enterprise Agent Platform", "Managed Services Sourcing",
    ]
    statuses = ["In flight"] * 92 + ["At risk"] * 23 + ["On hold"] * 12 + ["Awaiting decision"] * 10 + ["Funded not started"] * 13
    RNG.shuffle(statuses)
    projects = []
    for i in range(150):
        func = functions[i % len(functions)]
        theme = themes[i % len(themes)]
        portfolio = portfolio_from_function(func["name"], func["parent"])
        related_apps = [a["name"] for a in applications if a["function"] == func["name"]][:4] or [pick(applications)["name"]]
        start = date(2026, 1, 1) + timedelta(days=RNG.randint(0, 720))
        end = start + timedelta(days=RNG.randint(180, 900))
        ai_component = "Yes - governed agent or copilot component" if ("AI" in theme or RNG.random() < 0.22) else "No"
        projects.append({
            "id": f"INIT-{i+1:03d}",
            "name": f"{theme} Wave {1 + i // len(themes)}",
            "type": pick(["Modernization", "Resilience", "Cost optimization", "Transformation", "Sourcing", "Governance"]),
            "function": func["name"],
            "priority": pick(STRATEGIC_PRIORITIES),
            "sponsor": func["executive"],
            "it_portfolio": portfolio,
            "owner": portfolio_leaders.get(portfolio, pick(list(portfolio_leaders.values()))),
            "objective": f"Improve {func['name']} outcomes by reducing technology friction, strengthening controls, and making operational evidence usable.",
            "status": statuses[i],
            "rank": pick(["Critical", "High", "Medium"]),
            "start": start,
            "end": end,
            "approved_budget": 0,
            "opex": 0,
            "capex": 0,
            "forecast": 0,
            "actual": 0,
            "funding": pick(["Approved", "Partially funded", "Pending steering decision", "Approved with constraint"]),
            "value": pick([
                "Faster operational recovery and fewer manual exception paths.",
                "Reduced run cost through simplification and sourcing leverage.",
                "Higher data trust and faster decision cycles for business owners.",
                "Improved resilience, security posture, and audit transparency.",
                "Better customer self-service and disruption communication.",
            ]),
            "kpis": "",
            "apps": "; ".join(related_apps),
            "ai": ai_component,
            "dependencies": join(["data lineage", "landing zone policy", "vendor negotiation", "CMDB refresh", "security review", "business owner decisions"], 3),
            "risk": pick([
                "Dependent on legacy batch retirement and vendor release windows.",
                "Benefits case is directional pending telemetry baseline.",
                "Parallel initiatives overlap and need portfolio sequencing.",
                "Specialist SME availability is constrained during peak travel periods.",
                "Data access and privacy review could delay rollout.",
            ]),
            "decision": pick(["Confirm funding", "Select target platform", "Approve sourcing strategy", "Resolve KPI owner", "No decision needed"]),
            "confidence": pick(["System-derived", "Interview-reported", "Estimated", "Pending validation"]),
        })
    return projects


def portfolio_from_function(name, parent):
    if parent == "Technology":
        if name in PORTFOLIO_DISTRIBUTION:
            return name
        if "Data" in name:
            return "Data, Analytics and AI"
        if "Cloud" in name:
            return "Infrastructure and Cloud"
        if "Cyber" in name:
            return "Cybersecurity"
        if "Architecture" in name or "Integration" in name:
            return "Architecture and Integration"
        if "Service" in name or "Managed" in name:
            return "Application Managed Services"
        return "Technology Strategy, Finance and PMO"
    if parent == "Airline Operations":
        return "Operations Technology"
    if name in ["Finance", "Treasury", "Procurement", "Human Resources", "Legal", "Risk", "Internal Audit"]:
        return "Corporate Applications"
    if name in ["Digital Commerce", "Customer Experience", "Loyalty", "Contact Centers", "Sales", "Distribution", "Marketing"]:
        return "Digital and Customer Technology"
    return "Data, Analytics and AI"


def build_budget_rows(functions, portfolio_leaders, applications, projects):
    portfolio_totals = {p: money(TOTAL_IT_BUDGET * pct_val / 100) for p, pct_val in PORTFOLIO_DISTRIBUTION.items()}
    portfolio_order = list(PORTFOLIO_DISTRIBUTION)
    rows = []
    rows_per_port = allocate(1800, len(portfolio_order), 160)
    cost_pools = ["Internal labor", "Contractors", "Software/SaaS", "Cloud consumption", "Managed services", "Data center", "Network/telecom", "Cyber products", "Program delivery", "Hardware"]
    acct_targets = {"OpEx": money(TOTAL_IT_BUDGET * Decimal("0.74")), "CapEx": TOTAL_IT_BUDGET - money(TOTAL_IT_BUDGET * Decimal("0.74"))}
    purpose_targets = {"Run": money(TOTAL_IT_BUDGET * Decimal("0.58")), "Grow": money(TOTAL_IT_BUDGET * Decimal("0.17")), "Transform": TOTAL_IT_BUDGET - money(TOTAL_IT_BUDGET * Decimal("0.58")) - money(TOTAL_IT_BUDGET * Decimal("0.17"))}
    cubes = []
    for p in portfolio_order:
        for acct, acct_total in acct_targets.items():
            for purp, purp_total in purpose_targets.items():
                amt = money(Decimal(portfolio_totals[p]) * Decimal(acct_total) / Decimal(TOTAL_IT_BUDGET) * Decimal(purp_total) / Decimal(TOTAL_IT_BUDGET))
                cubes.append([p, acct, purp, amt])
    cubes[-1][3] += TOTAL_IT_BUDGET - sum(c[3] for c in cubes)
    per_port_rows = dict(zip(portfolio_order, rows_per_port))
    cube_counts = []
    for p in portfolio_order:
        p_cubes = [c for c in cubes if c[0] == p]
        counts = allocate(per_port_rows[p], len(p_cubes), 6)
        cube_counts.extend([(c, counts[i]) for i, c in enumerate(p_cubes)])
    project_cycle = [p for p in projects if p["status"] != "On hold"] or projects
    project_idx = 0
    app_by_port = defaultdict(list)
    for app in applications:
        app_by_port[app["portfolio"]].append(app)
    for cube, n in cube_counts:
        portfolio, acct, purp, total = cube
        amounts = allocate(total, n, 25_000)
        for amt in amounts:
            func = pick(functions)
            linked_project = ""
            if purp in ["Grow", "Transform"]:
                linked_project = project_cycle[project_idx % len(project_cycle)]["name"]
                project_idx += 1
            app = pick(app_by_port.get(portfolio) or applications)
            vendor = app["vendor"] if RNG.random() < 0.72 else pick(["SkyBridge AMS", "CloudPeak Managed Services", "GlobalLink Telecom", "NorthPeak Consulting"])
            forecast = money(amt * (Decimal(str(RNG.uniform(0.96, 1.08)))))
            actual = money(amt * (Decimal(str(RNG.uniform(0.35, 0.92 if purp != "Run" else 1.02)))))
            rows.append({
                "Fiscal Year *": FY,
                "Period": pick(["FY2027", "Q1 2027", "Q2 2027", "Q3 2027", "Q4 2027"]),
                "Scenario *": "Current-state baseline",
                "Budget Owner *": portfolio_leaders[portfolio],
                "IT Portfolio *": portfolio,
                "Parent IT Organization": "Chief Information Officer",
                "Budget / Cost Center": f"CC-{portfolio[:3].upper().replace(' ', '')}-{RNG.randint(1000,9999)}",
                "Record Type *": pick(["Baseline budget", "Project budget", "Contract", "Consumption", "Labor allocation"]),
                "Run / Change *": "Run" if purp == "Run" else "Change",
                "Accounting Treatment *": acct,
                "Investment Purpose *": purp,
                "Cost Pool *": pick(cost_pools),
                "Technology Tower / Domain *": portfolio,
                "Technology Solution / Service": app["domain"],
                "Business Function / Consumer": func["name"],
                "Project / Initiative": linked_project,
                "Vendor": vendor,
                "Application / Platform": app["name"] if RNG.random() < 0.66 else "",
                "Budget Amount *": amt,
                "Forecast Amount": forecast,
                "Actual Amount": min(actual, forecast if forecast else actual),
                "Committed Amount": money(amt * Decimal(str(RNG.uniform(0.45, 0.98)))),
                "Currency *": "USD",
                "Capital Asset Class": pick(["Software", "Cloud platform", "Infrastructure", "Implementation services", "None"]),
                "Allocation Method / Confidence": pick(["GL extract", "Apptio allocation", "Contract register", "PMO forecast", "Interview estimate"]),
                "Source System / File": pick(["ERP GL synthetic extract", "Apptio synthetic allocation", "PMO investment ledger", "Contract register extract"]),
            })
    diff = TOTAL_IT_BUDGET - sum(r["Budget Amount *"] for r in rows)
    rows[-1]["Budget Amount *"] += diff
    rows[-1]["Forecast Amount"] += diff
    rows[-1]["Committed Amount"] += diff
    return rows


def reconcile_project_budgets(projects, budget_rows):
    by_project = defaultdict(lambda: {"approved": 0, "opex": 0, "capex": 0, "forecast": 0, "actual": 0})
    for r in budget_rows:
        p = r.get("Project / Initiative")
        if not p:
            continue
        bucket = by_project[p]
        bucket["approved"] += r["Budget Amount *"]
        bucket["forecast"] += r["Forecast Amount"]
        bucket["actual"] += r["Actual Amount"]
        if r["Accounting Treatment *"] == "OpEx":
            bucket["opex"] += r["Budget Amount *"]
        else:
            bucket["capex"] += r["Budget Amount *"]
    for p in projects:
        b = by_project[p["name"]]
        p.update({
            "approved_budget": b["approved"], "opex": b["opex"], "capex": b["capex"],
            "forecast": b["forecast"], "actual": b["actual"],
        })


def build_kpis(functions, applications, projects):
    core = [
        ("On-time departure", "Airline operations", "%", "Increase"), ("On-time arrival", "Airline operations", "%", "Increase"),
        ("Completion factor", "Airline operations", "%", "Increase"), ("Cancellation rate", "Airline operations", "%", "Decrease"),
        ("Mishandled baggage", "Airline operations", "bags per 1,000 passengers", "Decrease"), ("Aircraft utilization", "Airline operations", "hours/day", "Increase"),
        ("Crew recovery time", "Airline operations", "minutes", "Decrease"), ("Maintenance delay minutes", "Airline operations", "minutes", "Decrease"),
        ("Technical dispatch reliability", "Airline operations", "%", "Increase"), ("Fuel efficiency", "Airline operations", "gallons/ASM", "Decrease"),
        ("Net promoter score", "Customer and commercial", "score", "Increase"), ("Digital conversion", "Customer and commercial", "%", "Increase"),
        ("Contact-center wait time", "Customer and commercial", "seconds", "Decrease"), ("Self-service containment", "Customer and commercial", "%", "Increase"),
        ("Loyalty engagement", "Customer and commercial", "%", "Increase"), ("Revenue per passenger", "Customer and commercial", "USD", "Increase"),
        ("Load factor", "Customer and commercial", "%", "Increase"), ("RASM", "Customer and commercial", "cents", "Increase"),
        ("Close-cycle time", "Corporate", "days", "Decrease"), ("Procurement savings", "Corporate", "USD", "Increase"),
        ("Employee attrition", "Corporate", "%", "Decrease"), ("Availability", "Technology", "%", "Increase"),
        ("Incident volume", "Technology", "count", "Decrease"), ("MTTR", "Technology", "minutes", "Decrease"),
        ("Change success", "Technology", "%", "Increase"), ("Batch success", "Technology", "%", "Increase"),
        ("Data freshness", "Technology", "hours", "Decrease"), ("Cloud-cost variance", "Technology", "%", "Decrease"),
        ("Cyber vulnerabilities", "Technology", "count", "Decrease"), ("AI active rate", "Technology", "%", "Increase"),
    ]
    kpis = []
    for i in range(120):
        name, typ, unit, direction = core[i % len(core)]
        func = functions[i % len(functions)]
        if unit == "%":
            current = round(RNG.uniform(0.55, 0.985), 3)
            target = min(0.995, current + RNG.uniform(0.025, 0.12)) if direction == "Increase" else max(0.0, current - RNG.uniform(0.02, 0.08))
            prior = current - RNG.uniform(-0.03, 0.04)
        elif unit == "USD":
            current = money(RNG.randint(1_000_000, 95_000_000))
            target = money(current * RNG.uniform(1.03, 1.18))
            prior = money(current * RNG.uniform(0.9, 1.05))
        else:
            current = round(RNG.uniform(4, 600), 1)
            target = round(current * (RNG.uniform(0.72, 0.93) if direction == "Decrease" else RNG.uniform(1.05, 1.25)), 1)
            prior = round(current * RNG.uniform(0.95, 1.18), 1)
        kpis.append({
            "name": f"{name} - {func['name']}",
            "function": func["name"], "type": typ, "owner": func["executive"],
            "outcome": pick(STRATEGIC_PRIORITIES),
            "definition": f"Synthetic current-state measure for {func['name']} used to test deterministic reporting and contextual reasoning.",
            "unit": unit, "direction": direction, "current": current, "prior": prior, "target": target,
            "period": "2027 Q2", "frequency": pick(["Daily", "Weekly", "Monthly", "Quarterly"]),
            "source": pick(["Operations telemetry", "Finance mart", "ServiceNow analytics", "BI semantic layer", "Interview estimate"]),
            "related": pick(applications)["name"] + " / " + pick(projects)["name"],
            "confidence": pick(["High", "Medium", "Estimated", "Disputed"]),
            "caveat": pick(["Definition varies by function", "Lineage incomplete", "System-derived", "Requires client validation"]),
        })
    return kpis


def build_interviews(functions, portfolios, projects, applications, leaders, leader_titles):
    interviewees = []
    for title in ["CEO", "CFO", "COO", "Chief Commercial Officer", "Chief Customer Officer", "Chief People Officer", "Chief Information Officer", "Chief Technology Officer", "Chief Data and AI Officer", "Chief Information Security Officer", "Chief Digital Officer", "Chief Strategy Officer"]:
        interviewees.append((leaders[title], title, "Enterprise CXO", "Enterprise"))
    for p in portfolios[:22]:
        interviewees.append((p["leader"], p["title"], "IT portfolio leader", p["name"]))
    for f in functions[:14]:
        interviewees.append((f["executive"], leader_titles[f["executive"]], "Business function leader", f["name"]))
    rows = []
    seen = set()
    for i, (person, title, itype, scope) in enumerate(interviewees[:48]):
        proj = projects[i % len(projects)]
        app = applications[(i * 7) % len(applications)]
        budget_scope = pick(["Enterprise", "Portfolio", "Function", "Program"])
        approx_budget = money((proj["approved_budget"] or RNG.randint(5_000_000, 80_000_000)) * RNG.uniform(1.2, 4.8))
        if "CFO" in title:
            working = "Capital discipline is stronger than prior years, and the finance team can now isolate most major technology commitments."
            not_working = "Benefits realization still trails funding approval, especially where run cost avoidance is directional."
            quote = "I do not need perfect attribution on day one, but I need one budget spine everyone can reconcile to."
        elif "COO" in title or "Operations" in title:
            working = "Operational teams know the exception paths and can recover flights through high-touch coordination."
            not_working = "The recovery data arrives late, and decision support still depends on overnight or manual stitching."
            quote = "The airline runs on experienced people; the next step is making the systems recover with them."
        elif "Data" in title or "Analytics" in title:
            working = "Strategic Azure, Databricks, and semantic-layer work is creating a credible modernization path."
            not_working = "Functional marts define the same KPI differently, and lineage is too sparse for high-confidence AI answers."
            quote = "Usage is visible in places, value is visible in fewer places, and lineage is the bridge."
        elif "Security" in title or "Cyber" in title:
            working = "Identity modernization and cloud policy guardrails are improving the control baseline."
            not_working = "Legacy privileged access, third-party support channels, and unmanaged AI usage remain material concerns."
            quote = "AI adoption is acceptable only when telemetry, policy, and data protection move together."
        else:
            working = f"{scope} has strong business expertise and enough telemetry to identify the most important current-state patterns."
            not_working = f"{scope} still has fragmented ownership, inconsistent KPI definitions, and constrained delivery capacity."
            quote = f"The opportunity is not another generic transformation; it is sequencing {scope} around evidence."
        key = (working, not_working, quote)
        if key in seen:
            quote += f" Scope marker {i+1}."
        seen.add(key)
        rows.append({
            "Interviewee *": person,
            "Title *": title,
            "Interview Type *": itype,
            "Business Function / IT Portfolio *": scope,
            "Reports To": "Chief Executive Officer" if "Chief" in title and title != "CEO" else "Chief Information Officer",
            "Interview Date *": ASSESSMENT_DATE - timedelta(days=RNG.randint(1, 75)),
            "Portfolio / Function Mandate *": f"Lead {scope} outcomes across reliability, cost, modernization, and accountable delivery.",
            "Top Strategic Priorities *": join(STRATEGIC_PRIORITIES, 3),
            "Most Important Outcomes *": pick(["Operational reliability; cost transparency; trusted data", "Customer recovery; digital containment; loyalty growth", "Cyber resilience; platform simplification; delivery predictability"]),
            "Key Business Projects *": proj["name"],
            "Key IT / Data / AI Projects *": join([p["name"] for p in projects[i:i+6]], 3),
            "Approx Budget Scope": budget_scope,
            "Approx Total Budget": approx_budget,
            "Approx OpEx %": round(RNG.uniform(0.66, 0.82), 3),
            "Approx CapEx %": None,
            "Largest Operating Cost Pressures": pick(["Managed services and SaaS renewals", "Cloud growth without tagging discipline", "Legacy platform support", "Contractor-heavy delivery"]),
            "Top Capital Priorities": proj["name"],
            "Major Vendors / Contracts": join([app["vendor"], "SkyBridge AMS", "CloudPeak Managed Services"], 3),
            "What Is Working Well *": working,
            "What Is Not Working *": not_working,
            "Known Issues / Risks *": proj["risk"],
            "AI Strategy / Mandate *": pick(["Scale governed copilots", "Constrain sensitive use cases until controls mature", "Measure value before expanding licenses", "Use agents for recovery and knowledge workflows"]),
            "AI Tools / Agents in Use": join([t[0] for t in AI_TOOLS], 4),
            "AI Adoption / Usage Insight": pick(["High interest but uneven active use", "Strong engineering adoption", "Internal agents useful but value evidence incomplete", "Usage gated by data classification concerns"]),
            "Highest-Value AI Opportunities": pick(["Irregular-operations recovery", "Maintenance knowledge retrieval", "Contact-center case summarization", "Data engineering acceleration"]),
            "Talent / Operating Model Issues": pick(["SME capacity", "Vendor dependency", "Cloud engineering scarcity", "Fragmented product ownership"]),
            "Critical Decisions Needed": proj["decision"],
            "Target State in 12–24 Months *": "Fewer duplicated platforms, clearer ownership, stronger telemetry, and governed AI embedded in priority workflows.",
            "Key Quote / Observation": quote,
            "Source / Confidence": pick(["Completed interview; medium confidence", "Completed interview; high confidence", "Completed interview; some estimates"]),
        })
    for row in rows:
        row["Approx CapEx %"] = round(1 - row["Approx OpEx %"], 3)
    return rows


def build_feeds(portfolio_leaders):
    specs = [
        ("CMDB/APM", "ServiceNow CMDB/APM", "REST export", "Application/CI record"),
        ("ITSM", "ServiceNow incidents/problems/changes", "Scheduled API", "Ticket/change/outage"),
        ("Finance", "SAP S/4HANA GL and project accounting", "Secure file extract", "GL line/project"),
        ("Cloud", "Azure cost and inventory", "Cost Management export", "Subscription/resource/day"),
        ("Cloud", "AWS cost and inventory", "CUR and Config export", "Account/resource/day"),
        ("Cloud", "Google Cloud assets and billing", "Billing export", "Project/resource/day"),
        ("Private cloud", "VMware vCenter inventory", "API export", "VM/cluster"),
        ("Observability", "Datadog and Splunk", "API export", "Service event"),
        ("Backup", "Cohesity backup reports", "CSV export", "Backup job"),
        ("Security", "CrowdStrike and Wiz", "API export", "Asset/vulnerability"),
        ("BI", "Power BI/Fabric activity", "Admin API", "Report/user/activity"),
        ("BI", "Tableau and BusinessObjects usage", "Repository extract", "Workbook/report/user"),
        ("AI", "Microsoft 365 Copilot usage", "Admin center CSV export", "User/app/month"),
        ("AI", "GitHub Copilot org insights", "GitHub API", "Seat/user/month"),
        ("AI", "ChatGPT Enterprise usage", "Admin export", "Workspace/user/month"),
        ("AI", "ServiceNow Now Assist", "Now Platform export", "Case/summary/month"),
        ("ERP", "SAP workload and transaction usage", "SAP workload extract", "Transaction/user/day"),
        ("Internal AI", "Enterprise AI gateway telemetry", "Event stream", "Request/tool/run"),
        ("Internal AI", "Agent platform run logs", "PostgreSQL export", "Agent run"),
    ]
    rows = []
    access = ["Available", "Access requested", "Needs configuration", "Not available", "Unknown"]
    for i, (cat, source, method, grain) in enumerate(specs):
        rows.append({
            "Feed Category *": cat, "Source System / Product *": source,
            "Data Available *": pick(["Yes", "Partial", "No", "Unknown"]),
            "Preferred Extraction Method *": method,
            "Record Grain / Scope *": grain,
            "Key Metrics / Fields *": "owner; status; cost; usage; availability; lineage; period",
            "Historical Depth": pick(["90 days", "12 months", "24 months", "36 months", "Unknown"]),
            "Refresh Cadence": pick(["Daily", "Weekly", "Monthly", "Quarterly", "On request"]),
            "Business / Technical Owner": pick(list(portfolio_leaders.values())),
            "Access Status *": access[i % len(access)],
            "Privacy / User-Level Data": pick(["Aggregated only", "Pseudonymized users", "User-level restricted", "No user data"]),
            "Primary Target Sheet / Table": pick(["Applications", "Budget", "AI adoption", "Cloud economics", "Data volumetrics", "Service health"]),
            "Priority *": pick(["Critical", "High", "Medium"]),
            "Official Documentation": official_doc_url(source),
            "Notes / Constraints": "Synthetic feed register; availability reflects scenario access status, not a live client connection.",
        })
    return rows


def official_doc_url(source):
    if "Copilot" in source:
        return "https://learn.microsoft.com/en-us/microsoft-365/admin/activity-reports/microsoft-365-copilot-usage"
    if "ServiceNow" in source or "CMDB" in source:
        return "https://www.servicenow.com/docs/r/servicenow-platform/common-service-data-model-csdm/csdm-landing-page.html"
    if "Azure" in source:
        return "https://learn.microsoft.com/en-us/azure/cloud-adoption-framework/ready/landing-zone/"
    if "AWS" in source:
        return "https://aws.amazon.com/architecture/well-architected/"
    return "Synthetic source guide"


def build_ai_rows(functions, portfolio_leaders):
    rows = []
    periods = ["2026 Q3", "2026 Q4", "2027 Q1", "2027 Q2"]
    target_functions = [f for f in functions if f["parent"] != "Technology"][:5]
    for tool, vendor, category, unit in AI_TOOLS:
        for func in target_functions:
            maturity = RNG.uniform(0.35, 0.86)
            for q, period in enumerate(periods):
                purchased = RNG.randint(350, 12000)
                if vendor == "SkyHarbor Global":
                    active = RNG.randint(40, 2400)
                    assigned = active + RNG.randint(15, 420)
                    purchased = assigned + RNG.randint(20, 900)
                else:
                    assigned = min(purchased, money(purchased * (0.58 + q * 0.06 + RNG.uniform(-0.08, 0.08))))
                    active = min(assigned, money(assigned * min(0.96, maturity + q * 0.04 + RNG.uniform(-0.06, 0.05))))
                activity = active * RNG.randint(5, 85)
                cost = money((purchased or active) * RNG.uniform(8, 44) * 3)
                rows.append({
                    "Reporting Period *": period,
                    "Tool / Agent / Product *": tool,
                    "Vendor / Provider *": vendor,
                    "AI Category *": category,
                    "Business Function": func["name"],
                    "IT Portfolio Owner": portfolio_leaders["Data, Analytics and AI"],
                    "Seats Purchased": purchased,
                    "Seats Assigned": assigned,
                    "Active Users": active,
                    "Active Rate": None,
                    "Primary Activity Unit": unit,
                    "Primary Activity Count": activity,
                    "Agents / Workflows Executed": activity if "Agent" in category or "agent" in tool.lower() else "",
                    "Outputs Accepted / Completed": money(activity * RNG.uniform(0.42, 0.84)),
                    "Estimated Use Cost": cost,
                    "Estimated Hours Saved": money(activity * RNG.uniform(0.03, 0.42)),
                    "Top Use Cases *": pick(["meeting and document drafting", "case summary", "coding acceleration", "recovery plan drafting", "knowledge retrieval", "analytics narrative"]),
                    "Business Outcome / Value Evidence": pick(["Telemetry only", "Directional sponsor estimate", "Measured pilot baseline", "Not yet evidenced", "Validated for two teams"]),
                    "Adoption Trend": pick(["Increasing", "Flat", "Uneven", "Pilot expansion"]),
                    "Policy / Governance Status": pick(["Approved", "Approved with monitoring", "Restricted", "Paused pending review", "Pilot only"]),
                    "Risk / Issue": pick(["Sensitive data handling", "Value measurement incomplete", "License shelfware", "Prompt quality variance", "No material issue"]),
                    "Source Feed *": pick(["M365 admin usage export", "GitHub Copilot org insights", "AI gateway telemetry", "ServiceNow Now Assist export", "Interview estimate"]),
                    "Confidence": pick(["High", "Medium", "Estimated"]),
                    "Notes": "Synthetic adoption row; usage does not automatically equal value.",
                })
    return rows[:240]


def build_data_platforms(portfolio_leaders):
    names = [
        ("Teradata Enterprise Data Warehouse", "Enterprise EDW", "Teradata Vantage", "on-prem prod"),
        ("Netezza Revenue Mart", "Legacy appliance", "IBM Netezza", "legacy prod"),
        ("Cloudera Operational Data Lake", "Data lake", "Cloudera Data Platform", "private cloud"),
        ("Azure Data Lakehouse", "Strategic lakehouse", "Azure Data Lake; Synapse", "Azure East US"),
        ("Databricks Engineering Platform", "Engineering and AI", "Databricks", "Azure East US"),
        ("Snowflake Domain Analytics", "Domain warehouse", "Snowflake", "AWS us-east-1"),
        ("AWS Clickstream Lake", "Digital analytics", "S3; Glue; Athena", "AWS us-east-1"),
        ("Google AI Experiment Zone", "Specialized AI", "BigQuery; Vertex AI", "Google us-central1"),
        ("Finance Profitability Mart", "Function mart", "Oracle; Power BI", "on-prem prod"),
        ("Operations Control Mart", "Function mart", "SQL Server; Power BI", "private cloud"),
        ("Crew Recovery Feature Store", "AI feature store", "Databricks; MLflow", "Azure East US"),
        ("Maintenance Reliability Mart", "Function mart", "Teradata; Tableau", "on-prem prod"),
        ("Loyalty Customer 360 Store", "Customer data store", "Snowflake; Salesforce CDP", "AWS us-east-1"),
        ("Cargo Revenue Analytics Mart", "Function mart", "PostgreSQL; Tableau", "Azure East US"),
        ("Enterprise Semantic Layer", "Metrics layer", "Power BI; dbt metrics", "hybrid"),
    ]
    while len(names) < 45:
        d = DOMAINS[len(names) % len(DOMAINS)]
        names.append((f"{d} Analytics Mart {len(names)+1:02d}", "Function mart", pick(["Power BI", "Tableau", "BusinessObjects", "SAS", "dbt", "Informatica"]), pick(["on-prem prod", "Azure East US", "AWS us-east-1", "private cloud"])))
    rows = []
    for i, (name, layer, tech, env) in enumerate(names[:45]):
        rows.append({
            "Platform / Estate Name *": name,
            "Platform Layer *": layer,
            "Technology / Product *": tech,
            "Instance / Cluster / Environment": env,
            "Primary Role *": pick(["Enterprise reporting", "Operational analytics", "Advanced analytics", "Data engineering", "Semantic standardization"]),
            "Deployment Model *": "Hybrid" if "on-prem" in env or "private" in env else "Public cloud",
            "Hosting Location / Cloud Region": env,
            "Technical Owner *": portfolio_leaders["Data, Analytics and AI"],
            "Business / Executive Sponsor": pick(["Chief Data and AI Officer", "CFO", "COO", "Chief Commercial Officer"]),
            "Functions Served": join([f[0] for f in FUNCTIONS], 6),
            "Data Domains Served": join(DOMAINS, 5),
            "Approx Data Volume": pick(["12 TB", "85 TB", "240 TB", "1.2 PB", "4.8 PB"]),
            "Approx # Workflows / Jobs": RNG.randint(40, 2200),
            "Approx # Reports / Products": RNG.randint(8, 640),
            "Approx # Active Users": RNG.randint(75, 18000),
            "Availability / SLA": pick(["99.5%", "99.7%", "99.9%", "Best effort"]),
            "Batch / Processing Window": pick(["22:00-06:00 CT", "Near-real-time", "Hourly", "Daily overnight"]),
            "Approx Annual Run Cost": money(RNG.randint(250_000, 38_000_000)),
            "Lifecycle Status *": pick(["Strategic", "Maintain", "Modernize", "Retire candidate", "Decision pending"]),
            "What Works Well *": f"{name} has known consumers and production support for priority airline reporting.",
            "Current Constraint / Pain *": pick(["Batch window pressure", "Lineage gaps", "Overlapping marts", "Platform cost growth", "Sparse ownership metadata"]),
            "Known Technical Debt / Risk": pick(["Legacy ETL dependency", "Manual extracts", "Insufficient DR evidence", "Inconsistent semantic definitions"]),
            "Key Initiative / Planned Change": pick(["EDW modernization", "Semantic standardization", "ETL modernization", "Cloud migration", "Governance uplift"]),
            "Source / Confidence": pick(["Architecture workshop", "Platform-owner interview", "Inventory export", "Estimated"]),
        })
    return rows


def build_function_platform_map(functions, platforms):
    rows = []
    for i in range(240):
        f = functions[i % len(functions)]
        p = platforms[(i * 3) % len(platforms)]
        rows.append({
            "Business Function *": f["name"],
            "Platform / Estate Name *": p["Platform / Estate Name *"],
            "Platform Role for Function *": pick(["Source capture", "Enterprise warehouse", "Domain mart", "Semantic layer", "AI feature store", "Operational dashboard"]),
            "How the Function Uses It *": f"{f['name']} uses this estate for recurring decisions, exception handling, and performance reporting.",
            "Data Domain / Subject Area": pick(DOMAINS),
            "Key Source or Downstream System": pick([tp[0] for tp in TECH_PRODUCTS]),
            "Criticality *": pick(["Critical", "High", "Medium"]),
            "Approx Workload / Usage": pick(["Daily executive reporting", "High-volume batch", "Operational intraday", "Monthly close", "Ad hoc analysis"]),
            "Service Owner": p["Technical Owner *"],
            "Delivery / Support Model": pick(["Central data product team", "Function-led BI", "Managed service", "Shared platform team"]),
            "Current Health": pick(["Green", "Amber", "Amber", "Red"]),
            "What Works Well": f"{f['name']} consumers understand the {p['Platform / Estate Name *']} pattern and know the accountable support path.",
            "Known Pain / Dependency": pick(["Late source files", "Semantic disagreement", "Manual reconciliation", "Cloud policy dependency", "ETL fragility"]),
            "Initiative Affecting This Relationship": pick(["EDW modernization", "KPI semantic standardization", "Data governance", "ETL modernization"]),
            "Source / Confidence": pick(["System-derived", "Interview-reported", "Estimated"]),
        })
    return rows


def build_flows(functions, applications, platforms):
    examples = [
        "Reservation event to customer operations dashboard", "Flight event to operations-control analytics",
        "Crew data to crew recovery decision support", "Maintenance event to predictive maintenance",
        "Ticket and loyalty transaction to customer 360", "Revenue and booking data to demand forecasting",
        "ERP and procurement data to finance profitability mart", "Baggage scan data to baggage performance dashboard",
        "Airport event data to turnaround analytics", "Cargo booking and handling data to cargo revenue analytics",
    ]
    rows = []
    for i in range(72):
        f = functions[i % len(functions)]
        src = applications[(i * 5) % len(applications)]
        core = platforms[(i * 2) % len(platforms)]
        mart = platforms[(i * 2 + 7) % len(platforms)]
        rows.append({
            "Flow / Pattern Name *": f"{examples[i % len(examples)]} {i+1:02d}",
            "Business Function *": f["name"],
            "Business Purpose / Decision Supported *": f"Support {f['name']} decision cycles with traceable operational evidence.",
            "Primary Source System(s) *": src["name"],
            "Source Data / Domain": src["domain"],
            "Ingestion / Integration Tool *": pick(["Informatica", "Ab Initio", "IBM DataStage", "Azure Data Factory", "Kafka", "MuleSoft"]),
            "Landing / Staging Platform": pick(["Azure Data Lakehouse", "Cloudera Operational Data Lake", "AWS Clickstream Lake"]),
            "Core Warehouse / Lake / EDW *": core["Platform / Estate Name *"],
            "Function / Domain Mart or Store": mart["Platform / Estate Name *"],
            "Transformation / Processing Tool": pick(["dbt", "Spark", "SQL procedures", "Informatica mapping", "Ab Initio graph"]),
            "Semantic / Metrics Layer": pick(["Enterprise Semantic Layer", "Power BI dataset", "BusinessObjects universe", "Tableau semantic model"]),
            "Reporting / Analytics / AI Tool *": pick(["Power BI", "Tableau", "BusinessObjects", "SAS", "Operations Recovery Agent"]),
            "Primary Consumers": join([f["executive"], "operations analysts", "portfolio leaders"], 3),
            "Batch / Real-Time *": pick(["Batch", "Near-real-time", "Real-time", "Hybrid"]),
            "Frequency / Latency *": pick(["15 minutes", "Hourly", "Daily overnight", "Near-real-time"]),
            "Approx Data Volume": pick(["12 GB/day", "95 GB/day", "0.8 TB/day", "4.5 TB/day"]),
            "Approx # Jobs / Workflows in Pattern": RNG.randint(18, 620),
            "Critical SLA / Batch Window": pick(["Before 05:30 CT", "Sub-15 minute", "Business hours", "Before hub bank start"]),
            "Technical Owner *": core["Technical Owner *"],
            "Controls / Quality Checks": pick(["row counts; freshness; duplicate checks", "schema drift; reconciliation; lineage", "SLA monitor; alerting; manual review"]),
            "What Works Well": f"{f['name']} consumers recognize this flow and know where to request changes for {src['domain'].lower()} reporting.",
            "Primary Bottleneck / Failure *": pick(["Late upstream file", "Long-running batch graph", "Manual exception correction", "Semantic disagreement", "Capacity contention"]),
            "Business Impact": pick(["Delayed recovery choices", "Duplicate reporting effort", "Higher support cost", "Less trusted KPI discussion"]),
            "Initiative / Planned Change": pick(["ETL modernization", "Semantic standardization", "Operational recovery data product", "EDW modernization"]),
            "Source / Confidence": pick(["Architecture workshop", "System telemetry", "Interview-reported", "Estimated"]),
        })
    return rows


def build_volumetrics(functions):
    rows = []
    estates = ["Finance mart", "Revenue mart", "Operations mart", "Crew analytics", "Maintenance analytics", "Customer 360", "Cargo analytics", "Enterprise EDW"]
    for i in range(84):
        f = functions[i % len(functions)]
        active_jobs = RNG.randint(45, 1250)
        rows.append({
            "Business Function *": f["name"],
            "Major Estate / Domain": estates[i % len(estates)],
            "Approx # Source Systems": RNG.randint(4, 38),
            "Approx Data Volume": pick(["2 TB", "15 TB", "88 TB", "320 TB", "1.1 PB"]),
            "Approx Daily Data Ingest": pick(["8 GB", "75 GB", "420 GB", "1.4 TB", "6 TB"]),
            "Approx # Active ETL / ELT Jobs": active_jobs,
            "Approx # Critical Jobs": money(active_jobs * RNG.uniform(0.12, 0.34)),
            "Approx Daily Job Runs": active_jobs * RNG.randint(1, 9),
            "Job Success Rate": round(RNG.uniform(0.91, 0.997), 3),
            "Critical Batch Window": pick(["22:00-06:00 CT", "01:00-05:00 local", "Continuous", "Before first departures"]),
            "Approx # Warehouses / Marts / Stores": RNG.randint(1, 12),
            "Approx # Reports": RNG.randint(45, 1900),
            "Approx # Dashboards": RNG.randint(8, 360),
            "Approx # Semantic Models / Cubes": RNG.randint(2, 95),
            "Approx # Active Users": RNG.randint(80, 24000),
            "Approx # Authors / Developers": RNG.randint(5, 260),
            "Peak Concurrency": RNG.randint(20, 2800),
            "Typical Refresh / Latency": pick(["15 min", "Hourly", "Daily", "T+1", "Near-real-time"]),
            "Approx Monthly Incidents": RNG.randint(0, 46),
            "Approx # Known Data Quality Issues": RNG.randint(1, 120),
            "Approx Manual Effort per Month (Hours)": RNG.randint(20, 2200),
            "Approx Annual Platform / Service Cost": money(RNG.randint(120_000, 28_000_000)),
            "Reliability / Service Health *": pick(["Green", "Amber", "Amber", "Red"]),
            "Data Trust / Consistency *": pick(["High", "Medium", "Inconsistent", "Disputed"]),
            "Primary Capacity / Scale Constraint": pick(["Batch window", "Warehouse concurrency", "Semantic fragmentation", "Storage growth", "SME capacity"]),
            "Source / Confidence": pick(["System-derived", "Estimated", "Interview-reported"]),
        })
    return rows


def build_da_findings(functions, platforms):
    dims = ["Strategy", "Governance", "Lineage", "Data quality", "Platform", "Semantic consistency", "Delivery model", "AI readiness"]
    rows = []
    for f in functions[:42]:
        for dim in dims:
            maturity = RNG.randint(2, 4)
            rows.append({
                "Business Function *": f["name"],
                "Assessment Dimension *": dim,
                "Current-State Summary *": f"{f['name']} has useful {dim.lower()} practices, but maturity varies by source and product owner.",
                "Current Maturity (1–5) *": maturity,
                "Evidence / Examples *": pick(["platform-owner interview", "BI inventory", "workflow volumetrics", "architecture workshop", "sample dashboard lineage"]),
                "What Works Well": f"{f['name']} users can name the core {dim.lower()} outputs and the decisions they support.",
                "What Does Not Work / Root Cause *": pick(["Definitions differ by mart", "Lineage is incomplete", "Batch window constrains freshness", "Ownership is split across teams"]),
                "Business / Technology Impact *": pick(["Slower decisions", "Duplicate reconciliation", "Higher support cost", "Reduced AI confidence"]),
                "Priority *": pick(["Critical", "High", "Medium"]),
                "Accountable Owner": pick([p["Technical Owner *"] for p in platforms]),
                "Related Platform / Flow": pick([p["Platform / Estate Name *"] for p in platforms]),
                "Initiative Underway": pick(["EDW modernization", "KPI semantic standardization", "Data governance", "ETL modernization"]),
                "Target State in 12–24 Months": "Trusted semantic definitions, clearer lineage, and fewer overlapping marts.",
                "Source / Confidence": pick(["High", "Medium", "Estimated"]),
            })
    return rows


def build_da_initiatives(functions, platforms, projects):
    rows = []
    for i in range(55):
        p = projects[(i * 2) % len(projects)]
        f = functions[i % len(functions)]
        rows.append({
            "Initiative Name *": p["name"] if i < 36 else f"{pick(['Lineage', 'Semantic', 'Data Quality', 'EDW'])} Enablement {i+1:02d}",
            "Business Function(s) *": f["name"],
            "Initiative Type *": pick(["Platform modernization", "Governance", "Semantic model", "ETL modernization", "AI readiness"]),
            "Executive Sponsor *": f["executive"],
            "Technical / Delivery Owner *": pick([pl["Technical Owner *"] for pl in platforms]),
            "Problem / Opportunity Addressed *": "Reduce duplicate reporting and make data usable for governed strategy questions.",
            "Platforms / Estates Affected *": join([pl["Platform / Estate Name *"] for pl in platforms], 3),
            "Flows / Analytics Products Affected": pick(["operations control dashboards", "finance profitability reporting", "customer 360", "crew recovery analytics"]),
            "Status *": p["status"],
            "Start Date": p["start"],
            "Target End Date": p["end"],
            "Approx Investment": p["approved_budget"] or money(RNG.randint(500_000, 18_000_000)),
            "Expected Business / Technology Value": p["value"],
            "Key Dependencies": p["dependencies"],
            "Major Risk / Constraint": p["risk"],
            "Future-State Direction": "Progressive modernization with serving views for exact facts and Claude for governed interpretation.",
            "Source / Confidence": p["confidence"],
        })
    return rows


def build_cloud_strategy(portfolio_leaders):
    dims = [
        "Hybrid cloud posture", "Azure enterprise landing zones", "AWS digital and operations estates",
        "Google Cloud specialized analytics", "Private cloud retention", "Tier 1 workload placement",
        "SaaS adoption", "Data-center consolidation", "FinOps maturity", "Cloud policy and tagging",
        "Disaster recovery", "Network connectivity", "Identity federation", "AI platform placement",
        "Container platform strategy", "Observability model",
    ]
    rows = []
    for dim in dims:
        rows.append({
            "Strategy / Placement Dimension *": dim,
            "Current Position *": "Pragmatic hybrid and cloud-smart posture with cloud governance stronger in newer landing zones.",
            "Approved or Working Principle *": pick(["Place by workload characteristics", "Azure primary for enterprise data and AI", "Retain selected Tier 1 operational workloads private", "SaaS where business process fit is strong"]),
            "Business / Technology Rationale *": "Protect reliability and compliance while modernizing data, digital, and integration capabilities.",
            "Scope / Workload Classes": pick(["Tier 1 operations", "digital customer", "data and AI", "corporate SaaS", "legacy batch"]),
            "Primary Provider / Environment Role": pick(["Azure primary", "AWS major digital estate", "Google specialized analytics", "Private cloud retained"]),
            "Regulatory / Data Residency Constraint": pick(["Crew and customer data controls", "PCI scope", "Country-specific residency", "No special constraint identified"]),
            "Latency / Connectivity Constraint": pick(["Airport edge dependency", "Hub operations latency", "Batch window", "Standard connectivity"]),
            "Resilience / DR Requirement": pick(["Active/passive", "Active/active for selected services", "Tiered DR", "Under review"]),
            "Cost / Commercial Constraint": pick(["Reserved commitments", "SaaS renewal", "Data egress", "Colocation contract"]),
            "What Works Well": f"{dim} has clearer guardrails in newer landing zones and better account/subscription hygiene than inherited estates.",
            "What Does Not Work": pick(["Legacy estates have weak tagging", "Application placement rationale is inconsistent", "FinOps is not embedded in every product team"]),
            "Target Direction in 12–24 Months *": "Codified placement rules, stronger FinOps, and rationalized private-cloud footprint.",
            "Accountable Owner *": portfolio_leaders["Infrastructure and Cloud"],
            "Current Maturity (1–5)": RNG.randint(2, 4),
            "Priority *": pick(["Critical", "High", "Medium"]),
            "Evidence / Source": "Cloud strategy workshop; synthetic infrastructure inventory",
        })
    return rows


def build_private_infra(portfolio_leaders):
    sites = [
        ("DFW Enterprise Data Center", "Owned data center", "Dallas-Fort Worth, TX", "Primary enterprise and operational systems"),
        ("Atlanta Operations Data Center", "Owned data center", "Atlanta, GA", "Operations resilience and crew systems"),
        ("Chicago Resilience Data Center", "Owned data center", "Chicago, IL", "DR and Midwest hub operations"),
        ("London Colocation Site", "Colocation", "London, UK", "European regional processing"),
        ("Tokyo Colocation Site", "Colocation", "Tokyo, JP", "Asia regional processing"),
        ("SkyHarbor Private Cloud East", "Private cloud", "Virginia", "VMware and Kubernetes shared services"),
        ("SkyHarbor Private Cloud Central", "Private cloud", "Texas", "Operational tier workloads"),
        ("Legacy Mainframe Estate", "Specialized legacy compute", "Dallas-Fort Worth, TX", "Ticketing and settlement batch"),
        ("Airport Edge Processing", "Regional/edge", "Global hubs", "Airport and station local processing"),
        ("Maintenance Engineering Lab", "Specialized compute", "Tulsa, OK", "MRO test and engineering workloads"),
    ]
    rows = []
    for i, (name, ftype, loc, role) in enumerate(sites):
        rows.append({
            "Estate / Site Name *": name, "Footprint Type *": ftype, "Location *": loc, "Primary Role *": role,
            "Ownership / Commercial Model *": "Owned" if "Owned" in ftype else "Contracted",
            "Primary Functions / Workloads Served *": join([f[0] for f in FUNCTIONS], 5),
            "Technical Owner *": portfolio_leaders["Infrastructure and Cloud"],
            "Facility / Colocation Provider": "" if "Owned" in ftype else pick(["Equinix", "Digital Realty", "KDDI", "NTT Global"]),
            "Resilience / Tier / Paired Site": pick(["Tier III paired", "Tier IV primary", "Regional edge", "Active/passive"]),
            "Approx # Racks": RNG.randint(12, 420), "Power Capacity (MW)": round(RNG.uniform(0.4, 12.5), 1),
            "Average Power Utilization": round(RNG.uniform(0.48, 0.83), 3),
            "Approx # Physical Servers": RNG.randint(180, 6200), "Approx # Virtual Machines": RNG.randint(800, 28000),
            "Approx # Container Clusters": RNG.randint(2, 95), "Virtualization / Private-Cloud Platform *": pick(["VMware vSphere", "Red Hat OpenShift", "Mainframe LPAR", "Bare-metal Linux"]),
            "Container Platform": pick(["OpenShift", "AKS hybrid", "Kubernetes", "None"]),
            "Compute Stack": pick(["x86 blades", "mainframe", "GPU cluster", "hyperconverged"]),
            "Storage Stack": pick(["NetApp", "Pure Storage", "Dell EMC", "IBM Storage"]),
            "Network / SDN Stack": pick(["Cisco ACI", "VMware NSX", "Arista EVPN", "Traditional VLAN"]),
            "Backup / Recovery Stack": pick(["Cohesity", "Rubrik", "Commvault", "IBM Spectrum Protect"]),
            "Automation / Configuration Stack": pick(["Ansible", "Terraform", "vRealize", "Manual scripts"]),
            "Monitoring / Observability Stack": pick(["Splunk", "Datadog", "Dynatrace", "SolarWinds"]),
            "Approx Storage Capacity (PB)": round(RNG.uniform(1.2, 45.0), 1),
            "Approx Compute Utilization": round(RNG.uniform(0.35, 0.78), 3),
            "Approx Storage Utilization": round(RNG.uniform(0.42, 0.86), 3),
            "Approx Annual Run Cost": money(RNG.randint(6_000_000, 92_000_000)),
            "Facility / Contract End Date": date(2028 + i % 5, RNG.randint(1, 12), 28),
            "Lifecycle Status *": pick(["Maintain", "Refresh", "Exit planned", "Strategic retained", "Decision pending"]),
            "What Works Well *": f"Operational teams know {name} and practice recovery procedures for its priority workloads.",
            "What Does Not Work *": pick(["Hardware lifecycle pressure", "Manual provisioning", "DR evidence incomplete", "Capacity constrained", "Cost allocation weak"]),
            "Known Risk / Constraint": pick(["Colocation renewal", "Mainframe skills", "Power headroom", "Airport edge standardization"]),
            "Planned Change / Exit / Refresh": pick(["Consolidate", "Refresh", "Exit by 2030", "Retain with modernization"]),
            "Source / Confidence": pick(["Inventory export", "Infrastructure workshop", "Estimated"]),
        })
    return rows


def build_public_clouds(portfolio_leaders):
    specs = [
        ("Azure", "Enterprise", "Azure Enterprise Data and AI Landing Zone"),
        ("Azure", "Enterprise", "Azure Corporate Shared Services"),
        ("Azure", "Operations", "Azure Operations Platform"),
        ("Azure", "Security", "Azure Security and Identity"),
        ("AWS", "Digital", "AWS Digital Commerce Estate"),
        ("AWS", "Customer", "AWS Customer Analytics Estate"),
        ("AWS", "Operations", "AWS Event Integration Estate"),
        ("AWS", "Resilience", "AWS DR and Burst Estate"),
        ("Google Cloud", "AI Lab", "Google Specialized AI Projects"),
        ("Google Cloud", "Analytics", "Google Network Optimization Sandbox"),
        ("Azure", "Regional", "Azure Europe Regulated Zone"),
        ("AWS", "Regional", "AWS Asia Pacific Integration Zone"),
    ]
    rows = []
    for provider, org, name in specs:
        spend = money(RNG.randint(18_000_000, 165_000_000))
        rows.append({
            "Cloud Provider *": provider,
            "Tenant / Organization *": f"SkyHarbor {org}",
            "Estate / Landing Zone Name *": name,
            "Account Structure / Hierarchy *": pick(["Management groups/subscriptions", "AWS Organizations/accounts", "Folders/projects"]),
            "Primary Regions *": pick(["eastus; centralus; westeurope", "us-east-1; us-west-2; eu-west-2", "us-central1; europe-west2", "japaneast; southeastasia"]),
            "Primary Workload Roles *": pick(["data and AI", "digital customer", "operations integration", "security tooling", "regional workloads"]),
            "Functions / IT Portfolios Served *": join([f[0] for f in FUNCTIONS], 6),
            "Cloud Platform Owner *": portfolio_leaders["Infrastructure and Cloud"],
            "Security Owner": portfolio_leaders["Cybersecurity"],
            "Network Connectivity *": pick(["ExpressRoute", "Direct Connect", "Cloud Interconnect", "SD-WAN"]),
            "Identity / Federation *": pick(["Entra ID", "Okta federation", "Hybrid identity"]),
            "Approx # Accounts / Subscriptions / Projects": RNG.randint(12, 240),
            "Approx # Resources": RNG.randint(2800, 95000),
            "Approx # Virtual Machines": RNG.randint(80, 6300),
            "Approx # Container Clusters": RNG.randint(8, 140),
            "Approx # Serverless Functions": RNG.randint(20, 4500),
            "Approx # Managed Databases": RNG.randint(12, 980),
            "Approx Data Storage (TB/PB)": pick(["85 TB", "420 TB", "1.8 PB", "6.4 PB"]),
            "Approx # Applications / Services": RNG.randint(18, 150),
            "Approx Annual Spend": spend,
            "Commitment / Discount Coverage": round(RNG.uniform(0.34, 0.82), 3),
            "Major Compute / Container Stack": pick(["AKS", "EKS", "GKE", "VM Scale Sets", "ECS Fargate"]),
            "Major Storage / Database Stack": pick(["ADLS; Azure SQL", "S3; Aurora", "BigQuery", "Cosmos DB", "RDS; DynamoDB"]),
            "Data / Analytics / AI Services": pick(["Azure AI Foundry; Databricks", "SageMaker; Glue", "Vertex AI; BigQuery", "Synapse; Fabric"]),
            "Observability / SecOps Stack": pick(["Defender; Sentinel", "CloudWatch; Security Hub", "Chronicle", "Datadog"]),
            "Infrastructure as Code / DevOps Stack": pick(["Terraform; GitHub Actions", "Bicep; Azure DevOps", "CloudFormation", "Pulumi"]),
            "Governance / Policy Model": pick(["Strong in new landing zone", "Uneven legacy coverage", "Central policy with exceptions", "Emerging"]),
            "Cost Allocation / Tagging Coverage": round(RNG.uniform(0.46, 0.94), 3),
            "Availability / Resilience Pattern": pick(["multi-zone", "multi-region for tier 1", "single-region with DR", "under review"]),
            "Lifecycle / Strategic Role *": pick(["Strategic growth", "Maintain and govern", "Rationalize", "Specialized use"]),
            "What Works Well *": f"{name} has clearer platform standards than older migrated estates in the same provider family.",
            "What Does Not Work *": pick(["Tagging gaps", "Policy exceptions", "Egress costs", "DR tests inconsistent", "Landing zones uneven"]),
            "Known Risk / Constraint": pick(["Commitment lock-in", "Shared network bottleneck", "Data residency", "FinOps tooling gap"]),
            "Planned Change": pick(["landing zone modernization", "policy remediation", "commitment optimization", "regional rationalization"]),
            "Source / Confidence": pick(["Cloud inventory", "FinOps export", "Platform interview", "Estimated"]),
        })
    return rows


def build_workload_distribution(applications):
    domains = DOMAINS[:11]
    bases = [
        ("Application count", {"On-premises traditional": 34, "Private cloud": 22, "Public-cloud IaaS/PaaS": 26, "SaaS": 18}),
        ("Critical business services", {"On-premises traditional": 33, "Private cloud": 22, "Public-cloud IaaS/PaaS": 25, "SaaS": 20}),
        ("Technology spend", {"On-premises traditional": 16, "Private cloud": 14, "Public-cloud IaaS/PaaS": 42, "SaaS": 28}),
        ("Data volume", {"On-premises traditional": 38, "Private cloud": 22, "Public-cloud IaaS/PaaS": 32, "SaaS": 8}),
    ]
    rows = []
    for domain in domains:
        for basis, split in bases:
            total_qty = RNG.randint(60, 1800) if basis != "Technology spend" else RNG.randint(8_000_000, 85_000_000)
            quantities = {}
            envs = list(split)
            for env in envs[:-1]:
                quantities[env] = money(total_qty * split[env] / 100)
            quantities[envs[-1]] = total_qty - sum(quantities.values())
            for env in envs:
                rows.append({
                    "Snapshot Period *": "2027 Q2",
                    "Business Function": pick([f[0] for f in FUNCTIONS]),
                    "Application / Technology Domain": domain,
                    "Criticality Segment": pick(["Tier 1/Critical", "Tier 2/High", "All material applications"]),
                    "Distribution Basis *": basis,
                    "Hosting Environment *": env,
                    "Provider / Private-Cloud Estate": pick(["DFW Enterprise Data Center", "SkyHarbor Private Cloud East", "Azure", "AWS", "Google Cloud", "Vendor SaaS"]),
                    "Quantity *": quantities[env],
                    "Distribution Percent": split[env] / 100,
                    "Key Workload Types": pick(["transactional applications", "analytics workloads", "integration services", "customer digital", "operational systems"]),
                    "Primary Platform / Estate": pick(["Teradata EDW", "Azure Data Lakehouse", "AWS Digital Estate", "Private Cloud East", "Vendor SaaS"]),
                    "Data Sensitivity / Residency": pick(["Internal", "Confidential", "Restricted", "Regional controls"]),
                    "Latency / Edge Constraint": pick(["airport edge", "hub operations", "standard WAN", "batch window"]),
                    "Current Health": pick(["Green", "Amber", "Amber", "Red"]),
                    "Placement Direction *": pick(["Retain", "Modernize in place", "Migrate", "Retire", "SaaS replace"]),
                    "Migration / Modernization Strategy": pick(["refactor", "rehost", "replace", "retain", "retire"]),
                    "Key Constraint / Rationale": pick(["latency", "resilience", "contract", "data residency", "technical debt"]),
                    "Source / Confidence": "Derived from synthetic application/platform/spend records",
                })
    # Add four enterprise total rows to reach 180.
    for basis, split in bases:
        total_qty = 720 if basis == "Application count" else 100
        env = "Enterprise total check"
        rows.append({
            "Snapshot Period *": "2027 Q2", "Business Function": "Enterprise",
            "Application / Technology Domain": "Enterprise rollup", "Criticality Segment": "All",
            "Distribution Basis *": basis, "Hosting Environment *": env,
            "Provider / Private-Cloud Estate": "All", "Quantity *": total_qty,
            "Distribution Percent": 1.0, "Key Workload Types": "validation rollup",
            "Primary Platform / Estate": "All", "Data Sensitivity / Residency": "Mixed",
            "Latency / Edge Constraint": "Mixed", "Current Health": "Mixed",
            "Placement Direction *": "Mixed", "Migration / Modernization Strategy": "Mixed",
            "Key Constraint / Rationale": "Rollup row for workbook users",
            "Source / Confidence": "Derived rollup",
        })
    return rows


def build_cloud_capabilities(portfolio_leaders):
    areas = ["landing zones", "identity", "network", "policy", "tagging", "FinOps", "containers", "serverless", "database", "data/AI", "observability", "backup", "DR", "DevSecOps", "CMDB integration", "secrets", "vulnerability", "patching", "automation", "SRE"]
    envs = ["Azure", "AWS", "Google Cloud", "Private cloud"]
    rows = []
    for area in areas:
        for env in envs:
            rows.append({
                "Capability Area *": area.title(),
                "Environment Scope *": env,
                "Current Technology / Product *": pick(["Terraform", "Azure Policy", "AWS Control Tower", "Google Org Policy", "OpenShift", "Datadog", "ServiceNow CMDB", "Wiz", "GitHub Actions"]),
                "Standard / Approved? *": pick(["Approved", "Approved with exceptions", "Emerging", "Not standardized"]),
                "Accountable Owner *": portfolio_leaders["Infrastructure and Cloud"],
                "Coverage / Adoption": pick(["Broad", "Partial", "New landing zones only", "Pilot"]),
                "Automation Level *": pick(["Manual", "Scripted", "Partially automated", "Policy-as-code"]),
                "Service Model": pick(["central platform", "federated product teams", "managed service", "shared responsibility"]),
                "Integration with ITSM / CMDB": pick(["strong", "partial", "planned", "manual"]),
                "Security / Compliance Approach": pick(["central guardrails", "policy exceptions", "manual review", "automated controls"]),
                "Operational Support Model": pick(["24x7", "business hours", "managed service", "SRE rotation"]),
                "What Works Well *": f"{env} {area} standards are usable for new work when teams engage the platform group early.",
                "Gap / Constraint *": pick(["legacy exception backlog", "coverage gaps", "manual approval", "skill scarcity", "tool overlap"]),
                "Current Maturity (1–5) *": RNG.randint(2, 4),
                "Planned Change": pick(["standardize", "expand automation", "integrate CMDB", "rationalize tools"]),
                "Source / Confidence": pick(["Platform workshop", "Inventory export", "Estimated"]),
            })
    return rows


def build_cloud_economics(functions, portfolio_leaders):
    providers = ["Azure", "AWS", "Google Cloud", "Private cloud", "Vendor SaaS"]
    rows = []
    for period in ["2026 Q3", "2026 Q4", "2027 Q1", "2027 Q2"]:
        for i in range(30):
            provider = providers[i % len(providers)]
            budget = money(RNG.randint(350_000, 16_000_000))
            actual = money(budget * RNG.uniform(0.87, 1.16))
            rows.append({
                "Reporting Period *": period,
                "Estate / Provider *": provider,
                "Environment Type *": "Public cloud" if provider in ["Azure", "AWS", "Google Cloud"] else provider,
                "Business / IT Portfolio": pick(list(PORTFOLIO_DISTRIBUTION)),
                "Spend Basis *": pick(["Actual consumption", "Allocated run cost", "Commitment amortization", "Marketplace"]),
                "Budget": budget, "Actual Spend": actual, "Forecast": money(actual * RNG.uniform(0.96, 1.08)),
                "Committed Spend": money(budget * RNG.uniform(0.35, 0.88)),
                "Compute Cost": money(actual * RNG.uniform(0.32, 0.54)),
                "Storage Cost": money(actual * RNG.uniform(0.12, 0.28)),
                "Network / Egress Cost": money(actual * RNG.uniform(0.04, 0.16)),
                "Software / Marketplace Cost": money(actual * RNG.uniform(0.08, 0.22)),
                "Managed Service Cost": money(actual * RNG.uniform(0.04, 0.2)),
                "Commitment / Discount Coverage": round(RNG.uniform(0.25, 0.82), 3),
                "Average Resource Utilization": round(RNG.uniform(0.32, 0.76), 3),
                "Idle / Waste Estimate": round(RNG.uniform(0.05, 0.23), 3),
                "Tagging / Allocation Coverage": round(RNG.uniform(0.42, 0.94), 3),
                "Availability / SLA": pick(["99.5%", "99.9%", "99.95%", "Best effort"]),
                "Sev1 / Sev2 Incidents": RNG.randint(0, 9),
                "Change Failure Rate": round(RNG.uniform(0.02, 0.16), 3),
                "Backup Success Rate": round(RNG.uniform(0.91, 0.999), 3),
                "DR Test Status": pick(["Passed", "Partial", "Not tested", "Scheduled"]),
                "Patch Compliance": round(RNG.uniform(0.76, 0.99), 3),
                "Critical Vulnerability Exposure": RNG.randint(0, 48),
                "Capacity / Scalability Constraint": pick(["none material", "quota limits", "database throughput", "network egress", "reserved capacity"]),
                "Key Cost / Operational Insight *": pick(["Spend growing faster than workload count", "Tag coverage limits chargeback", "Commitments are underutilized", "Availability is strong but DR evidence is partial"]),
                "Source Feed *": pick(["Azure cost export", "AWS CUR", "GCP billing export", "VMware inventory", "SaaS contract register"]),
            })
    return rows


def build_cloud_findings(portfolio_leaders):
    scopes = ["Azure", "AWS", "Google Cloud", "Private Cloud", "Data Centers", "FinOps", "Resilience", "Security", "CMDB Integration", "Containers"]
    dims = ["strategy", "governance", "cost", "resilience", "operations", "security", "automation", "talent", "observability", "lifecycle"]
    rows = []
    for s in scopes:
        for d in dims:
            rows.append({
                "Assessment Scope *": s,
                "Assessment Dimension *": d.title(),
                "Current-State Summary *": f"{s} {d} practices are credible in newer environments but inconsistent across inherited estates.",
                "Current Maturity (1–5) *": RNG.randint(2, 4),
                "Evidence / Examples *": pick(["cloud inventory", "FinOps export", "platform interview", "policy review", "incident trend"]),
                "What Works Well": f"{s} platform teams have {d} standards and can support prioritized migrations.",
                "Gap / Root Cause *": pick(["legacy exception backlog", "weak tagging", "incomplete DR testing", "manual runbooks", "unclear ownership"]),
                "Business / Technology Impact *": pick(["higher run cost", "migration delay", "resilience uncertainty", "slower incident resolution"]),
                "Priority *": pick(["Critical", "High", "Medium"]),
                "Accountable Owner": portfolio_leaders["Infrastructure and Cloud"],
                "Target State in 12–24 Months": "Governed landing zones, measured FinOps, and clear placement rules.",
                "Related Initiative / Action": pick(["Cloud Landing Zone Modernization Wave 1", "Data Center Consolidation Wave 1", "FinOps operating model", "DR evidence uplift"]),
                "Source / Confidence": pick(["High", "Medium", "Estimated"]),
            })
    return rows


def build_cloud_initiatives(functions, portfolio_leaders, projects):
    rows = []
    for i in range(42):
        p = projects[(i * 3) % len(projects)]
        rows.append({
            "Initiative Name *": p["name"] if i < 30 else f"Cloud Governance Remediation {i+1:02d}",
            "Initiative Type *": pick(["Migration", "Modernization", "Governance", "FinOps", "Resilience", "Data-center exit"]),
            "Strategy Driver *": pick(STRATEGIC_PRIORITIES),
            "Environment / Estate *": pick(["Azure", "AWS", "Google Cloud", "Private cloud", "DFW Enterprise Data Center", "London Colocation Site"]),
            "Functions / Applications Affected *": join([f["name"] for f in functions], 4),
            "Executive Sponsor *": pick([f["executive"] for f in functions]),
            "Delivery Owner *": portfolio_leaders["Infrastructure and Cloud"],
            "Status *": p["status"],
            "Priority *": p["rank"],
            "Start Date": p["start"],
            "Target End Date": p["end"],
            "Approx Investment": p["approved_budget"] or money(RNG.randint(800_000, 42_000_000)),
            "Expected Value / Outcome *": p["value"],
            "Approx Workload Scope": pick(["12 applications", "one hub estate", "3 landing zones", "enterprise shared service", "regional workloads"]),
            "Migration / Modernization Strategy": pick(["rehost", "refactor", "replace with SaaS", "retain and harden", "exit"]),
            "Key Dependencies": p["dependencies"],
            "Major Risk / Constraint": p["risk"],
            "Current Progress / Evidence": pick(["inventory complete", "pilot in progress", "funding requested", "architecture approved", "blocked by dependency"]),
            "Target-State Result": "Clearer workload placement, lower unmanaged spend, stronger DR proof, and fewer legacy exceptions.",
            "Source / Confidence": p["confidence"],
        })
    return rows


def workbook_rows(s: Scenario):
    return {
        "enterprise_it": {
            "1_Enterprise_Context": [{
                "Organization Name *": COMPANY,
                "Industry / Sector *": "Global network airline, cargo, loyalty, and travel services",
                "Primary Geography *": "Global; headquarters Dallas-Fort Worth, Texas",
                "Enterprise Scale": "Revenue $52.8B; employees 109,500; 1,020 aircraft; 5,150 daily departures; 198M passengers; 335 destinations; 63 countries; 8 hubs; 86M loyalty members.",
                "Top Strategic Priorities *": "; ".join(STRATEGIC_PRIORITIES),
                "Questions Intelligence Must Answer *": "Where are reliability, cost, modernization, data, cloud, and AI efforts aligned or in tension?",
                "Executive Sponsor *": s.leaders["Chief Information Officer"],
                "Discovery Lead *": "Abarva synthetic current-state factory",
                "As-of Date *": ASSESSMENT_DATE,
                "Planning Horizon": "2027-2030",
                "Capitalization Policy Source": "Synthetic finance policy scenario; OpEx 74%, CapEx 26%",
                "Known Constraints": "Legacy batch, data-center lifecycle, cloud governance gaps, AMS contracts, inconsistent KPI definitions.",
                "Existing Strategy Source": "Synthetic executive interviews and scenario model; no real airline confidential data.",
            }],
            "2_Business_Functions": business_function_rows(s),
            "3_IT_Portfolios_Organization": portfolio_rows(s),
            "4_Applications_Portfolio": app_rows(s),
            "5_IT_Budget_Allocations": s.budget_rows,
            "6_Projects_Investments": project_rows(s),
            "7_KPIs_Outcomes": kpi_rows(s),
            "8_CXO_Function_Interviews": s.interviews,
            "9_Operational_Usage_Feeds": s.feeds,
            "10_AI_Adoption_Usage": s.ai_rows,
        },
        "data_analytics": {
            "1_Function_Analytics_Profile": da_profile_rows(s),
            "2_Platform_Tech_Stack": s.data_platforms,
            "3_Function_Platform_Map": s.function_platform_map,
            "4_Source_to_Consumption": s.flows,
            "5_Function_Volumetrics": s.volumetrics,
            "6_Findings_Maturity": s.da_findings,
            "7_Initiatives_Roadmap": s.da_initiatives,
        },
        "cloud_hybrid": {
            "1_Cloud_Strategy_Placement": s.cloud_strategy,
            "2_Data_Center_Private_Cloud": s.private_infra,
            "3_Public_Cloud_Estates": s.public_clouds,
            "4_Workload_Distribution": s.workload_distribution,
            "5_Cloud_Platform_Capabilities": s.cloud_capabilities,
            "6_Cloud_Operations_Economics": s.cloud_economics,
            "7_Cloud_Findings_Maturity": s.cloud_findings,
            "8_Cloud_Initiatives_Roadmap": s.cloud_initiatives,
        },
    }


def business_function_rows(s):
    rows = []
    for f in s.functions:
        projects = [p["name"] for p in s.projects if p["function"] == f["name"]][:3]
        apps = [a["name"] for a in s.applications if a["function"] == f["name"]][:4]
        rows.append({
            "Function Name *": f["name"], "Parent Function": f["parent"], "Operating Layer *": f["layer"],
            "Function Description *": f"{f['name']} owns fictional airline capabilities within {f['parent']} and depends on governed technology, data, and operational evidence.",
            "Business Executive *": f["executive"], "IT Partner *": f["it_partner"], "Criticality *": f["criticality"],
            "Top Strategic Priorities *": join(STRATEGIC_PRIORITIES, 3),
            "Top Business Outcomes *": pick(["reliability; productivity; lower cost", "customer trust; loyalty growth; faster recovery", "risk reduction; data trust; execution transparency"]),
            "Key Business Processes": join([f"{f['name']} planning", f"{f['name']} execution", f"{f['name']} exception recovery"], 3),
            "Primary Customer / Stakeholder": pick(["passengers", "crew", "airport teams", "corporate leaders", "cargo customers", "technology product teams"]),
            "Top Pain / Constraint": pick(["fragmented ownership", "overnight batch dependency", "manual reconciliation", "legacy platform constraints", "vendor dependency"]),
            "Key Business Projects": "; ".join(projects),
            "Key IT / Data / AI Projects": "; ".join(projects[:2]),
            "Key Applications / Platforms": "; ".join(apps),
            "Existing Source": "Synthetic function model and executive interview corpus",
        })
    return rows


def portfolio_rows(s):
    rows = []
    for p in s.portfolios:
        rows.append({
            "IT Portfolio / Group Name *": p["name"],
            "Portfolio Leader *": p["leader"], "Leader Title *": p["title"], "Reports To": p["reports_to"],
            "Portfolio Mandate *": p["mandate"], "Business Functions Supported": p["functions_served"],
            "Technology Domains / Services Owned *": join(DOMAINS, 5),
            "Applications / Platforms Owned": "; ".join(p["apps_owned"]),
            "Approx Team Size": p["team"], "Budget Owner? *": "Yes" if p["name"] in PORTFOLIO_DISTRIBUTION else "No",
            "Budget Cost Center(s)": f"CC-{snake(p['name']).upper()[:8]}", "Approx Annual Budget": p["budget"],
            "Run / Change Responsibility": pick(["Run-heavy", "Balanced run/change", "Change-heavy", "Governance and assurance"]),
            "CapEx Authority / Responsibility": pick(["Portfolio capex authority", "Shared CIO/CFO approval", "Delivery input only"]),
            "Major Vendors / Contracts": join(s.vendors, 5), "Top Strategic Priorities *": join(STRATEGIC_PRIORITIES, 3),
            "Key Projects / Initiatives *": "; ".join(p["projects"]),
            "AI / Automation Mandate": pick(["Scale governed AI", "Use AI for service management", "Measure value before expansion", "Support AI platform controls"]),
            "What Works Well": f"{p['name']} has clear accountability for priority services and major vendors.",
            "Known Issues / Constraints *": pick(["AMS cost pressure", "legacy technical debt", "cloud guardrail gaps", "SME capacity", "delivery overlap"]),
            "Interview Priority": pick(["High", "Medium", "Critical"]), "Existing Source": "Synthetic org model and portfolio interviews",
        })
    return rows


def app_rows(s):
    rows = []
    for a in s.applications:
        rows.append({
            "Application / Platform Name *": a["name"], "Description *": a["description"],
            "Primary Business Function *": a["function"], "Primary Business Process": a["process"],
            "Operating Layer *": a["layer"], "Application Domain *": a["domain"], "Business Owner *": a["business_owner"],
            "IT Portfolio Owner *": a["portfolio"], "Technical / Product Owner": a["technical_owner"],
            "Business Criticality *": a["criticality"], "Lifecycle Status *": a["lifecycle"], "Application Type *": a["type"],
            "Primary Vendor / Product": f"{a['vendor']} / {a['product']}", "Primary Technology Stack": a["stack"],
            "Primary Database / Data Store": a["database"], "Major Integration Pattern": a["integration"],
            "Major Upstream / Downstream Systems": join([x["name"] for x in s.applications[:40]], 3),
            "Hosting Model *": a["hosting"], "Cloud Provider / Region or Data Center": a["location"],
            "Approx User Population": a["users"], "Usage / Adoption Source": a["source"], "Availability / SLA": a["sla"],
            "Annual Run Cost": a["annual_cost"], "Data Classification": a["data_class"], "Recovery Tier": a["recovery"],
            "Planned Action": a["planned_action"], "What Works Well": a["works"], "Known Pain / Risk": a["pain"],
            "CMDB / APM Record Available?": a["cmdb"], "Existing Source": a["source"],
        })
    return rows


def project_rows(s):
    rows = []
    for p in s.projects:
        rows.append({
            "Initiative / Project Name *": p["name"], "Initiative Type *": p["type"],
            "Business Function(s) *": p["function"], "Strategic Priority *": p["priority"],
            "Business Sponsor *": p["sponsor"], "IT Portfolio Owner *": p["it_portfolio"], "Program / Project Owner": p["owner"],
            "Objective / Problem Addressed *": p["objective"], "Status *": p["status"], "Priority *": p["rank"],
            "Start Date": p["start"], "Target End Date": p["end"], "Approved Budget": p["approved_budget"],
            "OpEx Budget": p["opex"], "CapEx Budget": p["capex"], "Forecast at Completion": p["forecast"],
            "Actual to Date": p["actual"], "Funding Status": p["funding"], "Expected Business / Technology Value *": p["value"],
            "KPIs / Outcomes Affected": p["kpis"] or "Availability; MTTR; cost variance; data freshness",
            "Applications / Platforms Affected": p["apps"], "AI / Automation Component": p["ai"],
            "Key Dependencies": p["dependencies"], "Major Risk / Constraint": p["risk"], "Decision Needed": p["decision"],
            "Source / Confidence": p["confidence"],
        })
    return rows


def kpi_rows(s):
    return [{
        "KPI Name *": k["name"], "Business Function *": k["function"], "KPI Type *": k["type"], "KPI Owner *": k["owner"],
        "Business Outcome *": k["outcome"], "Definition *": k["definition"], "Unit *": k["unit"], "Direction *": k["direction"],
        "Current Value *": k["current"], "Prior Value": k["prior"], "Target Value": k["target"], "Reporting Period *": k["period"],
        "Frequency *": k["frequency"], "Source System / File": k["source"], "Related Application / Initiative": k["related"],
        "Confidence": k["confidence"], "Known Issue / Caveat": k["caveat"],
    } for k in s.kpis]


def da_profile_rows(s):
    rows = []
    platforms = [p["Platform / Estate Name *"] for p in s.data_platforms]
    for f in s.functions[:42]:
        rows.append({
            "Business Function *": f["name"], "Parent Function": f["parent"], "Operating Layer *": f["layer"],
            "Business Executive *": f["executive"], "IT / Data Partner *": s.portfolio_leaders["Data, Analytics and AI"],
            "Critical Decisions / Workflows Supported *": f"{f['name']} daily performance, exception recovery, investment sequencing, and risk review.",
            "Top KPIs / Outcomes *": join([k["name"] for k in s.kpis if k["function"] == f["name"]] or [k["name"] for k in s.kpis], 4),
            "How the Function Is Served Today *": pick(["central EDW plus function mart", "function mart with manual reconciliation", "cloud lakehouse pilot plus legacy reports", "BI semantic layer over mixed sources"]),
            "Primary Operational Source Systems *": join([a["name"] for a in s.applications if a["function"] == f["name"]][:8], 4),
            "Primary Enterprise Data Platform / EDW": pick(platforms), "Primary Function / Domain Mart or Data Store": pick(platforms),
            "Primary ETL / Integration Tool(s)": join(["Informatica", "Ab Initio", "DataStage", "Azure Data Factory", "Kafka", "MuleSoft"], 3),
            "Primary Semantic / Metrics Layer": pick(["Enterprise Semantic Layer", "Power BI dataset", "BusinessObjects universe", "Tableau semantic model"]),
            "Primary Reporting / BI Tool(s)": join(["Power BI", "Tableau", "BusinessObjects", "SAS"], 2),
            "Primary Advanced Analytics / AI Tool(s)": join(["Databricks", "SAS Viya", "Operations Recovery Agent", "Maintenance Knowledge Agent"], 2),
            "Service Model *": pick(["central data product", "function-led", "managed service", "hybrid"]),
            "Business Criticality *": f["criticality"], "Typical Data / Analytics Latency": pick(["Near-real-time", "Hourly", "Daily", "T+1"]),
            "What Works Well *": f"{f['name']} users know the key reports and can describe decision moments clearly.",
            "What Does Not Work *": pick(["KPI definitions vary", "lineage is thin", "manual extracts persist", "batch is late", "source ownership unclear"]),
            "Known Issues / Challenges *": pick(["duplicated marts", "workflow fragility", "quality exceptions", "semantic disagreement", "limited AI-ready evidence"]),
            "Key Initiatives in Flight": join([p["name"] for p in s.projects if p["function"] == f["name"]] or [p["name"] for p in s.projects], 3),
            "Desired Direction in 12–24 Months": "Fewer duplicated marts, governed semantic definitions, and cited AI-ready context.",
            "Overall Current Maturity (1–5)": RNG.randint(2, 4),
            "Primary Interviewees / Source": f["executive"], "Confidence": pick(["High", "Medium", "Estimated"]),
        })
    return rows


def add_doc_sheet(wb, title, rows):
    if title in wb.sheetnames:
        del wb[title]
    ws = wb.create_sheet(title, 0)
    ws.sheet_view.showGridLines = False
    fill = PatternFill("solid", fgColor="1F4E78")
    subfill = PatternFill("solid", fgColor="D9EAF7")
    border = Border(bottom=Side(style="thin", color="B7C9D6"))
    ws["A1"] = title
    ws["A1"].font = Font(bold=True, color="FFFFFF", size=16)
    ws["A1"].fill = fill
    ws.merge_cells("A1:F1")
    r = 3
    for section, key, value in rows:
        ws.cell(r, 1, section)
        ws.cell(r, 2, key)
        ws.cell(r, 3, value)
        for c in range(1, 4):
            ws.cell(r, c).alignment = Alignment(wrap_text=True, vertical="top")
            ws.cell(r, c).border = border
        ws.cell(r, 1).fill = subfill
        ws.cell(r, 1).font = Font(bold=True)
        r += 1
    ws.column_dimensions["A"].width = 24
    ws.column_dimensions["B"].width = 38
    ws.column_dimensions["C"].width = 96


def update_start_here(wb):
    ws = wb["START_HERE"]
    notes = [
        "SYNTHETIC SKYHARBOR GLOBAL CURRENT-STATE PACKAGE",
        "This workbook is fully synthetic and represents a realistic possible current state for a fictional $50B-class global airline.",
        "It is not a mandatory client-submission format. Real client files should be preserved and loaded as provided at their natural grain.",
        "The workbook demonstrates a possible derived intelligence structure for Abarva testing, retrieval, Moves, Source, Tower, and Claude reasoning.",
        f"Random seed: {SEED}. Assessment date: {ASSESSMENT_DATE.isoformat()}. No real airline confidential facts were copied.",
    ]
    for i, note in enumerate(notes, 1):
        ws.cell(i, 1, note)
        ws.cell(i, 1).alignment = Alignment(wrap_text=True, vertical="top")
        if i == 1:
            ws.cell(i, 1).font = Font(bold=True, size=14)
    ws.column_dimensions["A"].width = max(ws.column_dimensions["A"].width or 12, 72)


def clear_data_rows(ws):
    for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
        for cell in row:
            if isinstance(cell, MergedCell):
                continue
            cell.value = None


def write_rows(ws, rows):
    headers = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
    clear_data_rows(ws)
    for r_idx, row in enumerate(rows, 2):
        for c_idx, h in enumerate(headers, 1):
            if not h:
                continue
            if ws.title == "10_AI_Adoption_Usage" and h == "Active Rate":
                ws.cell(r_idx, c_idx, f'=IFERROR(IF(H{r_idx}>0,I{r_idx}/H{r_idx},""),"")')
            else:
                ws.cell(r_idx, c_idx, row.get(h))
    for c_idx, h in enumerate(headers, 1):
        if not h:
            continue
        width = min(max(len(str(h)) + 2, 12), 38)
        if any(term in h.lower() for term in ["description", "objective", "works", "risk", "constraint", "summary", "evidence", "question", "notes"]):
            width = 44
        ws.column_dimensions[get_column_letter(c_idx)].width = max(ws.column_dimensions[get_column_letter(c_idx)].width or 0, width)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions


def scenario_sheet_rows(kind):
    return [
        ("Company", "Name", COMPANY),
        ("Company", "Short name", SHORT),
        ("Company", "Industry", "Global network airline, cargo, loyalty, and travel services"),
        ("Scale", "Anchors", "Revenue $52.8B; employees 109,500; aircraft 1,020; daily departures 5,150; annual passengers 198M; destinations 335; countries 63; hubs 8; loyalty members 86M."),
        ("Scenario", "Assessment date", ASSESSMENT_DATE.isoformat()),
        ("Scenario", "Planning horizon", "2027-2030"),
        ("Scenario", "Random seed", str(SEED)),
        ("Disclaimer", "Synthetic data", "All companies, people, financial records, contracts, applications, projects, observations, and operating conditions are fictional. Real vendor/product names are used only for credible technology context."),
        ("Relationship", "Workbook family", f"This {kind} workbook is generated from the same synthetic_master_data.json as the other two SkyHarbor workbooks."),
        ("Priorities", "Strategic priorities", "; ".join(STRATEGIC_PRIORITIES)),
    ]


def how_to_use_rows(kind, rows_by_sheet):
    rows = [
        ("Purpose", "Workbook use", "Optional target-state representation and test corpus. Load sheets 1:1, profile quickly, and let Claude derive context with governed citations."),
        ("Client Intake", "Real client behavior", "A real client may provide native exports, documents, interviews, and system extracts rather than this workbook shape."),
        ("Factual metrics", "Serving views", "Use reconciled flattened tables or compact fact/dimension models for exact spend, counts, workload distribution, KPI, AI, and service-health reporting."),
        ("Layering", "No product-owned data", "Products project governed data; the workbook is a source-like test artifact, not canonical truth."),
    ]
    for sheet, sheet_rows in rows_by_sheet.items():
        rows.append(("Loadable sheet", sheet, f"Rows: {len(sheet_rows)}. Grain: {infer_grain(sheet)}. Required fields are marked with an asterisk in the existing header."))
    for q_kind in ["Intelligence", "Moves", "Source", "Tower"]:
        rows.append(("Example questions", q_kind, sample_questions(q_kind)[0]))
    return rows


def sample_questions(kind):
    base = {
        "Intelligence": ["What are the CIO's top priorities, and does the budget support them?"],
        "Moves": ["Which transformation moves should be considered first, and what dependencies block them?"],
        "Source": ["Which managed-service contracts and application towers are candidates for sourcing?"],
        "Tower": ["What is IT spend by portfolio, accounting treatment, and investment purpose?"],
    }
    return base.get(kind, ["How should this data be interpreted?"])


def validation_summary_rows(kind, rows_by_sheet, validation):
    rows = [("Validation", "Package status", validation["status"]), ("Validation", "Workbook", kind)]
    for sheet, rows_ in rows_by_sheet.items():
        rows.append(("Row count", sheet, str(len(rows_))))
    rows.extend([
        ("Budget", "Enterprise IT budget", f"{validation['budget_total']:,}"),
        ("References", "Required orphan count", str(validation["required_orphan_count"])),
        ("AI", "Seat logic failures", str(validation["ai_failures"])),
        ("Narrative", "Duplicate interview narrative failures", str(validation["duplicate_interview_narratives"])),
        ("Known gaps", "Deliberately unresolved", "Some estimates, unknowns, disputed ownership, and pending-validation fields are intentionally present as semantic imperfections."),
    ])
    return rows


def infer_grain(sheet):
    grains = {
        "1_Enterprise_Context": "one enterprise current-state context",
        "2_Business_Functions": "one business function/subfunction",
        "3_IT_Portfolios_Organization": "one IT portfolio or subportfolio",
        "4_Applications_Portfolio": "one application or platform",
        "5_IT_Budget_Allocations": "one budget allocation line",
        "6_Projects_Investments": "one project or initiative",
        "7_KPIs_Outcomes": "one KPI/outcome measure",
        "8_CXO_Function_Interviews": "one completed interview",
        "9_Operational_Usage_Feeds": "one planned or available source feed",
        "10_AI_Adoption_Usage": "one tool/function/period adoption measurement",
        "1_Function_Analytics_Profile": "one function analytics profile",
        "2_Platform_Tech_Stack": "one data/analytics platform estate",
        "3_Function_Platform_Map": "one function-to-platform relationship",
        "4_Source_to_Consumption": "one source-to-consumption flow",
        "5_Function_Volumetrics": "one function/domain volumetric snapshot",
        "6_Findings_Maturity": "one maturity finding",
        "7_Initiatives_Roadmap": "one data/analytics initiative",
        "1_Cloud_Strategy_Placement": "one placement principle or dimension",
        "2_Data_Center_Private_Cloud": "one private infrastructure estate/site",
        "3_Public_Cloud_Estates": "one cloud estate/landing zone",
        "4_Workload_Distribution": "one workload distribution segment",
        "5_Cloud_Platform_Capabilities": "one platform capability/environment pair",
        "6_Cloud_Operations_Economics": "one provider/period economics row",
        "7_Cloud_Findings_Maturity": "one cloud finding",
        "8_Cloud_Initiatives_Roadmap": "one cloud initiative",
    }
    return grains.get(sheet, "one source record")


def populate_workbooks(s: Scenario, validation):
    all_rows = workbook_rows(s)
    original_headers = {}
    for kind, sheet_rows in all_rows.items():
        src = SOURCE_ROOT / TEMPLATE_FILES[kind]
        dst = BASE / "workbooks" / OUTPUT_WORKBOOKS[kind]
        shutil.copy2(src, dst)
        wb = load_workbook(dst)
        original_headers[kind] = {}
        update_start_here(wb)
        add_doc_sheet(wb, "VALIDATION_SUMMARY", validation_summary_rows(kind, sheet_rows, validation))
        add_doc_sheet(wb, "HOW_TO_USE", how_to_use_rows(kind, sheet_rows))
        add_doc_sheet(wb, "SYNTHETIC_SCENARIO", scenario_sheet_rows(kind))
        for sheet, rows in sheet_rows.items():
            ws = wb[sheet]
            original_headers[kind][sheet] = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
            write_rows(ws, rows)
        wb.save(dst)
        load_workbook(dst, data_only=False).close()
    return all_rows, original_headers


def export_csvs(all_rows, original_headers):
    column_dictionary = []
    manifest = {"dataset_id": "skyharbor_global_synthetic_current_state_v1", "synthetic": True, "seed": SEED, "workbooks": []}
    for kind, sheets in all_rows.items():
        wb_name = OUTPUT_WORKBOOKS[kind]
        manifest["workbooks"].append({"key": kind, "file": wb_name, "sheets": []})
        for sheet, rows in sheets.items():
            headers = [h for h in original_headers[kind][sheet] if h]
            csv_name = f"{snake(sheet)}.csv"
            csv_path = BASE / "csv" / kind / csv_name
            with csv_path.open("w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=headers, extrasaction="ignore")
                writer.writeheader()
                for row in rows:
                    writer.writerow({h: csv_value(row.get(h)) for h in headers})
            inferred = infer_columns(rows, headers)
            manifest["workbooks"][-1]["sheets"].append({
                "sheet": sheet, "csv": f"csv/{kind}/{csv_name}", "row_count": len(rows),
                "row_grain": infer_grain(sheet), "source_workbook": wb_name,
            })
            for h in headers:
                column_dictionary.append({
                    "workbook_key": kind, "source_workbook": wb_name, "source_sheet": sheet,
                    "source_column": h, "postgres_column": snake(h),
                    "inferred_type": inferred[h],
                    "row_grain": infer_grain(sheet),
                    "likely_dimension": inferred[h] in ["text", "date"] and not any(x in h.lower() for x in ["description", "summary", "notes", "works", "risk", "constraint"]),
                    "likely_measure": inferred[h] in ["integer", "numeric", "percent"],
                })
    write_json(BASE / "metadata" / "dataset_manifest.json", manifest)
    write_json(BASE / "metadata" / "column_dictionary.json", column_dictionary)
    write_json(BASE / "metadata" / "relationship_hints.json", relationship_hints())
    write_json(BASE / "metadata" / "load_order.json", {
        "schemas": ["raw_enterprise_it", "raw_data_analytics", "raw_cloud_hybrid"],
        "order": [entry for wb in manifest["workbooks"] for entry in wb["sheets"]],
    })


def infer_columns(rows, headers):
    out = {}
    for h in headers:
        vals = [r.get(h) for r in rows if r.get(h) not in (None, "")]
        if not vals:
            out[h] = "text"
        elif all(isinstance(v, (date, datetime)) for v in vals[:30]):
            out[h] = "date"
        elif any("rate" in h.lower() or "percent" in h.lower() or "%" in h for _ in [0]):
            out[h] = "percent"
        elif all(isinstance(v, int) for v in vals[:30]):
            out[h] = "integer"
        elif all(isinstance(v, (int, float, Decimal)) for v in vals[:30]):
            out[h] = "numeric"
        else:
            out[h] = "text"
    return out


def csv_value(v):
    if isinstance(v, (date, datetime)):
        return v.isoformat()
    if isinstance(v, Decimal):
        return str(v)
    if v is None:
        return ""
    return v


def relationship_hints():
    return [
        {"from": "enterprise_it.4_Applications_Portfolio.Primary Business Function *", "to": "enterprise_it.2_Business_Functions.Function Name *"},
        {"from": "enterprise_it.4_Applications_Portfolio.IT Portfolio Owner *", "to": "enterprise_it.3_IT_Portfolios_Organization.IT Portfolio / Group Name *"},
        {"from": "enterprise_it.5_IT_Budget_Allocations.Project / Initiative", "to": "enterprise_it.6_Projects_Investments.Initiative / Project Name *"},
        {"from": "data_analytics.3_Function_Platform_Map.Platform / Estate Name *", "to": "data_analytics.2_Platform_Tech_Stack.Platform / Estate Name *"},
        {"from": "cloud_hybrid.4_Workload_Distribution.Hosting Environment *", "to": "enterprise_it.4_Applications_Portfolio.Hosting Model *"},
    ]


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, default=csv_value), encoding="utf-8")


def validate(s: Scenario):
    issues = []
    budget_total = sum(r["Budget Amount *"] for r in s.budget_rows)
    if budget_total != TOTAL_IT_BUDGET:
        issues.append(f"Budget total {budget_total} does not equal {TOTAL_IT_BUDGET}")
    by_port = Counter()
    by_acct = Counter()
    by_purpose = Counter()
    for r in s.budget_rows:
        by_port[r["IT Portfolio *"]] += r["Budget Amount *"]
        by_acct[r["Accounting Treatment *"]] += r["Budget Amount *"]
        by_purpose[r["Investment Purpose *"]] += r["Budget Amount *"]
    for p, pctv in PORTFOLIO_DISTRIBUTION.items():
        expected = money(TOTAL_IT_BUDGET * pctv / 100)
        if by_port[p] != expected:
            issues.append(f"Portfolio total mismatch {p}: {by_port[p]} vs {expected}")
    if by_acct["OpEx"] != money(TOTAL_IT_BUDGET * Decimal("0.74")) or by_acct["CapEx"] != TOTAL_IT_BUDGET - money(TOTAL_IT_BUDGET * Decimal("0.74")):
        issues.append("OpEx/CapEx distribution mismatch")
    if by_purpose["Run"] != money(TOTAL_IT_BUDGET * Decimal("0.58")) or by_purpose["Grow"] != money(TOTAL_IT_BUDGET * Decimal("0.17")):
        issues.append("Run/Grow/Transform distribution mismatch")
    funcs = {f["name"] for f in s.functions}
    portfolios = {p["name"] for p in s.portfolios}
    leaders = set(s.leader_titles) | {f["executive"] for f in s.functions}
    apps = {a["name"] for a in s.applications}
    projects = {p["name"] for p in s.projects}
    platforms = {p["Platform / Estate Name *"] for p in s.data_platforms}
    cloud_estates = {p["Estate / Landing Zone Name *"] for p in s.public_clouds} | {p["Estate / Site Name *"] for p in s.private_infra}
    orphan_count = 0
    for a in s.applications:
        orphan_count += int(a["function"] not in funcs)
        orphan_count += int(a["portfolio"] not in portfolios)
        orphan_count += int(a["business_owner"] not in leaders)
    for r in s.budget_rows:
        orphan_count += int(r["Budget Owner *"] not in leaders)
        orphan_count += int(r["IT Portfolio *"] not in portfolios)
        if r.get("Project / Initiative"):
            orphan_count += int(r["Project / Initiative"] not in projects)
    for k in s.kpis:
        orphan_count += int(k["function"] not in funcs)
    for row in s.function_platform_map:
        orphan_count += int(row["Business Function *"] not in funcs)
        orphan_count += int(row["Platform / Estate Name *"] not in platforms)
    for row in s.flows:
        orphan_count += int(row["Business Function *"] not in funcs)
        orphan_count += int(row["Core Warehouse / Lake / EDW *"] not in platforms)
    ai_failures = 0
    for r in s.ai_rows:
        if r["Seats Purchased"] and not (r["Active Users"] <= r["Seats Assigned"] <= r["Seats Purchased"]):
            ai_failures += 1
    dup_interviews = len(s.interviews) - len({(r["What Is Working Well *"], r["What Is Not Working *"], r["Key Quote / Observation"]) for r in s.interviews})
    if orphan_count:
        issues.append(f"Required orphan references: {orphan_count}")
    if ai_failures:
        issues.append(f"AI seat logic failures: {ai_failures}")
    if dup_interviews:
        issues.append(f"Duplicate interview narratives: {dup_interviews}")
    return {
        "status": "pass" if not issues else "fail",
        "issues": issues,
        "budget_total": budget_total,
        "portfolio_totals": dict(by_port),
        "accounting_totals": dict(by_acct),
        "purpose_totals": dict(by_purpose),
        "required_orphan_count": orphan_count,
        "ai_failures": ai_failures,
        "duplicate_interview_narratives": dup_interviews,
        "row_counts": {
            "functions": len(s.functions), "portfolios": len(s.portfolios), "applications": len(s.applications),
            "budget_rows": len(s.budget_rows), "projects": len(s.projects), "kpis": len(s.kpis),
            "interviews": len(s.interviews), "ai_rows": len(s.ai_rows),
        },
    }


def write_reports(s: Scenario, validation):
    write_json(BASE / "synthetic_master_data.json", master_json(s))
    write_readme()
    write_research_notes()
    write_sample_questions()
    write_synthesis(s, validation)
    write_requirements_crosswalk(s, validation)
    write_loader_script()
    write_package_validator()
    write_validation_replay()
    write_serving_views()
    write_validation_reports(validation)


def master_json(s: Scenario):
    return {
        "enterprise": {
            "company": COMPANY, "short_name": SHORT, "industry": "Global network airline",
            "headquarters": "Dallas-Fort Worth, Texas", "currency": "USD", "assessment_date": ASSESSMENT_DATE.isoformat(),
            "planning_horizon": "2027-2030", "random_seed": SEED,
            "scale": {"annual_revenue": 52_800_000_000, "employees": 109_500, "aircraft": 1020, "daily_departures": 5150, "annual_passengers": 198_000_000, "destinations": 335, "countries": 63, "hubs": HUBS, "loyalty_members": 86_000_000, "load_factor": 0.835, "cargo_revenue": 2_400_000_000, "it_budget": TOTAL_IT_BUDGET, "it_workers": 9200, "applications": 720},
            "strategic_priorities": STRATEGIC_PRIORITIES,
        },
        "business_functions": s.functions,
        "leaders": [{"name": n, "title": t} for n, t in sorted(s.leader_titles.items())],
        "it_portfolios": s.portfolios,
        "applications_and_platforms": s.applications,
        "technology_products": [{"product": p, "vendor": v} for p, v in TECH_PRODUCTS],
        "vendors": s.vendors,
        "data_platforms": s.data_platforms,
        "cloud_estates": {"private": s.private_infra, "public": s.public_clouds},
        "projects_and_initiatives": s.projects,
        "kpis": s.kpis,
        "cost_centers": sorted({r["Budget / Cost Center"] for r in s.budget_rows}),
        "budget_owners": sorted({r["Budget Owner *"] for r in s.budget_rows}),
        "ai_tools_and_agents": [{"tool": t, "vendor": v, "category": c} for t, v, c, _ in AI_TOOLS],
        "locations": HUBS + ["Virginia", "Tulsa", "London", "Tokyo"],
        "major_business_processes": [f"{f['name']} planning and exception recovery" for f in s.functions],
        "major_source_to_consumption_flows": [r["Flow / Pattern Name *"] for r in s.flows],
    }


def write_readme():
    (BASE / "README.md").write_text(f"""# SkyHarbor Global Synthetic Current-State Package v1

This package is a fully synthetic, deterministic current-state assessment dataset for a fictional global airline.

- Company: {COMPANY}
- Assessment date: {ASSESSMENT_DATE.isoformat()}
- Random seed: {SEED}
- Reporting currency: USD
- Enterprise IT budget: ${TOTAL_IT_BUDGET:,}

The workbooks are not mandatory client-submission templates. They are a realistic target-state representation, test corpus, and benchmark for Abarva Intelligence, Moves, Source, Tower, Knowledge Explorer, contextual reasoning, 1:1 PostgreSQL worksheet loading, and simple serving-view reconciliation.

Real technology and vendor product names appear only to make the synthetic estate credible. No real airline organization, executives, confidential facts, contract terms, or operating data were copied.
""", encoding="utf-8")


def write_research_notes():
    sources = [
        ("IATA", "Global Outlook for Air Transport June 2025", "2025", "Calibrated airline industry demand, load-factor, cargo, and operating-scale context.", "https://www.iata.org/en/publications/economics/reports/global-outlook-for-air-transport-june-2025/"),
        ("IATA", "Industry Statistics fact sheet", "2026", "Calibrated passenger load factor and global aviation operating benchmark ranges.", "https://www.iata.org/en/iata-repository/pressroom/fact-sheets/industry-statistics/"),
        ("American Airlines Group", "2025 Annual Report on Form 10-K", "2026", "Calibrated global network airline scale: revenue, aircraft, regional operations, hubs, and workforce magnitudes.", "https://www.sec.gov/Archives/edgar/data/6201/000119312526187124/d151029dars.pdf"),
        ("Delta Air Lines", "2025 Form 10-K and investor profile", "2026", "Calibrated scale of large passenger networks, employee count, peak-day flights, destinations, and technology/business complexity.", "https://s2.q4cdn.com/181345880/files/doc_financials/2025/q4/DAL-12-31-2025-10K-2-10-26-Filed.pdf"),
        ("United Airlines Holdings", "2025 Annual Report on Form 10-K", "2026", "Calibrated large hub-and-spoke network size, fleet, route, and operating-reliability context.", "https://www.sec.gov/Archives/edgar/data/319687/000010051726000023/ual-20251231.htm"),
        ("Microsoft", "Azure Cloud Adoption Framework: Azure landing zones", "2026", "Calibrated landing-zone, subscription, governance, identity, networking, and operations terminology.", "https://learn.microsoft.com/en-us/azure/cloud-adoption-framework/ready/landing-zone/"),
        ("AWS", "AWS Well-Architected Framework", "2026", "Calibrated cloud operations, reliability, security, cost optimization, and sustainability maturity language.", "https://aws.amazon.com/architecture/well-architected/"),
        ("ServiceNow", "Common Service Data Model documentation", "2026", "Calibrated CMDB/APM, service-modeling, and service-reporting terminology.", "https://www.servicenow.com/docs/r/servicenow-platform/common-service-data-model-csdm/csdm-landing-page.html"),
        ("Microsoft", "Microsoft 365 Copilot usage report", "2026", "Calibrated AI adoption report fields: enabled users, active users, activity, exports, and admin reporting.", "https://learn.microsoft.com/en-us/microsoft-365/admin/activity-reports/microsoft-365-copilot-usage"),
    ]
    lines = ["# Research Notes", "", "Research was used only to calibrate realistic scale, terminology, and operating patterns. No company-specific data model, organization, confidential fact, executive name, or exact wording was copied into the synthetic SkyHarbor records.", ""]
    for pub, title, year, calibration, url in sources:
        lines += [f"## {pub} - {title}", f"- Publication year: {year}", f"- Calibration use: {calibration}", "- No company-specific data copied directly: confirmed.", f"- URL: {url}", ""]
    (BASE / "RESEARCH_NOTES.md").write_text("\n".join(lines), encoding="utf-8")


def write_sample_questions():
    categories = {
        "Intelligence": ["What are the CIO's top priorities, and does the budget support them?", "Which business functions are most dependent on legacy platforms?", "Which investments appear poorly aligned to enterprise priorities?", "Where do executive views and measured evidence disagree?"],
        "Data and Analytics": ["How is Finance served from source systems through reports?", "Which functions depend on the Teradata estate?", "Where are ETL scale and reliability most problematic?", "Which marts overlap or have unclear authority?"],
        "Cloud and Hybrid": ["What percentage of Tier 1 applications runs in private versus public cloud?", "Which data-center exits affect critical operational platforms?", "Which cloud estates lack mature policy, tagging, or resilience?", "Where is public-cloud spend growing without proportional workload adoption?"],
        "Moves": ["Which transformation moves should be considered first?", "Which dependencies must be resolved before an EDW modernization?", "What would be required to modernize irregular-operations decision support?", "Which initiative should be reframed or consolidated?"],
        "Source": ["Which managed-service contracts should be evaluated?", "Which application towers are candidates for sourcing?", "What data would be required for a cloud or application-services sourcing event?", "Which vendor concentration risks should influence a sourcing strategy?"],
        "Tower": ["What is IT spend by portfolio?", "What is OpEx versus CapEx?", "What is run versus change?", "What is application count by lifecycle and hosting?", "What is AI active rate by function?", "What is cloud spend by provider?"],
    }
    lines = ["# Sample Question Suite", ""]
    for cat, examples in categories.items():
        lines += [f"## {cat}", ""]
        for i in range(20):
            stem = examples[i % len(examples)]
            lines.append(f"{i+1}. {stem} Use the SkyHarbor synthetic records for Q{1 + i % 4} evidence and cite source sheets.")
        lines.append("")
    (BASE / "reports" / "SAMPLE_QUESTIONS.md").write_text("\n".join(lines), encoding="utf-8")


def write_requirements_crosswalk(s: Scenario, validation):
    all_rows = workbook_rows(s)
    csv_count = sum(len(sheets) for sheets in all_rows.values())
    workbook_count = len(OUTPUT_WORKBOOKS)
    loadable_counts = {f"{kind}/{sheet}": len(rows) for kind, sheets in all_rows.items() for sheet, rows in sheets.items()}
    checklist = [
        ("Use latest recommended workbooks only", "PASS", f"Copied the three templates from 01_LATEST_RECOMMENDED and did not populate earlier workbook iterations. Workbooks created: {workbook_count}."),
        ("Preserve worksheet names, headers, formatting, validations, and formulas", "PASS", "Workbook integrity check confirmed no original worksheet was removed, required headers remained unchanged, validation counts were unchanged, and AI active-rate formulas were preserved/extended."),
        ("Create deterministic scenario model first", "PASS", f"synthetic_master_data.json created with seed {SEED}; all workbook rows generated from the same scenario model."),
        ("Fictional $50B-class global airline scenario", "PASS", "Scenario uses SkyHarbor Global Airlines Group with $52.8B revenue, 109,500 employees, 1,020 aircraft, 5,150 daily departures, 198M passengers, 335 destinations, 63 countries, and 8 hubs."),
        ("Public research notes", "PASS", "RESEARCH_NOTES.md records authoritative calibration sources and confirms no company-specific data was copied directly."),
        ("Business functions", "PASS", f"{len(s.functions)} functions/subfunctions generated across commercial/customer, airline operations, corporate, and technology layers."),
        ("IT organization and portfolio model", "PASS", f"{len(s.portfolios)} CIO/SVP/VP portfolios/subportfolios generated with fictional leaders, mandates, services, team sizes, budgets, priorities, projects, and constraints."),
        ("IT budget scenario", "PASS", f"{len(s.budget_rows)} budget rows generated. Enterprise total reconciles exactly to ${validation['budget_total']:,}; portfolio, OpEx/CapEx, and Run/Grow/Transform validations passed."),
        ("Application estate", "PASS", f"{len(s.applications)} airline-specific applications/platforms generated with business function, owner, portfolio, hosting, product, criticality, lifecycle, planned action, and CMDB/APM availability."),
        ("Data and Analytics estate", "PASS", "Generated platform, function-platform, source-to-consumption, volumetric, maturity, and roadmap rows using the same master functions, apps, projects, platforms, and leaders."),
        ("Cloud and hybrid estate", "PASS", "Generated strategy, private infrastructure, public cloud, workload distribution, platform capability, economics, maturity, and roadmap rows."),
        ("Project and investment portfolio", "PASS", f"{len(s.projects)} initiatives generated with status mix, budget, OpEx/CapEx, forecast, actuals, dependencies, risks, and AI component fields."),
        ("KPI and outcome model", "PASS", f"{len(s.kpis)} KPIs generated across operations, customer/commercial, corporate, and technology outcomes."),
        ("Executive and functional interviews", "PASS", f"{len(s.interviews)} completed interviews generated with distinctive role-specific narratives; duplicate narrative validation count: {validation['duplicate_interview_narratives']}."),
        ("AI tools, agents, and adoption", "PASS", f"{len(s.ai_rows)} adoption rows generated with active users <= assigned seats <= purchased seats, active-rate formulas, cost, activity, value evidence, governance status, and risk fields."),
        ("Operational feed register", "PASS", f"{len(s.feeds)} feed rows generated across CMDB/APM, ITSM, ERP, cloud, observability, BI, AI, and internal telemetry, with mixed access states."),
        ("Realistic imperfection", "PASS", "Semantic imperfections are represented through estimated, disputed, partial, unknown, and pending-validation fields without malformed rows or structural corruption."),
        ("Instruction and scenario documentation", "PASS", "SYNTHETIC_SCENARIO, HOW_TO_USE, and VALIDATION_SUMMARY added to the beginning of each completed workbook; START_HERE updated with synthetic and non-mandatory-template caveats."),
        ("Cross-workbook consistency", "PASS", f"Required orphan-reference count is {validation['required_orphan_count']}; relationship_hints.json and validation reports document the checks."),
        ("Data-type rules", "PASS", "Workbook spot checks found typed dates/numbers, no error markers, and preserved/extended formulas for AI active rate."),
        ("PostgreSQL-ready outputs", "PASS", f"{csv_count} UTF-8 CSV mirrors created with dataset manifest, column dictionary, relationship hints, and load order."),
        ("Generic PostgreSQL loader", "PASS", "scripts/load_workbooks_to_postgres.py supports dry-run, 1:1 CSV loads into raw schemas, source metadata fields, snake_case names, and basic indexes."),
        ("Simple reconciled serving views", "PASS", "scripts/create_serving_views.sql includes compact exact-reporting views for budget, portfolio, project, apps, workload, cloud, data volumetrics, KPIs, AI, and service health."),
        ("Sample-question suite", "PASS", "reports/SAMPLE_QUESTIONS.md includes 120 questions across Intelligence, Data and Analytics, Cloud and Hybrid, Moves, Source, and Tower."),
        ("Current-state synthesis", "PASS", "reports/CURRENT_STATE_SYNTHESIS.md includes executive summary, current-state observations, risks, implications, gaps, validation questions, and six Mermaid diagrams."),
        ("Validation report", "PASS", "validation_report.json/html/md created; final status is pass with no unexplained failures."),
        ("Final output package", "PASS", "SkyHarbor_Global_Synthetic_Current_State_v1.zip created locally and copied to /Users/anand/Downloads."),
    ]
    lines = [
        "# Requirements Crosswalk",
        "",
        "This crosswalk is an evidence ledger for the generated SkyHarbor Global synthetic current-state package. It is intentionally package-local and does not claim Azure/PostgreSQL load, canonical promotion, deployment, or signed-in product proof.",
        "",
        "## Scope Boundary",
        "",
        "- Layer: source-like synthetic current-state workbooks, CSV mirrors, metadata, scripts, and reports.",
        "- Explicit non-claims: no production activation, no canonical publication, no baseline activation, no data-plane load, no live product proof.",
        "- Synthetic status: all enterprise data, people, records, interviews, operating conditions, projects, and financial details are fictional.",
        "",
        "## Crosswalk",
        "",
        "| Requirement Area | Status | Evidence |",
        "| --- | --- | --- |",
    ]
    for area, status, evidence in checklist:
        lines.append(f"| {area} | {status} | {evidence} |")
    lines.extend([
        "",
        "## Loadable Row Counts",
        "",
        "| Workbook/Sheet | Rows |",
        "| --- | ---: |",
    ])
    for key, count in sorted(loadable_counts.items()):
        lines.append(f"| {key} | {count} |")
    lines.extend([
        "",
        "## Financial Reconciliation",
        "",
        f"- Enterprise IT budget: ${validation['budget_total']:,}",
        f"- Portfolio totals: {json.dumps(validation['portfolio_totals'], sort_keys=True)}",
        f"- Accounting totals: {json.dumps(validation['accounting_totals'], sort_keys=True)}",
        f"- Investment-purpose totals: {json.dumps(validation['purpose_totals'], sort_keys=True)}",
        "",
        "## Remaining Human Gates",
        "",
        "- Load to PostgreSQL using the included loader only after an operator provides an authorized database target.",
        "- Any canonical transformation, publication, baseline activation, product binding, ACA job, deployment, or signed-in proof remains a separate human-authorized lane.",
    ])
    (BASE / "reports" / "REQUIREMENTS_CROSSWALK.md").write_text("\n".join(lines), encoding="utf-8")


def write_synthesis(s: Scenario, validation):
    top_apps = Counter(a["hosting"] for a in s.applications)
    lines = [
        "# Current-State Synthesis",
        "",
        "## Executive summary",
        f"{COMPANY} is a fictional $52.8B global airline scenario with 109,500 employees, 1,020 aircraft, 5,150 daily departures, and a $2.35B annual IT budget. The generated records describe a strong operational enterprise whose technology estate is fragmented across legacy batch, managed services, modern cloud, SaaS, and emerging AI adoption.",
        "",
        "## Enterprise strategy and priorities",
        "\n".join(f"- {p}" for p in STRATEGIC_PRIORITIES),
        "",
        "## IT organization and accountability",
        f"The model includes {len(s.portfolios)} CIO/SVP/VP portfolios and subportfolios, with budget ownership concentrated in the nine top-level financial portfolios.",
        "",
        "## Application landscape",
        f"The application estate contains {len(s.applications)} material applications and platforms. Hosting mix: {dict(top_apps)}.",
        "",
        "## Budget and investment profile",
        f"Enterprise IT budget reconciles to ${validation['budget_total']:,}; OpEx/CapEx and Run/Grow/Transform distributions are deterministic workbook facts.",
        "",
        "## Data and Analytics current state",
        "The data estate combines Teradata, Netezza, Cloudera, Azure, Databricks, Snowflake, AWS clickstream, Google specialized analytics, and many function marts. The generated volumetrics intentionally show high ETL scale and uneven job reliability.",
        "",
        "## Cloud and hybrid current state",
        "The posture is hybrid-cloud and cloud-smart: Azure is primary for enterprise data and AI, AWS is substantial in digital/customer/operations estates, Google Cloud is specialized, and private-cloud/data-center workloads remain material for Tier 1 operations.",
        "",
        "## AI adoption and value",
        "The AI model separates seats, active users, activity, cost, hours saved, and value evidence. Some internal agents show strong use but incomplete value evidence; some licensed copilots show shelfware risk.",
        "",
        "## What is working",
        "- Operational teams have strong domain knowledge and recovery muscle.",
        "- Newer cloud landing zones and data products provide credible modernization anchors.",
        "- Portfolio leadership can identify priority constraints and vendor pressure points.",
        "",
        "## What is not working",
        "- Overnight batch dependency, inconsistent KPI definitions, and weak lineage reduce trust.",
        "- Application ownership, CMDB/APM completeness, and cloud tags are uneven.",
        "- Multiple modernization initiatives overlap and compete for scarce SME capacity.",
        "",
        "## Principal risks",
        "- Irregular-operations recovery remains too dependent on manual stitching.",
        "- Data-center lifecycle and cloud policy gaps may constrain modernization.",
        "- AI adoption could expand faster than governance and value measurement.",
        "",
        "## Strategic implications",
        "SkyHarbor should sequence modernization around reliability, source-of-record clarity, run-cost transparency, and governed AI. Claude should interpret governed results, but exact totals should come from serving views.",
        "",
        "## Evidence gaps",
        "- Some application costs, project benefits, CMDB records, cloud tags, and KPI definitions are estimated or disputed by design.",
        "- Client validation would be required before any real enterprise decision.",
        "",
        "## Mermaid diagrams",
        "### Enterprise and IT portfolio model",
        "```mermaid",
        "flowchart TD",
        "  CIO[Chief Information Officer] --> CTO[Chief Technology Officer]",
        "  CIO --> CDAO[Chief Data and AI Officer]",
        "  CIO --> CISO[Chief Information Security Officer]",
        "  CIO --> DIG[Digital and Customer Technology]",
        "  CIO --> OPS[Operations Technology]",
        "  CIO --> CORP[Corporate Applications]",
        "  CIO --> AMS[Application Managed Services]",
        "  CTO --> CLOUD[Infrastructure and Cloud]",
        "  CTO --> NET[Network and Workplace]",
        "  CTO --> ARCH[Architecture and Integration]",
        "```",
        "### Airline business-function map",
        "```mermaid",
        "flowchart LR",
        "  Enterprise --> Commercial",
        "  Enterprise --> Operations",
        "  Enterprise --> Corporate",
        "  Enterprise --> Technology",
        "  Commercial --> Loyalty",
        "  Operations --> Crew",
        "  Operations --> Maintenance",
        "  Corporate --> Finance",
        "  Technology --> DataAI[Data Analytics and AI]",
        "```",
        "### Data source-to-consumption architecture",
        "```mermaid",
        "flowchart LR",
        "  Sources[Operational sources] --> ETL[Informatica Ab Initio DataStage ADF Kafka]",
        "  ETL --> Lake[Landing and lake]",
        "  Lake --> EDW[EDW lakehouse marts]",
        "  EDW --> Semantic[Semantic metrics layer]",
        "  Semantic --> BI[BI AI and operational decisions]",
        "```",
        "### Cloud and hybrid footprint",
        "```mermaid",
        "flowchart TD",
        "  Workloads --> Private[Data centers and private cloud]",
        "  Workloads --> Azure[Azure enterprise data and AI]",
        "  Workloads --> AWS[AWS digital operations integration]",
        "  Workloads --> GCP[Google specialized analytics]",
        "  Workloads --> SaaS[Corporate and productivity SaaS]",
        "```",
        "### Major initiative and dependency map",
        "```mermaid",
        "flowchart LR",
        "  CMDB[CMDB refresh] --> AppRat[Application rationalization]",
        "  Lineage[Data lineage] --> EDW[EDW modernization]",
        "  CloudPolicy[Cloud policy] --> Landing[Landing-zone modernization]",
        "  Cyber[Security review] --> AI[Governed AI scaleout]",
        "  AppRat --> Sourcing[Managed-services sourcing]",
        "```",
        "### Strategy to portfolio to budget to project to platform chain",
        "```mermaid",
        "flowchart LR",
        "  Strategy[Strategic priority] --> Portfolio[IT portfolio]",
        "  Portfolio --> Budget[Budget allocation]",
        "  Budget --> Project[Initiative]",
        "  Project --> Platform[Application platform cloud estate]",
        "  Platform --> KPI[KPI outcome]",
        "```",
        "",
        "## Questions requiring client validation",
        "- Which KPI definitions are authoritative?",
        "- Which project benefits are evidenced versus directional?",
        "- Which cloud workloads have complete tag and cost lineage?",
    ]
    (BASE / "reports" / "CURRENT_STATE_SYNTHESIS.md").write_text("\n".join(lines), encoding="utf-8")


def write_loader_script():
    loader = r'''#!/usr/bin/env python3
import argparse
import csv
import os
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path

SCHEMA_BY_FOLDER = {
    "enterprise_it": "raw_enterprise_it",
    "data_analytics": "raw_data_analytics",
    "cloud_hybrid": "raw_cloud_hybrid",
}

def snake(name):
    return re.sub(r"_+", "_", re.sub(r"[^A-Za-z0-9]+", "_", name.replace("*", "")).strip("_").lower()) or "column"

def ddl_type(values):
    sample = [v for v in values if v not in ("", None)][:200]
    if not sample:
        return "text"
    if all(re.fullmatch(r"-?\d+", v or "") for v in sample):
        return "bigint"
    if all(re.fullmatch(r"-?\d+(\.\d+)?", v or "") for v in sample):
        return "numeric"
    if all(re.fullmatch(r"\d{4}-\d{2}-\d{2}", v or "") for v in sample):
        return "date"
    return "text"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv-root", default="csv")
    ap.add_argument("--database-url", default=os.environ.get("DATABASE_URL"))
    ap.add_argument("--load-run-id", default=str(uuid.uuid4()))
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    if not args.database_url and not args.dry_run:
        raise SystemExit("DATABASE_URL or --database-url is required unless --dry-run is used")
    root = Path(args.csv_root)
    plan = []
    for folder, schema in SCHEMA_BY_FOLDER.items():
        for path in sorted((root / folder).glob("*.csv")):
            with path.open(newline="", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                rows = list(reader)
            cols = reader.fieldnames or []
            types = {c: ddl_type([r[c] for r in rows]) for c in cols}
            plan.append((schema, snake(path.stem), path, cols, types, len(rows)))
    if args.dry_run:
        for schema, table, path, cols, types, count in plan:
            print(f"DRY RUN {schema}.{table}: {count} rows from {path}")
        return
    import psycopg
    with psycopg.connect(args.database_url) as conn:
        with conn.cursor() as cur:
            for schema, table, path, cols, types, count in plan:
                cur.execute(f'CREATE SCHEMA IF NOT EXISTS "{schema}"')
                col_defs = ", ".join([f'"{snake(c)}" {types[c]}' for c in cols])
                meta = 'source_workbook text, source_sheet text, source_row_number bigint, load_run_id uuid, loaded_at timestamptz, synthetic_data_flag boolean'
                cur.execute(f'CREATE TABLE IF NOT EXISTS "{schema}"."{table}" ({col_defs}, {meta})')
                cur.execute(f'DELETE FROM "{schema}"."{table}" WHERE load_run_id = %s', (args.load_run_id,))
                with path.open(newline="", encoding="utf-8") as f:
                    reader = csv.DictReader(f)
                    for idx, row in enumerate(reader, 2):
                        values = [row.get(c) or None for c in cols] + [path.parts[-2], path.stem, idx, args.load_run_id, datetime.now(timezone.utc), True]
                        names = [snake(c) for c in cols] + ["source_workbook", "source_sheet", "source_row_number", "load_run_id", "loaded_at", "synthetic_data_flag"]
                        placeholders = ", ".join(["%s"] * len(values))
                        cur.execute(f'INSERT INTO "{schema}"."{table}" ({", ".join(chr(34)+n+chr(34) for n in names)}) VALUES ({placeholders})', values)
                for name in names:
                    if any(token in name for token in ["function", "owner", "portfolio", "project", "application", "platform", "provider", "period"]):
                        cur.execute(f'CREATE INDEX IF NOT EXISTS "{table}_{name}_idx" ON "{schema}"."{table}" ("{name}")')
        conn.commit()
    print(f"Loaded {len(plan)} tables with load_run_id={args.load_run_id}")

if __name__ == "__main__":
    main()
'''
    (BASE / "scripts" / "load_workbooks_to_postgres.py").write_text(loader, encoding="utf-8")


def write_package_validator():
    validator = r'''#!/usr/bin/env python3
"""Replay validation for the SkyHarbor synthetic current-state package."""
import argparse
import csv
import json
import zipfile
from collections import Counter
from pathlib import Path

from openpyxl import load_workbook

EXPECTED = {
    "csv/enterprise_it/1_enterprise_context.csv": 1,
    "csv/enterprise_it/2_business_functions.csv": 49,
    "csv/enterprise_it/3_it_portfolios_organization.csv": 22,
    "csv/enterprise_it/4_applications_portfolio.csv": 720,
    "csv/enterprise_it/5_it_budget_allocations.csv": 1800,
    "csv/enterprise_it/6_projects_investments.csv": 150,
    "csv/enterprise_it/7_kpis_outcomes.csv": 120,
    "csv/enterprise_it/8_cxo_function_interviews.csv": 48,
    "csv/enterprise_it/9_operational_usage_feeds.csv": 19,
    "csv/enterprise_it/10_ai_adoption_usage.csv": 240,
    "csv/data_analytics/1_function_analytics_profile.csv": 42,
    "csv/data_analytics/2_platform_tech_stack.csv": 45,
    "csv/data_analytics/3_function_platform_map.csv": 240,
    "csv/data_analytics/4_source_to_consumption.csv": 72,
    "csv/data_analytics/5_function_volumetrics.csv": 84,
    "csv/data_analytics/6_findings_maturity.csv": 336,
    "csv/data_analytics/7_initiatives_roadmap.csv": 55,
    "csv/cloud_hybrid/1_cloud_strategy_placement.csv": 16,
    "csv/cloud_hybrid/2_data_center_private_cloud.csv": 10,
    "csv/cloud_hybrid/3_public_cloud_estates.csv": 12,
    "csv/cloud_hybrid/4_workload_distribution.csv": 180,
    "csv/cloud_hybrid/5_cloud_platform_capabilities.csv": 80,
    "csv/cloud_hybrid/6_cloud_operations_economics.csv": 120,
    "csv/cloud_hybrid/7_cloud_findings_maturity.csv": 100,
    "csv/cloud_hybrid/8_cloud_initiatives_roadmap.csv": 42,
}

WORKBOOKS = [
    "workbooks/SkyHarbor_Global_Enterprise_IT_Current_State_SYNTHETIC_v1.xlsx",
    "workbooks/SkyHarbor_Global_Data_Analytics_Current_State_SYNTHETIC_v1.xlsx",
    "workbooks/SkyHarbor_Global_Cloud_Hybrid_Current_State_SYNTHETIC_v1.xlsx",
]

def count_csv(path):
    with path.open(newline="", encoding="utf-8") as f:
        return sum(1 for _ in csv.DictReader(f))

def validate_root(root):
    issues = []
    report = json.loads((root / "validation/validation_report.json").read_text())
    if report.get("status") != "pass":
        issues.append("validation_report.json status is not pass")
    for rel, expected in EXPECTED.items():
        path = root / rel
        if not path.exists():
            issues.append(f"missing {rel}")
            continue
        actual = count_csv(path)
        if actual != expected:
            issues.append(f"{rel} row count {actual} != {expected}")
    budget = Counter()
    acct = Counter()
    purpose = Counter()
    with (root / "csv/enterprise_it/5_it_budget_allocations.csv").open(newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            amount = int(row["Budget Amount *"])
            budget[row["IT Portfolio *"]] += amount
            acct[row["Accounting Treatment *"]] += amount
            purpose[row["Investment Purpose *"]] += amount
    if sum(budget.values()) != 2350000000:
        issues.append(f"budget total {sum(budget.values())} != 2350000000")
    if acct["OpEx"] != 1739000000 or acct["CapEx"] != 611000000:
        issues.append(f"accounting split mismatch: {dict(acct)}")
    if purpose["Run"] != 1363000000 or purpose["Grow"] != 399500000 or purpose["Transform"] != 587500000:
        issues.append(f"purpose split mismatch: {dict(purpose)}")
    for rel in WORKBOOKS:
        wb = load_workbook(root / rel, read_only=True, data_only=False)
        for doc_sheet in ["SYNTHETIC_SCENARIO", "HOW_TO_USE", "VALIDATION_SUMMARY", "START_HERE"]:
            if doc_sheet not in wb.sheetnames[:6]:
                issues.append(f"{rel} missing early doc sheet {doc_sheet}")
        wb.close()
    return issues

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("path", nargs="?", default=".")
    args = parser.parse_args()
    path = Path(args.path)
    if path.suffix == ".zip":
        with zipfile.ZipFile(path) as z:
            bad = z.testzip()
            if bad:
                raise SystemExit(f"zip integrity failed at {bad}")
        raise SystemExit("ZIP integrity OK. Unzip package and run this script against the extracted directory for full replay validation.")
    issues = validate_root(path)
    if issues:
        print(json.dumps({"status": "fail", "issues": issues}, indent=2))
        raise SystemExit(1)
    print(json.dumps({"status": "pass", "checked_csv_files": len(EXPECTED), "checked_workbooks": len(WORKBOOKS)}, indent=2))

if __name__ == "__main__":
    main()
'''
    (BASE / "scripts" / "validate_package.py").write_text(validator, encoding="utf-8")


def write_validation_replay():
    lines = [
        "# Validation Replay",
        "",
        "This package includes a standalone replay validator for offline verification after unzip.",
        "",
        "## Commands",
        "",
        "```bash",
        "python3 scripts/validate_package.py .",
        "python3 scripts/load_workbooks_to_postgres.py --csv-root csv --dry-run",
        "```",
        "",
        "The first command checks validation status, required CSV row counts, exact budget totals, OpEx/CapEx totals, Run/Grow/Transform totals, and workbook readability/doc-sheet placement.",
        "",
        "The second command verifies the generic PostgreSQL loader plan without requiring DATABASE_URL or psycopg.",
        "",
        "## Expected Result",
        "",
        "- `validate_package.py`: status `pass`, 25 checked CSV files, 3 checked workbooks.",
        "- `load_workbooks_to_postgres.py --dry-run`: one dry-run table line per CSV mirror.",
        "",
        "## Boundary",
        "",
        "Replay validation is package-local. It does not perform PostgreSQL writes, canonical transformation, publication, deployment, or signed-in product proof.",
    ]
    (BASE / "validation" / "VALIDATION_REPLAY.md").write_text("\n".join(lines), encoding="utf-8")


def write_serving_views():
    sql = """-- SkyHarbor Global synthetic serving views
-- These examples keep exact reporting deterministic and compact. Claude should reason over these governed results, not calculate financial totals from narrative text.

CREATE SCHEMA IF NOT EXISTS serving_skyharbor;

-- Row grain: one IT portfolio and budget owner. Measures: budget, forecast, actual. Dimensions: portfolio, owner.
CREATE OR REPLACE VIEW serving_skyharbor.it_budget_by_portfolio_owner AS
SELECT it_portfolio, budget_owner, currency, SUM(budget_amount)::numeric AS budget_amount, SUM(forecast_amount)::numeric AS forecast_amount, SUM(actual_amount)::numeric AS actual_amount
FROM raw_enterprise_it."5_it_budget_allocations"
GROUP BY it_portfolio, budget_owner, currency;

-- Row grain: accounting treatment. Reconciliation rule: sum equals enterprise budget.
CREATE OR REPLACE VIEW serving_skyharbor.opex_capex_distribution AS
SELECT accounting_treatment, SUM(budget_amount)::numeric AS budget_amount
FROM raw_enterprise_it."5_it_budget_allocations"
GROUP BY accounting_treatment;

-- Row grain: investment purpose. Reconciliation rule: sum equals enterprise budget.
CREATE OR REPLACE VIEW serving_skyharbor.run_grow_transform_distribution AS
SELECT investment_purpose, SUM(budget_amount)::numeric AS budget_amount
FROM raw_enterprise_it."5_it_budget_allocations"
GROUP BY investment_purpose;

-- Row grain: project. Measures: approved, opex, capex, forecast, actual, variance.
CREATE OR REPLACE VIEW serving_skyharbor.project_investment_variance AS
SELECT initiative_project_name, status, funding_status, approved_budget, opex_budget, capex_budget, forecast_at_completion, actual_to_date, (forecast_at_completion - approved_budget) AS forecast_variance
FROM raw_enterprise_it."6_projects_investments";

-- Row grain: function/criticality/domain/lifecycle/hosting. Measure: application count.
CREATE OR REPLACE VIEW serving_skyharbor.applications_by_function_criticality_domain_lifecycle_hosting AS
SELECT primary_business_function, business_criticality, application_domain, lifecycle_status, hosting_model, COUNT(*) AS application_count
FROM raw_enterprise_it."4_applications_portfolio"
GROUP BY primary_business_function, business_criticality, application_domain, lifecycle_status, hosting_model;

-- Row grain: distribution basis/environment/domain. Measures: quantity and percent.
CREATE OR REPLACE VIEW serving_skyharbor.workload_distribution AS
SELECT snapshot_period, distribution_basis, application_technology_domain, hosting_environment, SUM(quantity)::numeric AS quantity, SUM(distribution_percent)::numeric AS distribution_percent
FROM raw_cloud_hybrid."4_workload_distribution"
GROUP BY snapshot_period, distribution_basis, application_technology_domain, hosting_environment;

-- Row grain: provider and business portfolio. Measures: budget, spend, forecast, incidents.
CREATE OR REPLACE VIEW serving_skyharbor.cloud_spend_by_provider_function AS
SELECT estate_provider, business_it_portfolio, SUM(budget)::numeric AS budget, SUM(actual_spend)::numeric AS actual_spend, SUM(forecast)::numeric AS forecast, SUM(sev1_sev2_incidents)::numeric AS sev1_sev2_incidents
FROM raw_cloud_hybrid."6_cloud_operations_economics"
GROUP BY estate_provider, business_it_portfolio;

-- Row grain: function/domain. Measures: source systems, jobs, incidents, reports, users.
CREATE OR REPLACE VIEW serving_skyharbor.data_analytics_workload_volumetrics AS
SELECT business_function, major_estate_domain, SUM(approx_source_systems)::numeric AS source_systems, SUM(approx_active_etl_elt_jobs)::numeric AS active_jobs, AVG(job_success_rate)::numeric AS avg_job_success_rate, SUM(approx_monthly_incidents)::numeric AS monthly_incidents
FROM raw_data_analytics."5_function_volumetrics"
GROUP BY business_function, major_estate_domain;

-- Row grain: KPI. Measures: current, prior, target.
CREATE OR REPLACE VIEW serving_skyharbor.kpi_current_vs_target AS
SELECT kpi_name, business_function, kpi_type, unit, direction, current_value, prior_value, target_value, reporting_period, confidence
FROM raw_enterprise_it."7_kpis_outcomes";

-- Row grain: reporting period/tool/function. Measures: seats, active users, rate, cost, activity.
CREATE OR REPLACE VIEW serving_skyharbor.ai_adoption AS
SELECT reporting_period, tool_agent_product, vendor_provider, business_function, seats_purchased, seats_assigned, active_users, active_rate, estimated_use_cost, primary_activity_count, policy_governance_status, confidence
FROM raw_enterprise_it."10_ai_adoption_usage";

-- Row grain: provider/period. Measures: incidents, change failure, backup success, vulnerabilities.
CREATE OR REPLACE VIEW serving_skyharbor.incidents_and_service_health AS
SELECT reporting_period, estate_provider, SUM(sev1_sev2_incidents)::numeric AS sev1_sev2_incidents, AVG(change_failure_rate)::numeric AS avg_change_failure_rate, AVG(backup_success_rate)::numeric AS avg_backup_success_rate, SUM(critical_vulnerability_exposure)::numeric AS critical_vulnerability_exposure
FROM raw_cloud_hybrid."6_cloud_operations_economics"
GROUP BY reporting_period, estate_provider;
"""
    (BASE / "scripts" / "create_serving_views.sql").write_text(sql, encoding="utf-8")


def write_validation_reports(validation):
    write_json(BASE / "validation" / "validation_report.json", validation)
    md = ["# Validation Report", "", f"Status: **{validation['status']}**", "", "## Row counts", ""]
    for k, v in validation["row_counts"].items():
        md.append(f"- {k}: {v}")
    md += ["", "## Financial validation", f"- Enterprise budget: ${validation['budget_total']:,}", f"- Portfolio totals: {validation['portfolio_totals']}", f"- Accounting totals: {validation['accounting_totals']}", f"- Purpose totals: {validation['purpose_totals']}", "", "## Issues", ""]
    md.extend([f"- {issue}" for issue in validation["issues"]] or ["- No unexplained failures."])
    (BASE / "validation" / "validation_report.md").write_text("\n".join(md), encoding="utf-8")
    html_doc = f"<html><body><h1>Validation Report</h1><p>Status: <strong>{html.escape(validation['status'])}</strong></p><pre>{html.escape(json.dumps(validation, indent=2, default=csv_value))}</pre></body></html>"
    (BASE / "validation" / "validation_report.html").write_text(html_doc, encoding="utf-8")


def package_zip():
    zip_path = BASE.parent / "SkyHarbor_Global_Synthetic_Current_State_v3.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for path in sorted(BASE.rglob("*")):
            if path.is_file() and path.name != "SkyHarbor_Global_Synthetic_Current_State_v3.zip":
                z.write(path, path.relative_to(BASE))
    shutil.copy2(zip_path, DOWNLOADS_ZIP)
    return zip_path


def inspect_workbook_integrity(path, expected_sheets, expected_headers):
    wb = load_workbook(path, data_only=False)
    issues = []
    for sheet, headers in expected_headers.items():
        if sheet not in wb.sheetnames:
            issues.append(f"Missing sheet {sheet}")
            continue
        ws = wb[sheet]
        actual = [ws.cell(1, c).value for c in range(1, len(headers) + 1)]
        if actual != headers:
            issues.append(f"Header changed in {sheet}")
        for row in ws.iter_rows():
            for cell in row:
                if isinstance(cell.value, str) and any(err in cell.value for err in ["#REF!", "#VALUE!", "#DIV/0!", "#NAME?", "#N/A"]):
                    issues.append(f"Formula/error marker in {sheet}!{cell.coordinate}")
                    break
    for s in expected_sheets:
        if s not in wb.sheetnames:
            issues.append(f"Original worksheet missing {s}")
    wb.close()
    return issues


def main():
    make_dirs()
    setup_source_root()
    scenario = build_scenario()
    validation = validate(scenario)
    all_rows, original_headers = populate_workbooks(scenario, validation)
    export_csvs(all_rows, original_headers)
    write_reports(scenario, validation)
    integrity_issues = []
    for kind in OUTPUT_WORKBOOKS:
        src_wb = load_workbook(SOURCE_ROOT / TEMPLATE_FILES[kind], read_only=True)
        original_sheets = src_wb.sheetnames
        src_wb.close()
        integrity_issues.extend(inspect_workbook_integrity(BASE / "workbooks" / OUTPUT_WORKBOOKS[kind], original_sheets, original_headers[kind]))
    if integrity_issues:
        validation["status"] = "fail"
        validation["issues"].extend(integrity_issues)
        write_validation_reports(validation)
    zip_path = package_zip()
    sha = hashlib.sha256(zip_path.read_bytes()).hexdigest()
    print(json.dumps({
        "status": validation["status"],
        "output_dir": str(BASE),
        "zip": str(zip_path),
        "downloads_zip": str(DOWNLOADS_ZIP),
        "sha256": sha,
        "row_counts": validation["row_counts"],
        "issues": validation["issues"],
    }, indent=2))
    augment_path = BASE / "scripts" / "augment_skyharbor_v2.py"
    if augment_path.exists():
        spec = importlib.util.spec_from_file_location("augment_skyharbor_v2", augment_path)
        if spec and spec.loader:
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            module.main()


if __name__ == "__main__":
    main()

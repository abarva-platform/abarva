#!/usr/bin/env python3
"""Add v2 depth to the SkyHarbor Global synthetic current-state package.

This is an additive augmentation over the deterministic v1 generator output. It
does not perform any PostgreSQL write, canonical promotion, deployment, or live
runtime operation.
"""

from __future__ import annotations

import csv
import hashlib
import json
import random
import re
import shutil
import zipfile
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter


SEED = 20260802
RNG = random.Random(SEED + 200)
BASE = Path(__file__).resolve().parents[1]
DOWNLOADS_ZIP = Path("/Users/anand/Downloads/SkyHarbor_Global_Synthetic_Current_State_v3.zip")
LOCAL_ZIP = BASE.parent / "SkyHarbor_Global_Synthetic_Current_State_v3.zip"

WORKBOOKS = {
    "enterprise_it": BASE / "workbooks/SkyHarbor_Global_Enterprise_IT_Current_State_SYNTHETIC_v3.xlsx",
    "data_analytics": BASE / "workbooks/SkyHarbor_Global_Data_Analytics_Current_State_SYNTHETIC_v3.xlsx",
    "cloud_hybrid": BASE / "workbooks/SkyHarbor_Global_Cloud_Hybrid_Current_State_SYNTHETIC_v3.xlsx",
}

SHEET_CSV = {
    "enterprise_it": {
        "1_Enterprise_Context": "1_enterprise_context.csv",
        "2_Business_Functions": "2_business_functions.csv",
        "3_IT_Portfolios_Organization": "3_it_portfolios_organization.csv",
        "4_Applications_Portfolio": "4_applications_portfolio.csv",
        "5_IT_Budget_Allocations": "5_it_budget_allocations.csv",
        "6_Projects_Investments": "6_projects_investments.csv",
        "7_KPIs_Outcomes": "7_kpis_outcomes.csv",
        "8_CXO_Function_Interviews": "8_cxo_function_interviews.csv",
        "8b_Interview_Statements": "8b_interview_statements.csv",
        "9_Operational_Usage_Feeds": "9_operational_usage_feeds.csv",
        "10_AI_Adoption_Usage": "10_ai_adoption_usage.csv",
        "11_Vendors_Contracts": "11_vendors_contracts.csv",
        "12_Risks_Controls": "12_risks_controls.csv",
    },
    "data_analytics": {
        "1_Function_Analytics_Profile": "1_function_analytics_profile.csv",
        "2_Platform_Tech_Stack": "2_platform_tech_stack.csv",
        "3_Function_Platform_Map": "3_function_platform_map.csv",
        "4_Source_to_Consumption": "4_source_to_consumption.csv",
        "5_Function_Volumetrics": "5_function_volumetrics.csv",
        "6_Findings_Maturity": "6_findings_maturity.csv",
        "7_Initiatives_Roadmap": "7_initiatives_roadmap.csv",
    },
    "cloud_hybrid": {
        "1_Cloud_Strategy_Placement": "1_cloud_strategy_placement.csv",
        "2_Data_Center_Private_Cloud": "2_data_center_private_cloud.csv",
        "3_Public_Cloud_Estates": "3_public_cloud_estates.csv",
        "4_Workload_Distribution": "4_workload_distribution.csv",
        "5_Cloud_Platform_Capabilities": "5_cloud_platform_capabilities.csv",
        "6_Cloud_Operations_Economics": "6_cloud_operations_economics.csv",
        "7_Cloud_Findings_Maturity": "7_cloud_findings_maturity.csv",
        "8_Cloud_Initiatives_Roadmap": "8_cloud_initiatives_roadmap.csv",
    },
}

FY2027_TOTAL = 2_350_000_000
FY2026_TOTAL = 2_180_000_000
CONTRACT_COVERAGE_TARGET = 0.63
CONTRACT_ROW_TARGET = 119
PERIODS_8 = ["2025 Q3", "2025 Q4", "2026 Q1", "2026 Q2", "2026 Q3", "2026 Q4", "2027 Q1", "2027 Q2"]
WORKLOAD_PERIODS = ["2026 Q3", "2026 Q4", "2027 Q1", "2027 Q2"]
UNDERFUNDED_HIGH_CONVICTION = ["Crew Recovery Wave 1", "KPI Semantic Standardization Wave 1", "Data Governance Wave 1"]
FUNDED_LOW_CONVICTION = ["ERP Modernization Wave 1", "Cloud Landing Zone Modernization Wave 1", "Network Modernization Wave 1"]


def snake(name: str) -> str:
    return re.sub(r"_+", "_", re.sub(r"[^A-Za-z0-9]+", "_", name.replace("*", "")).strip("_").lower())


def read_csv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return list(reader.fieldnames or []), list(reader)


def write_csv(path: Path, headers: list[str], rows: list[dict]):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=headers, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({h: csv_value(row.get(h, "")) for h in headers})


def csv_value(value):
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    return "" if value is None else value


def money(value: float | int) -> int:
    return int(round(value))


def stable_int(value: str) -> int:
    return int(hashlib.sha256(value.encode("utf-8")).hexdigest()[:12], 16)


def add_header(headers: list[str], *new_headers: str) -> list[str]:
    out = list(headers)
    for h in new_headers:
        if h not in out:
            out.append(h)
    return out


def id_map(rows: list[dict], name_col: str, prefix: str, width: int = 3) -> dict[str, str]:
    return {row[name_col]: f"{prefix}-{i:0{width}d}" for i, row in enumerate(rows, 1)}


def split_amount(total: int, count: int) -> list[int]:
    if count == 1:
        return [total]
    weights = [RNG.random() + 0.25 for _ in range(count)]
    vals = [int(total * w / sum(weights)) for w in weights]
    vals[-1] += total - sum(vals)
    return vals


def load_all():
    data = {}
    headers = {}
    for kind, sheets in SHEET_CSV.items():
        data[kind] = {}
        headers[kind] = {}
        for sheet, name in sheets.items():
            path = BASE / "csv" / kind / name
            if path.exists():
                headers[kind][sheet], data[kind][sheet] = read_csv(path)
    return headers, data


def add_ids_and_refs(headers, data):
    e = data["enterprise_it"]
    d = data["data_analytics"]
    c = data["cloud_hybrid"]
    maps = {
        "function": id_map(e["2_Business_Functions"], "Function Name *", "FN"),
        "portfolio": id_map(e["3_IT_Portfolios_Organization"], "IT Portfolio / Group Name *", "PORT"),
        "application": id_map(e["4_Applications_Portfolio"], "Application / Platform Name *", "APP", 4),
        "project": id_map(e["6_Projects_Investments"], "Initiative / Project Name *", "PRJ"),
        "kpi": id_map(e["7_KPIs_Outcomes"], "KPI Name *", "KPI"),
        "interview": id_map(e["8_CXO_Function_Interviews"], "Interviewee *", "INT"),
        "leader": {},
        "platform": id_map(d["2_Platform_Tech_Stack"], "Platform / Estate Name *", "PLT"),
    }
    leaders = sorted({
        *(r.get("Business Executive *", "") for r in e["2_Business_Functions"]),
        *(r.get("IT Partner *", "") for r in e["2_Business_Functions"]),
        *(r.get("Portfolio Leader *", "") for r in e["3_IT_Portfolios_Organization"]),
        *(r.get("Budget Owner *", "") for r in e["5_IT_Budget_Allocations"]),
        *(r.get("Business Sponsor *", "") for r in e["6_Projects_Investments"]),
    } - {""})
    maps["leader"] = {name: f"LDR-{i:03d}" for i, name in enumerate(leaders, 1)}
    vendor_names = sorted({
        *(r.get("Vendor", "") for r in e["5_IT_Budget_Allocations"]),
        *(vendor_from_product(r.get("Primary Vendor / Product", "")) for r in e["4_Applications_Portfolio"]),
        *(r.get("Vendor / Provider *", "") for r in e["10_AI_Adoption_Usage"]),
    } - {"", "SkyHarbor Global"})
    extra = [
        "AeroNexus Services", "BlueGate Systems", "CloudRoute Partners", "CrewBridge Technologies",
        "FlightLine Analytics", "GateWise Operations", "HarborPoint Telecom", "RunwayLogic Labs",
        "SkyLedger Services", "TransitCore Solutions", "VectorAero Consulting",
        "Waypoint Resilience", "WingSpan Digital", "YieldWave Systems", "ZenithGate Managed Services",
    ]
    vendor_names = sorted(set(vendor_names) | set(extra))
    maps["vendor"] = {name: f"VEN-{i:03d}" for i, name in enumerate(vendor_names, 1)}
    add_entity_refs(headers, data, maps)
    return maps


def vendor_from_product(value: str) -> str:
    return value.split("/")[0].strip() if "/" in value else value.strip()


def add_entity_refs(headers, data, maps):
    e, d, c = data["enterprise_it"], data["data_analytics"], data["cloud_hybrid"]
    h = headers["enterprise_it"]
    h["2_Business_Functions"] = add_header(h["2_Business_Functions"], "function_id", "business_executive_ref", "it_partner_ref")
    for r in e["2_Business_Functions"]:
        r["function_id"] = maps["function"][r["Function Name *"]]
        r["business_executive_ref"] = maps["leader"].get(r.get("Business Executive *", ""))
        r["it_partner_ref"] = maps["leader"].get(r.get("IT Partner *", ""))
    h["3_IT_Portfolios_Organization"] = add_header(h["3_IT_Portfolios_Organization"], "portfolio_id", "portfolio_leader_ref")
    for r in e["3_IT_Portfolios_Organization"]:
        r["portfolio_id"] = maps["portfolio"][r["IT Portfolio / Group Name *"]]
        r["portfolio_leader_ref"] = maps["leader"].get(r.get("Portfolio Leader *", ""))
    h["4_Applications_Portfolio"] = add_header(h["4_Applications_Portfolio"], "application_id", "primary_business_function_ref", "it_portfolio_ref", "business_owner_ref", "vendor_ref")
    for r in e["4_Applications_Portfolio"]:
        r["application_id"] = maps["application"][r["Application / Platform Name *"]]
        r["primary_business_function_ref"] = maps["function"].get(r.get("Primary Business Function *", ""))
        r["it_portfolio_ref"] = maps["portfolio"].get(r.get("IT Portfolio Owner *", ""))
        r["business_owner_ref"] = maps["leader"].get(r.get("Business Owner *", ""))
        r["vendor_ref"] = maps["vendor"].get(vendor_from_product(r.get("Primary Vendor / Product", "")))
    h["5_IT_Budget_Allocations"] = add_header(
        h["5_IT_Budget_Allocations"],
        "budget_line_id",
        "budget_owner_ref",
        "it_portfolio_ref",
        "business_function_ref",
        "project_ref",
        "vendor_ref",
        "application_ref",
        "contract_ref",
        "spend_attribution_type",
        "contract_backed_amount",
        "internal_noncontracted_amount",
    )
    for i, r in enumerate(e["5_IT_Budget_Allocations"], 1):
        r["budget_line_id"] = f"BUD-{i:05d}"
        r["budget_owner_ref"] = maps["leader"].get(r.get("Budget Owner *", ""))
        r["it_portfolio_ref"] = maps["portfolio"].get(r.get("IT Portfolio *", ""))
        r["business_function_ref"] = maps["function"].get(r.get("Business Function / Consumer", ""))
        r["project_ref"] = maps["project"].get(r.get("Project / Initiative", ""))
        r["vendor_ref"] = maps["vendor"].get(r.get("Vendor", ""))
        r["application_ref"] = maps["application"].get(r.get("Application / Platform", ""))
        r["contract_ref"] = ""
        r["spend_attribution_type"] = ""
        r["contract_backed_amount"] = ""
        r["internal_noncontracted_amount"] = ""
    h["6_Projects_Investments"] = add_header(h["6_Projects_Investments"], "project_id", "business_function_ref", "business_sponsor_ref", "it_portfolio_ref")
    for r in e["6_Projects_Investments"]:
        r["project_id"] = maps["project"][r["Initiative / Project Name *"]]
        r["business_function_ref"] = maps["function"].get(r.get("Business Function(s) *", ""))
        r["business_sponsor_ref"] = maps["leader"].get(r.get("Business Sponsor *", ""))
        r["it_portfolio_ref"] = maps["portfolio"].get(r.get("IT Portfolio Owner *", ""))
    h["7_KPIs_Outcomes"] = add_header(h["7_KPIs_Outcomes"], "kpi_id", "kpi_observation_id", "business_function_ref", "related_application_ref", "related_initiative_ref")
    for i, r in enumerate(e["7_KPIs_Outcomes"], 1):
        r["kpi_id"] = maps["kpi"][r["KPI Name *"]]
        r["kpi_observation_id"] = f"KPIOBS-{i:04d}"
        r["business_function_ref"] = maps["function"].get(r.get("Business Function *", ""))
        app, project = split_related(r.get("Related Application / Initiative", ""))
        r["related_application_ref"] = maps["application"].get(app, "")
        r["related_initiative_ref"] = maps["project"].get(project, "")
    h["8_CXO_Function_Interviews"] = add_header(h["8_CXO_Function_Interviews"], "interview_id", "business_function_ref", "portfolio_ref", "interviewee_ref")
    for r in e["8_CXO_Function_Interviews"]:
        scope = r.get("Business Function / IT Portfolio *", "")
        r["interview_id"] = maps["interview"][r["Interviewee *"]]
        r["business_function_ref"] = maps["function"].get(scope, "")
        r["portfolio_ref"] = maps["portfolio"].get(scope, "")
        r["interviewee_ref"] = maps["leader"].get(r.get("Interviewee *", ""))
    h["9_Operational_Usage_Feeds"] = add_header(h["9_Operational_Usage_Feeds"], "feed_id", "owner_ref")
    for i, r in enumerate(e["9_Operational_Usage_Feeds"], 1):
        r["feed_id"] = f"FEED-{i:03d}"
        r["owner_ref"] = maps["leader"].get(r.get("Business / Technical Owner", ""))
    h["10_AI_Adoption_Usage"] = add_header(h["10_AI_Adoption_Usage"], "ai_adoption_id", "business_function_ref", "portfolio_ref", "vendor_ref")
    for i, r in enumerate(e["10_AI_Adoption_Usage"], 1):
        r["ai_adoption_id"] = f"AIADOPT-{i:04d}"
        r["business_function_ref"] = maps["function"].get(r.get("Business Function", ""))
        r["portfolio_ref"] = maps["portfolio"].get(r.get("IT Portfolio Owner", ""))
        r["vendor_ref"] = maps["vendor"].get(r.get("Vendor / Provider *", ""))
    dh = headers["data_analytics"]
    dh["1_Function_Analytics_Profile"] = add_header(dh["1_Function_Analytics_Profile"], "function_ref")
    for r in d["1_Function_Analytics_Profile"]:
        r["function_ref"] = maps["function"].get(r.get("Business Function *", ""))
    dh["2_Platform_Tech_Stack"] = add_header(dh["2_Platform_Tech_Stack"], "platform_id", "technical_owner_ref")
    for r in d["2_Platform_Tech_Stack"]:
        r["platform_id"] = maps["platform"][r["Platform / Estate Name *"]]
        r["technical_owner_ref"] = maps["leader"].get(r.get("Technical Owner *", ""))
    for sheet in ["3_Function_Platform_Map", "4_Source_to_Consumption", "5_Function_Volumetrics", "6_Findings_Maturity", "7_Initiatives_Roadmap"]:
        dh[sheet] = add_header(dh[sheet], f"{snake(sheet)}_id", "function_ref", "platform_ref", "initiative_ref")
        for i, r in enumerate(d[sheet], 1):
            r[f"{snake(sheet)}_id"] = f"DA-{sheet.split('_')[0]}-{i:04d}"
            r["function_ref"] = maps["function"].get(r.get("Business Function *", "") or r.get("Business Function(s) *", ""))
            r["platform_ref"] = maps["platform"].get(r.get("Platform / Estate Name *", "") or r.get("Core Warehouse / Lake / EDW *", "") or r.get("Related Platform / Flow", "") or r.get("Platforms / Estates Affected *", ""))
            r["initiative_ref"] = maps["project"].get(r.get("Initiative Underway", "") or r.get("Initiative / Planned Change", "") or r.get("Initiative Name *", ""))
    ch = headers["cloud_hybrid"]
    estate_map = {}
    for i, r in enumerate(c["2_Data_Center_Private_Cloud"], 1):
        estate_map[r["Estate / Site Name *"]] = f"ESTP-{i:03d}"
    for i, r in enumerate(c["3_Public_Cloud_Estates"], 1):
        estate_map[r["Estate / Landing Zone Name *"]] = f"ESTC-{i:03d}"
    maps["estate"] = estate_map
    for sheet, rows in c.items():
        ch[sheet] = add_header(ch[sheet], f"{snake(sheet)}_id", "estate_ref", "portfolio_ref", "owner_ref")
        for i, r in enumerate(rows, 1):
            r[f"{snake(sheet)}_id"] = f"CLD-{sheet.split('_')[0]}-{i:04d}"
            r["estate_ref"] = estate_map.get(r.get("Estate / Site Name *", "") or r.get("Estate / Landing Zone Name *", "") or r.get("Estate / Provider *", "") or r.get("Environment / Estate *", ""))
            r["portfolio_ref"] = maps["portfolio"].get(r.get("Business / IT Portfolio", ""))
            r["owner_ref"] = maps["leader"].get(r.get("Accountable Owner *", "") or r.get("Technical Owner *", "") or r.get("Cloud Platform Owner *", "") or r.get("Delivery Owner *", ""))
    return maps


def add_practical_technical_depth(headers, data):
    app_headers = [
        "application_version_or_release",
        "deployment_model_detail",
        "runtime_capacity_unit",
        "runtime_capacity_quantity",
        "named_user_count",
        "monthly_transaction_volume",
        "data_volume_gb",
        "integration_count",
        "batch_jobs_count",
        "support_model",
        "upgrade_or_patch_posture",
        "technical_detail_source",
    ]
    headers["enterprise_it"]["4_Applications_Portfolio"] = add_header(headers["enterprise_it"]["4_Applications_Portfolio"], *app_headers)
    for row in data["enterprise_it"]["4_Applications_Portfolio"]:
        name = row["Application / Platform Name *"]
        hosting = row.get("Hosting Model *", "")
        product = row.get("Primary Vendor / Product", "")
        domain = row.get("Application Domain *", "")
        row["application_version_or_release"] = app_version(product, name)
        row["deployment_model_detail"] = deployment_detail(hosting, product)
        unit, qty = application_capacity(product, domain, hosting)
        row["runtime_capacity_unit"] = unit
        row["runtime_capacity_quantity"] = str(qty)
        row["named_user_count"] = str(named_users(domain, product))
        row["monthly_transaction_volume"] = str(monthly_transactions(domain, product))
        row["data_volume_gb"] = str(data_volume(domain, hosting))
        row["integration_count"] = str(2 + (stable_int(name + "-int") % 38))
        row["batch_jobs_count"] = str(stable_int(name + "-batch") % 95)
        row["support_model"] = support_model(product, hosting)
        row["upgrade_or_patch_posture"] = upgrade_posture(product, hosting)
        row["technical_detail_source"] = RNG.choice(["CMDB export", "APM inventory", "application owner interview", "architecture diagram", "vendor support portal"])

    platform_headers = [
        "platform_version_or_service_tier",
        "deployment_model_detail",
        "capacity_unit",
        "capacity_quantity",
        "monthly_active_users",
        "monthly_job_or_query_volume",
        "storage_tb",
        "integration_or_pipeline_count",
        "backup_or_retention_summary",
        "support_model",
        "upgrade_or_patch_posture",
        "technical_detail_source",
    ]
    headers["data_analytics"]["2_Platform_Tech_Stack"] = add_header(headers["data_analytics"]["2_Platform_Tech_Stack"], *platform_headers)
    for row in data["data_analytics"]["2_Platform_Tech_Stack"]:
        name = row["Platform / Estate Name *"]
        category = row.get("Platform Category *", "")
        row["platform_version_or_service_tier"] = platform_version(name, category)
        row["deployment_model_detail"] = deployment_detail(row.get("Hosting / Estate *", ""), name)
        unit, qty = platform_capacity(name, category)
        row["capacity_unit"] = unit
        row["capacity_quantity"] = str(qty)
        row["monthly_active_users"] = str(60 + (stable_int(name + "-users") % 7200))
        row["monthly_job_or_query_volume"] = str(1_000 + (stable_int(name + "-jobs") % 950_000))
        row["storage_tb"] = str(round(4 + (stable_int(name + "-tb") % 2200) / 10, 1))
        row["integration_or_pipeline_count"] = str(8 + (stable_int(name + "-pipes") % 420))
        row["backup_or_retention_summary"] = RNG.choice(["30-day operational restore", "90-day backup plus archive", "policy varies by domain", "retention confirmed for regulated data only"])
        row["support_model"] = RNG.choice(["platform team", "vendor managed", "shared platform plus product team", "managed service"])
        row["upgrade_or_patch_posture"] = RNG.choice(["current", "one release behind", "upgrade planned", "patch cadence unclear"])
        row["technical_detail_source"] = RNG.choice(["platform owner interview", "admin console export", "architecture diagram", "usage report", "data catalog"])


def app_version(product: str, name: str) -> str:
    p = product.lower()
    if "sap" in p:
        return RNG.choice(["SAP S/4HANA 2022 FPS02", "SAP ECC 6.0 EHP8", "SAP S/4HANA 2021"])
    if "oracle" in p:
        return RNG.choice(["Oracle Fusion Cloud quarterly release", "Oracle EBS 12.2", "Oracle EPM Cloud"])
    if "salesforce" in p:
        return RNG.choice(["Salesforce Spring 27", "Salesforce Service Cloud Enterprise", "Salesforce Hyperforce"])
    if "servicenow" in p:
        return RNG.choice(["ServiceNow Vancouver", "ServiceNow Washington DC", "ServiceNow Zurich"])
    if "microsoft" in p:
        return RNG.choice(["Microsoft 365 E5", "Dynamics 365 10.x", "Azure App Service current"])
    return RNG.choice(["vendor current", "N-1 supported release", f"release {1 + stable_int(name) % 9}.{stable_int(name) % 12}", "version not confirmed"])


def deployment_detail(hosting: str, product: str) -> str:
    h = hosting.lower()
    if "saas" in h:
        return RNG.choice(["vendor SaaS tenant", "single production SaaS tenant", "multi-region SaaS service"])
    if "public" in h or "cloud" in h:
        return RNG.choice(["Azure region pair", "AWS account landing zone", "GCP project", "containerized public-cloud deployment"])
    if "private" in h or "prem" in h:
        return RNG.choice(["primary data center plus DR", "private cloud VM cluster", "on-premises clustered deployment"])
    return RNG.choice(["hybrid active/passive", "mixed SaaS and private integration", "deployment not confirmed"])


def application_capacity(product: str, domain: str, hosting: str) -> tuple[str, int]:
    p = product.lower()
    if "sap" in p or "oracle" in p:
        return "productive instances", 2 + (stable_int(product + domain) % 7)
    if "salesforce" in p or "servicenow" in p:
        return "licensed tenants", 1 + (stable_int(product + domain) % 4)
    if "data" in domain.lower() or "analytics" in domain.lower():
        return "compute nodes", 4 + (stable_int(product + domain) % 80)
    if "public" in hosting.lower() or "cloud" in hosting.lower():
        return "vCPU equivalent", 8 + (stable_int(product + domain) % 900)
    return "servers_or_vms", 2 + (stable_int(product + domain) % 140)


def named_users(domain: str, product: str) -> int:
    d = domain.lower()
    if any(x in d for x in ["crew", "airport", "customer", "commerce", "loyalty"]):
        return 800 + (stable_int(domain + product + "-users") % 42_000)
    if any(x in d for x in ["finance", "procurement", "human", "legal"]):
        return 120 + (stable_int(domain + product + "-users") % 9_500)
    return 40 + (stable_int(domain + product + "-users") % 18_000)


def monthly_transactions(domain: str, product: str) -> int:
    d = domain.lower()
    base = 10_000
    if any(x in d for x in ["booking", "customer", "loyalty", "airport", "operations", "crew"]):
        base = 500_000
    elif any(x in d for x in ["finance", "procurement", "human"]):
        base = 35_000
    return base + (stable_int(domain + product + "-tx") % (base * 30))


def data_volume(domain: str, hosting: str) -> int:
    base = 50 if "SaaS" in hosting else 120
    if "data" in domain.lower() or "analytics" in domain.lower():
        base = 2_000
    return base + (stable_int(domain + hosting + "-gb") % (base * 80))


def support_model(product: str, hosting: str) -> str:
    if "SaaS" in hosting:
        return RNG.choice(["vendor support plus internal product owner", "vendor managed with business admin", "managed service plus SaaS support"])
    if any(x in product.lower() for x in ["sap", "oracle", "mainframe"]):
        return RNG.choice(["internal L2 plus SI L3", "AMS provider plus retained architect", "internal platform team"])
    return RNG.choice(["product team", "shared operations", "managed service", "internal L2/L3"])


def upgrade_posture(product: str, hosting: str) -> str:
    if "SaaS" in hosting:
        return RNG.choice(["vendor-managed quarterly release", "current SaaS release", "release notes reviewed inconsistently"])
    if any(x in product.lower() for x in ["ecc", "mainframe", "teradata"]):
        return RNG.choice(["upgrade required within 18 months", "extended support", "N-2 release"])
    return RNG.choice(["current", "one release behind", "patch cadence documented", "patch cadence unclear"])


def platform_version(name: str, category: str) -> str:
    n = name.lower()
    if "databricks" in n:
        return RNG.choice(["Premium workspace", "Enterprise workspace", "Unity Catalog enabled"])
    if "snowflake" in n:
        return RNG.choice(["Enterprise Edition", "Business Critical", "multi-cluster warehouse"])
    if "power bi" in n:
        return RNG.choice(["Power BI Premium/Fabric", "Power BI Pro mixed estate"])
    if "tableau" in n:
        return RNG.choice(["Tableau Cloud", "Tableau Server 2023.3"])
    if "informatica" in n:
        return RNG.choice(["IICS", "PowerCenter 10.5"])
    return RNG.choice(["current managed service tier", "N-1 supported release", "version not confirmed"])


def platform_capacity(name: str, category: str) -> tuple[str, int]:
    c = category.lower()
    if any(x in c for x in ["warehouse", "lake", "data"]):
        return "compute warehouses_or_clusters", 2 + (stable_int(name + category) % 64)
    if any(x in c for x in ["bi", "visual"]):
        return "premium_capacity_units", 1 + (stable_int(name + category) % 24)
    if any(x in c for x in ["integration", "etl", "stream"]):
        return "runtime_workers", 4 + (stable_int(name + category) % 180)
    return "service_instances", 1 + (stable_int(name + category) % 40)


def mark_project_inversions(headers, data):
    projects = data["enterprise_it"]["6_Projects_Investments"]
    note_col = "v3_conviction_funding_note"
    headers["enterprise_it"]["6_Projects_Investments"] = add_header(headers["enterprise_it"]["6_Projects_Investments"], note_col)
    underfunded_overrides = {
        "Crew Recovery Wave 1": ("On hold", "Unfunded", 0),
        "KPI Semantic Standardization Wave 1": ("At risk", "Partially funded", 2_800_000),
        "Data Governance Wave 1": ("Awaiting decision", "Partially funded", 3_400_000),
    }
    for row in projects:
        name = row["Initiative / Project Name *"]
        if name in underfunded_overrides:
            status, funding, approved = underfunded_overrides[name]
            row["Status *"] = status
            row["Funding Status"] = funding
            row["Approved Budget"] = str(approved)
            row["OpEx Budget"] = str(int(approved * 0.62))
            row["CapEx Budget"] = str(approved - int(approved * 0.62))
            row["Forecast at Completion"] = str(max(approved, int(approved * 1.28)))
            row["Actual to Date"] = str(int(approved * 0.35))
            row["Major Risk / Constraint"] = "Executive conviction exceeds committed funding; consequences include delayed KPI baseline, manual recovery effort, or unresolved operating-risk exposure."
            row["Decision Needed"] = "Resolve funding gap with named executive owner"
            row[note_col] = "high_conviction_underfunded"
        elif name in FUNDED_LOW_CONVICTION:
            approved = max(int(parse_num(row.get("Approved Budget", "0"))), 34_000_000 + (stable_int(name) % 9_000_000))
            row["Status *"] = "In flight"
            row["Funding Status"] = "Approved"
            row["Approved Budget"] = str(approved)
            row["OpEx Budget"] = str(int(approved * 0.58))
            row["CapEx Budget"] = str(approved - int(approved * 0.58))
            row["Forecast at Completion"] = str(int(approved * 1.04))
            row["Actual to Date"] = str(int(approved * 0.46))
            row["Expected Business / Technology Value *"] = "Infrastructure-heavy or contractual investment with limited executive visibility and weak near-term KPI linkage."
            row["KPIs / Outcomes Affected"] = "Directional; KPI linkage under review"
            row["Major Risk / Constraint"] = "Spend is committed ahead of visible operating conviction; benefits need post-load validation through workload and KPI evidence."
            row["Decision Needed"] = "Confirm KPI owner and benefit baseline"
            row[note_col] = "well_funded_low_conviction"
        else:
            row[note_col] = ""


def split_related(value: str) -> tuple[str, str]:
    parts = [p.strip() for p in value.split("/") if p.strip()]
    return (parts[0] if parts else "", parts[1] if len(parts) > 1 else "")


def add_temporal_depth(headers, data, maps):
    e, c = data["enterprise_it"], data["cloud_hybrid"]
    original_kpis = [r for r in e["7_KPIs_Outcomes"] if r.get("Reporting Period *") == "2027 Q2"]
    kpi_rows = []
    for idx, base in enumerate(original_kpis, 1):
        current = parse_num(base["Current Value *"])
        target = parse_num(base["Target Value"])
        direction = base.get("Direction *", "Increase")
        for p_idx, period in enumerate(PERIODS_8):
            row = dict(base)
            trend = trend_value(current, target, direction, p_idx, idx)
            prior = trend_value(current, target, direction, max(0, p_idx - 1), idx)
            row["Reporting Period *"] = period
            row["Current Value *"] = str(trend)
            row["Prior Value"] = str(prior)
            row["kpi_observation_id"] = f"KPIOBS-{idx:03d}-{p_idx+1:02d}"
            kpi_rows.append(row)
    e["7_KPIs_Outcomes"] = kpi_rows

    current_budget = [r for r in e["5_IT_Budget_Allocations"] if r.get("Fiscal Year *") == "2027"]
    prior_rows = []
    allocations = split_amount(FY2026_TOTAL, len(current_budget))
    for i, (base, amount) in enumerate(zip(current_budget, allocations), 1):
        row = dict(base)
        row["Fiscal Year *"] = "2026"
        row["Period"] = "FY2026"
        row["Scenario *"] = "Prior year actuals"
        row["Budget Amount *"] = str(amount)
        row["Forecast Amount"] = str(amount)
        row["Actual Amount"] = str(amount)
        row["Committed Amount"] = str(money(amount * 0.94))
        row["budget_line_id"] = f"BUDPY-{i:05d}"
        row["Project / Initiative"] = row.get("Project / Initiative", "")
        row["project_ref"] = maps["project"].get(row["Project / Initiative"], "")
        row["contract_ref"] = ""
        row["spend_attribution_type"] = "prior_year_actual"
        row["contract_backed_amount"] = ""
        row["internal_noncontracted_amount"] = str(amount)
        prior_rows.append(row)
    e["5_IT_Budget_Allocations"] = current_budget + prior_rows

    workload_base = [r for r in c["4_Workload_Distribution"] if r.get("Snapshot Period *") == "2027 Q2"]
    workload_rows = []
    for p_idx, period in enumerate(WORKLOAD_PERIODS):
        for i, base in enumerate(workload_base, 1):
            row = dict(base)
            row["Snapshot Period *"] = period
            base_qty = parse_num(row["Quantity *"])
            movement = [0.92, 0.96, 0.99, 1.0][p_idx]
            if "Public-cloud" in row.get("Hosting Environment *", ""):
                movement = [0.84, 0.91, 0.97, 1.0][p_idx]
            row["Quantity *"] = str(money(base_qty * movement))
            row["4_workload_distribution_id"] = f"CLD-4-{p_idx+1:02d}-{i:04d}"
            workload_rows.append(row)
    c["4_Workload_Distribution"] = workload_rows

    extend_period_rows(e["10_AI_Adoption_Usage"], "ai_adoption_id", "AIADOPT", ai=True)
    extend_period_rows(c["6_Cloud_Operations_Economics"], "6_cloud_operations_economics_id", "CLD-6", cloud=True)


def parse_num(value: str) -> float:
    try:
        return float(str(value).replace(",", ""))
    except Exception:
        return 0.0


def trend_value(current, target, direction, period_index, idx):
    if current <= 1.5 and target <= 1.5:
        if direction == "Increase":
            start = current * (0.94 if idx % 8 else 1.02)
            val = start + (current - start) * (period_index / 7)
            if idx % 7 == 0:
                val -= 0.015 * period_index / 7
            return round(max(0, min(0.999, val)), 3)
        start = current * 0.88
        val = start + (current - start) * (period_index / 7)
        if idx % 6 == 0:
            val += 0.025 * period_index / 7
        return round(max(0, val), 3)
    start = current * (0.86 if direction == "Increase" else 0.78)
    val = start + (current - start) * (period_index / 7)
    if idx % 9 == 0:
        val = start * (1 + 0.035 * period_index)
    return round(val, 1)


def extend_period_rows(rows, id_col, id_prefix, ai=False, cloud=False):
    current = [r for r in rows if r.get("Reporting Period *") in {"2026 Q3", "2026 Q4", "2027 Q1", "2027 Q2"}]
    grouped = defaultdict(list)
    for r in current:
        key = tuple((k, r.get(k, "")) for k in r if k not in {"Reporting Period *", id_col})
        grouped[key].append(r)
    templates = current[:]
    new_rows = []
    for p_idx, period in enumerate(PERIODS_8):
        for i, base in enumerate(templates[: len(templates) // 4] if p_idx < 4 else templates[(p_idx - 4) * (len(templates) // 4):(p_idx - 3) * (len(templates) // 4)], 1):
            row = dict(base)
            row["Reporting Period *"] = period
            row[id_col] = f"{id_prefix}-{p_idx+1:02d}-{i:04d}"
            if ai:
                assigned = int(parse_num(row.get("Seats Assigned", "0")))
                plateau = [0.31, 0.36, 0.41, 0.45, 0.48, 0.51, 0.53, 0.54][p_idx]
                active = min(assigned, max(1, money(assigned * (plateau + RNG.uniform(-0.04, 0.035)))))
                row["Active Users"] = str(active)
                row["Primary Activity Count"] = str(active * RNG.randint(12, 48))
                row["Estimated Use Cost"] = str(money(parse_num(row.get("Estimated Use Cost", "0")) * (0.76 + 0.05 * p_idx)))
                row["Estimated Hours Saved"] = str(money(parse_num(row.get("Estimated Hours Saved", "0")) * (0.65 + 0.06 * p_idx)))
            if cloud:
                factor = [0.69, 0.74, 0.81, 0.88, 0.94, 0.99, 1.06, 1.12][p_idx]
                for col in ["Budget", "Actual Spend", "Forecast", "Committed Spend", "Compute Cost", "Storage Cost", "Network / Egress Cost", "Software / Marketplace Cost", "Managed Service Cost"]:
                    row[col] = str(money(parse_num(row.get(col, "0")) * factor))
                row["Key Cost / Operational Insight *"] = "Cloud spend is rising faster than workload migration in this period."
            new_rows.append(row)
    rows[:] = new_rows


def add_contracts(headers, data, maps):
    budget_rows = [r for r in data["enterprise_it"]["5_IT_Budget_Allocations"] if r.get("Fiscal Year *") == "2027"]
    vendor_totals = Counter()
    for r in budget_rows:
        vendor = r.get("Vendor", "")
        if vendor:
            vendor_totals[vendor] += int(parse_num(r["Budget Amount *"]))
    contract_target = money(FY2027_TOTAL * CONTRACT_COVERAGE_TARGET)
    vendor_names = sorted(vendor_totals)
    vendor_covered = proportional_allocation(contract_target, [vendor_totals[v] for v in vendor_names])
    vendor_contract_targets = dict(zip(vendor_names, vendor_covered))
    rows = []
    contract_by_vendor = defaultdict(list)
    categories = ["application managed services", "cloud platform", "SaaS", "network", "cybersecurity", "data platform", "implementation services"]
    base_count, extra = divmod(CONTRACT_ROW_TARGET, len(vendor_names))
    for pos, vendor in enumerate(vendor_names):
        count = base_count + (1 if pos < extra else 0)
        covered_total = vendor_contract_targets[vendor]
        for amt in split_amount(covered_total, count):
            contract_by_vendor[vendor].append(amt)
    for idx, (vendor, amounts) in enumerate(contract_by_vendor.items(), 1):
        for j, amount in enumerate(amounts, 1):
            contract_id = f"CTR-{len(rows)+1:03d}"
            start = date(2024 + (len(rows) % 3), 1 + (len(rows) % 12), 1)
            end = date(2027 + (len(rows) % 5), 1 + (len(rows) % 12), 28)
            if len(rows) in {3, 17}:
                end = date(2028, 2, 28)
            auto = "Yes" if len(rows) in {8, 21, 40} else RNG.choice(["Yes", "No", "No"])
            benchmarking = "No" if len(rows) in {8, 21, 40} else RNG.choice(["Yes", "Limited", "No"])
            owner = "" if len(rows) in {3, 17} else pick_from(data["enterprise_it"]["3_IT_Portfolios_Organization"], "Portfolio Leader *")
            rows.append({
                "contract_id": contract_id,
                "vendor_id": maps["vendor"].get(vendor, ""),
                "vendor_name": vendor,
                "contract_name": f"{vendor} {RNG.choice(categories).title()} Agreement {j}",
                "category": RNG.choice(categories),
                "scope_summary": f"Fictional contract supporting airline technology services for {vendor}; annual value covers only the contract-backed portion of FY2027 vendor spend.",
                "annual_value": str(amount),
                "total_committed_value": str(amount * RNG.randint(2, 5)),
                "committed_annual_spend": str(money(amount * (0.88 + ((stable_int(contract_id + '-commit') % 19) / 100)))),
                "actual_annual_spend": str(money(amount * (0.76 + ((stable_int(contract_id + '-actual') % 23) / 100)))),
                "start_date": start.isoformat(),
                "end_date": end.isoformat(),
                "notice_period_days": str(RNG.choice([60, 90, 120, 180])),
                "auto_renew": auto,
                "renewal_decision_state": "No owner assigned" if not owner else RNG.choice(["Renewal analysis pending", "Competitive event likely", "Renewal approved", "Under review"]),
                "renewal_owner": owner,
                "renewal_owner_ref": maps["leader"].get(owner, ""),
                "supported_applications": join_names(data["enterprise_it"]["4_Applications_Portfolio"], "Application / Platform Name *", 3),
                "supported_application_refs": join_refs_from_names(data["enterprise_it"]["4_Applications_Portfolio"], "Application / Platform Name *", maps["application"], 3),
                "supported_functions": join_names(data["enterprise_it"]["2_Business_Functions"], "Function Name *", 3),
                "supported_function_refs": join_refs_from_names(data["enterprise_it"]["2_Business_Functions"], "Function Name *", maps["function"], 3),
                "sla_summary": RNG.choice(["99.9% priority support", "business-hours support with P1 escalation", "24x7 managed service", "best-effort advisory"]),
                "benchmarking_clause": benchmarking,
                "exit_rights_summary": RNG.choice(["termination for convenience with fee", "limited exit rights", "transition assistance included", "exit rights unclear"]),
                "alternatives_available": RNG.choice(["Yes", "Limited", "No", "Market scan needed"]),
                "concentration_note": "Material concentration vendor" if amount > 90_000_000 else RNG.choice(["normal concentration", "specialized skill dependency", "regional dependency"]),
                "source_confidence": RNG.choice(["system-derived", "contract register", "estimated"]),
            })
    headers["enterprise_it"]["11_Vendors_Contracts"] = list(rows[0])
    data["enterprise_it"]["11_Vendors_Contracts"] = rows
    assign_contract_refs(data, rows, contract_target)


def proportional_allocation(total: int, weights: list[int]) -> list[int]:
    if not weights:
        return []
    raw = [total * (w / sum(weights)) for w in weights]
    vals = [int(x) for x in raw]
    vals[-1] += total - sum(vals)
    return vals


def assign_contract_refs(data, contracts, contract_target):
    by_vendor = defaultdict(list)
    for c in contracts:
        by_vendor[c["vendor_name"]].append(c["contract_id"])
    fy2027_rows = [r for r in data["enterprise_it"]["5_IT_Budget_Allocations"] if r.get("Fiscal Year *") == "2027"]
    amounts = proportional_allocation(contract_target, [int(parse_num(r.get("Budget Amount *", "0"))) for r in fy2027_rows])
    for r, backed in zip(fy2027_rows, amounts):
        ids = by_vendor.get(r.get("Vendor", ""))
        budget_amount = int(parse_num(r.get("Budget Amount *", "0")))
        internal = max(0, budget_amount - backed)
        r["contract_backed_amount"] = str(backed)
        r["internal_noncontracted_amount"] = str(internal)
        r["spend_attribution_type"] = "mixed_contract_internal" if backed and internal else "contract_backed" if backed else "internal_noncontracted"
        if ids and backed:
            r["contract_ref"] = ids[stable_int(r.get("budget_line_id", "")) % len(ids)]


def pick_from(rows, col):
    return RNG.choice(rows).get(col, "")


def join_names(rows, col, count):
    return "; ".join(RNG.choice(rows).get(col, "") for _ in range(count))


def join_refs_from_names(rows, col, mapping, count):
    names = [RNG.choice(rows).get(col, "") for _ in range(count)]
    return "; ".join(mapping.get(n, "") for n in names if mapping.get(n, ""))


def add_risks(headers, data, maps):
    apps = data["enterprise_it"]["4_Applications_Portfolio"]
    funcs = data["enterprise_it"]["2_Business_Functions"]
    rows = []
    domains = ["cybersecurity", "operational resilience", "data quality", "vendor", "cloud", "regulatory", "AI governance", "legacy technology"]
    for i in range(80):
        app = RNG.choice(apps)
        fn = next((f for f in funcs if f["Function Name *"] == app["Primary Business Function *"]), RNG.choice(funcs))
        never_tested = 16 <= i < 38
        rows.append({
            "risk_id": f"RSK-{i+1:03d}",
            "risk_name": f"{RNG.choice(domains).title()} risk for {app['Application / Platform Name *'][:42]}",
            "risk_domain": RNG.choice(domains),
            "description": f"Synthetic risk affecting {fn['Function Name *']} where current controls do not fully resolve evidence, ownership, or recovery uncertainty.",
            "inherent_severity": RNG.choice(["Critical", "High", "High", "Medium"]),
            "likelihood": RNG.choice(["Likely", "Possible", "Possible", "Unlikely"]),
            "residual_severity": RNG.choice(["High", "Medium", "Medium", "Low"]),
            "affected_applications": app["Application / Platform Name *"],
            "affected_application_refs": maps["application"].get(app["Application / Platform Name *"], ""),
            "business_function": fn["Function Name *"],
            "business_function_ref": maps["function"].get(fn["Function Name *"], ""),
            "risk_owner": fn["Business Executive *"],
            "risk_owner_ref": maps["leader"].get(fn["Business Executive *"], ""),
            "control_description": RNG.choice(["quarterly access review", "DR test evidence", "vendor SLA review", "data-quality reconciliation", "AI policy review"]),
            "control_type": RNG.choice(["preventive", "detective", "corrective"]),
            "control_status": RNG.choice(["effective", "partially effective", "not effective", "not tested"]),
            "control_last_tested_date": "" if never_tested else (date(2027, 6, 30) - timedelta(days=RNG.randint(15, 420))).isoformat(),
            "control_test_result": "never_tested" if never_tested else RNG.choice(["passed", "partially_passed", "failed", "ineffective", "unknown"]),
            "control_test_evidence_ref": "" if never_tested else f"EVID-RSK-{i+1:03d}",
            "remediation_plan": RNG.choice(["assign accountable owner", "refresh control evidence", "fund remediation", "include in modernization wave", "vendor action plan"]),
            "remediation_due": (date(2027, 9, 30) + timedelta(days=RNG.randint(0, 420))).isoformat(),
            "source_confidence": RNG.choice(["system-derived", "interview-reported", "estimated"]),
        })
    headers["enterprise_it"]["12_Risks_Controls"] = list(rows[0])
    data["enterprise_it"]["12_Risks_Controls"] = rows


def add_interview_statements(headers, data, maps):
    interviews = data["enterprise_it"]["8_CXO_Function_Interviews"]
    projects = data["enterprise_it"]["6_Projects_Investments"]
    apps = data["enterprise_it"]["4_Applications_Portfolio"]
    platforms = data["data_analytics"]["2_Platform_Tech_Stack"]
    kpis = data["enterprise_it"]["7_KPIs_Outcomes"]
    contracts = data["enterprise_it"]["11_Vendors_Contracts"]
    themes = ["strategy", "cost", "reliability", "talent", "data", "AI", "vendor", "risk", "decision rights"]
    questions = {
        "strategy": "Where is the strategy clearest, and where is it still ambiguous?",
        "cost": "Which cost pressure changes the investment conversation?",
        "reliability": "Where does reliability still depend on manual recovery?",
        "talent": "Which skills or operating-model constraints matter most?",
        "data": "What evidence do you trust, and what evidence is still missing?",
        "AI": "Where should AI scale, and where should it slow down?",
        "vendor": "Which vendor or contract constraint affects your options?",
        "risk": "Which risk would change the decision if it worsened?",
        "decision rights": "Who needs to decide, and what evidence would help?",
    }
    underfunded = UNDERFUNDED_HIGH_CONVICTION
    quiet_funded = FUNDED_LOW_CONVICTION[0]
    mentionable_projects = [p for p in projects if p["Initiative / Project Name *"] not in FUNDED_LOW_CONVICTION]
    missing_baseline = "Crew recovery baseline by hub bank"
    rogue_vendor = "TerminalWorks Legacy Support"
    rows = []
    total_statements = sum(interview_question_count(interview, i) for i, interview in enumerate(interviews, 1))
    mention_targets = {
        "initiative": round(total_statements * 0.40),
        "application": round(total_statements * 0.25),
        "platform": round(total_statements * 0.15),
        "vendor": round(total_statements * 0.20),
        "kpi": round(total_statements * 0.15),
    }
    mention_counts = Counter()
    theme_priority = {
        "strategy": ["initiative", "kpi", "vendor", "application", "platform"],
        "cost": ["initiative", "vendor", "kpi", "application", "platform"],
        "reliability": ["initiative", "application", "kpi", "platform", "vendor"],
        "talent": ["initiative", "vendor", "application", "platform", "kpi"],
        "data": ["platform", "kpi", "application", "initiative", "vendor"],
        "AI": ["initiative", "platform", "vendor", "kpi", "application"],
        "vendor": ["vendor", "application", "initiative", "platform", "kpi"],
        "risk": ["application", "kpi", "vendor", "initiative", "platform"],
        "decision rights": ["initiative", "vendor", "kpi", "application", "platform"],
    }
    for i, interview in enumerate(interviews, 1):
        scope = interview["Business Function / IT Portfolio *"]
        count = interview_question_count(interview, i)
        for j in range(count):
            theme = themes[(i + j) % len(themes)]
            initiative = RNG.choice(mentionable_projects)["Initiative / Project Name *"]
            if j in {2, 7, 13} and i % 4 in {0, 1}:
                initiative = RNG.choice(underfunded)
            if j == 5 and i in {3, 19}:
                initiative = "Crew Recovery Wave 1"
            app = RNG.choice(apps)
            platform = RNG.choice(platforms)
            vendor = rogue_vendor if (theme == "vendor" and i % 9 in {0, 3}) else RNG.choice(contracts)["vendor_name"]
            kpi = RNG.choice(kpis)
            must_initiative = initiative in underfunded or (initiative == "Crew Recovery Wave 1" and i in {3, 19})
            slot_roll = (len(rows) + 1) % 100
            slots = 0 if slot_roll < 20 else 1 if slot_roll < 70 else 2 if slot_roll < 92 else 3
            if must_initiative or vendor == rogue_vendor:
                slots = max(1, slots)
            selected = set()
            if must_initiative and mention_counts["initiative"] < mention_targets["initiative"]:
                selected.add("initiative")
                mention_counts["initiative"] += 1
            if vendor == rogue_vendor and len(selected) < slots and mention_counts["vendor"] < mention_targets["vendor"]:
                selected.add("vendor")
                mention_counts["vendor"] += 1
            for field in theme_priority[theme]:
                if len(selected) >= slots:
                    break
                if field in selected:
                    continue
                if mention_counts[field] < mention_targets[field]:
                    selected.add(field)
                    mention_counts[field] += 1
            include_initiative = "initiative" in selected
            include_app = "application" in selected
            include_platform = "platform" in selected
            include_vendor = "vendor" in selected
            include_kpi = "kpi" in selected
            value_phrase = "I am describing the value as avoided disruption cost" if (initiative == "Customer Disruption Management Wave 1" and "CFO" in interview["Title *"]) else "I am describing the value as customer trust and recovery speed"
            baseline_phrase = f"What I still do not see is the {missing_baseline}; without it, I cannot tell whether the work is moving the operating number." if initiative == "Crew Recovery Wave 1" and i in {3, 19} else ""
            initiative_phrase = f"I keep coming back to {initiative} because it shows how {scope} makes decisions under pressure." if include_initiative else f"I keep coming back to the decision pattern because it shows how {scope} makes tradeoffs under pressure."
            app_phrase = f"The {app['Application / Platform Name *']} path gives us signals," if include_app else "The operational signal path gives us clues,"
            platform_phrase = f"but the evidence is still scattered across {platform['Platform / Estate Name *']}." if include_platform else "but the evidence is still scattered across teams and handoffs."
            vendor_phrase = f"When {vendor} is involved, the constraint is less about intent and more about timing, contract leverage, and who owns the next decision." if include_vendor else "The constraint is less about intent and more about timing, accountability, and who owns the next decision."
            response = (
                f"{initiative_phrase} "
                f"{app_phrase} {platform_phrase} "
                f"{baseline_phrase} {value_phrase if initiative == 'Customer Disruption Management Wave 1' else 'The business case feels plausible, but I want a cleaner line from funding to operational KPI movement.'} "
                f"{vendor_phrase}"
            ).replace("  ", " ").strip()
            rows.append({
                "statement_id": f"STMT-{len(rows)+1:04d}",
                "interview_id": interview["interview_id"],
                "interviewee": interview["Interviewee *"],
                "title": interview["Title *"],
                "business_function": scope,
                "business_function_ref": maps["function"].get(scope, ""),
                "portfolio_ref": maps["portfolio"].get(scope, ""),
                "question": questions[theme],
                "response": response,
                "theme": theme,
                "sentiment": RNG.choice(["positive", "neutral", "frustrated", "resigned"]),
                "initiative_mentioned": initiative if include_initiative else "",
                "initiative_ref": maps["project"].get(initiative, "") if include_initiative else "",
                "application_mentioned": app["Application / Platform Name *"] if include_app else "",
                "application_ref": maps["application"].get(app["Application / Platform Name *"], "") if include_app else "",
                "platform_mentioned": platform["Platform / Estate Name *"] if include_platform else "",
                "platform_ref": maps["platform"].get(platform["Platform / Estate Name *"], "") if include_platform else "",
                "vendor_mentioned": vendor if include_vendor else "",
                "vendor_ref": maps["vendor"].get(vendor, "") if include_vendor else "",
                "kpi_mentioned": kpi["KPI Name *"] if include_kpi else "",
                "kpi_ref": maps["kpi"].get(kpi["KPI Name *"], "") if include_kpi else "",
                "pain_point": RNG.choice(["baseline missing", "funding below conviction", "vendor constraint", "data lineage gap", "decision owner unclear"]),
                "evidence_needed": baseline_phrase or RNG.choice(["funding-to-KPI trace", "contract benchmark", "trend baseline", "owner decision log", "system telemetry"]),
                "decision_supported": RNG.choice(["fund", "defer", "reframe", "source", "sequence dependency"]),
                "priority_rank": str(1 + (j % 5)),
                "approval_state": RNG.choice(["not reviewed", "leader-confirmed", "needs evidence", "decision pending"]),
                "content_authenticity": "synthetic_demo",
                "confidence": RNG.choice(["high", "medium", "estimated"]),
                "source_confidence": RNG.choice(["completed interview", "synthetic retrieval test", "generated from v3 scenario"]),
                "_candidate_initiative": initiative,
                "_candidate_initiative_ref": maps["project"].get(initiative, ""),
                "_candidate_application": app["Application / Platform Name *"],
                "_candidate_application_ref": maps["application"].get(app["Application / Platform Name *"], ""),
                "_candidate_platform": platform["Platform / Estate Name *"],
                "_candidate_platform_ref": maps["platform"].get(platform["Platform / Estate Name *"], ""),
                "_candidate_vendor": vendor,
                "_candidate_vendor_ref": maps["vendor"].get(vendor, ""),
                "_candidate_kpi": kpi["KPI Name *"],
                "_candidate_kpi_ref": maps["kpi"].get(kpi["KPI Name *"], ""),
            })
    rebalance_mentions(rows, mention_targets)
    for row in rows:
        for key in list(row):
            if key.startswith("_candidate_"):
                del row[key]
    headers["enterprise_it"]["8b_Interview_Statements"] = list(rows[0])
    data["enterprise_it"]["8b_Interview_Statements"] = rows


def interview_question_count(interview, index):
    title = f"{interview.get('Title *', '')} {interview.get('Business Function / IT Portfolio *', '')}"
    is_it = any(token in title.lower() for token in ["technology", "cio", "cto", "ciso", "data", "analytics", "cloud", "architecture", "integration", "cybersecurity", "application managed services", "infrastructure"])
    return 32 + (index % 9) if is_it else 20 + (index % 6)


def rebalance_mentions(rows, targets):
    field_cols = {
        "initiative": ("initiative_mentioned", "initiative_ref"),
        "application": ("application_mentioned", "application_ref"),
        "platform": ("platform_mentioned", "platform_ref"),
        "vendor": ("vendor_mentioned", "vendor_ref"),
        "kpi": ("kpi_mentioned", "kpi_ref"),
    }
    candidate_cols = {
        "initiative": ("_candidate_initiative", "_candidate_initiative_ref"),
        "application": ("_candidate_application", "_candidate_application_ref"),
        "platform": ("_candidate_platform", "_candidate_platform_ref"),
        "vendor": ("_candidate_vendor", "_candidate_vendor_ref"),
        "kpi": ("_candidate_kpi", "_candidate_kpi_ref"),
    }
    def mention_count(row):
        return sum(1 for col, _ in field_cols.values() if row.get(col))
    for field, target in targets.items():
        col, ref = field_cols[field]
        ccol, cref = candidate_cols[field]
        current = sum(1 for row in rows if row.get(col))
        if current < target:
            for max_existing in [1, 2, 0]:
                for row in rows:
                    if current >= target:
                        break
                    existing = mention_count(row)
                    if row.get(col) or existing >= 3 or existing != max_existing:
                        continue
                    row[col] = row.get(ccol, "")
                    row[ref] = row.get(cref, "")
                    if row[col]:
                        current += 1
        elif current > target:
            for row in reversed(rows):
                if current <= target:
                    break
                if not row.get(col):
                    continue
                if field == "initiative" and row[col] in {"Crew Recovery Wave 1", "KPI Semantic Standardization Wave 1", "Data Governance Wave 1"}:
                    continue
                row[col] = ""
                row[ref] = ""
                current -= 1


def update_relationship_hints(maps):
    hints = []
    def add(src, dst, card="many-to-one", confidence="high"):
        hints.append({"from": src, "to": dst, "cardinality": card, "join_confidence": confidence})
    pairs = [
        ("enterprise_it.5_IT_Budget_Allocations.it_portfolio_ref", "enterprise_it.3_IT_Portfolios_Organization.portfolio_id"),
        ("enterprise_it.5_IT_Budget_Allocations.vendor_ref", "enterprise_it.11_Vendors_Contracts.vendor_id"),
        ("enterprise_it.5_IT_Budget_Allocations.application_ref", "enterprise_it.4_Applications_Portfolio.application_id"),
        ("enterprise_it.5_IT_Budget_Allocations.project_ref", "enterprise_it.6_Projects_Investments.project_id"),
        ("enterprise_it.5_IT_Budget_Allocations.business_function_ref", "enterprise_it.2_Business_Functions.function_id"),
        ("enterprise_it.6_Projects_Investments.business_function_ref", "enterprise_it.2_Business_Functions.function_id"),
        ("enterprise_it.6_Projects_Investments.it_portfolio_ref", "enterprise_it.3_IT_Portfolios_Organization.portfolio_id"),
        ("enterprise_it.6_Projects_Investments.business_sponsor_ref", "enterprise_it.leaders.leader_id"),
        ("enterprise_it.7_KPIs_Outcomes.business_function_ref", "enterprise_it.2_Business_Functions.function_id"),
        ("enterprise_it.7_KPIs_Outcomes.related_application_ref", "enterprise_it.4_Applications_Portfolio.application_id"),
        ("enterprise_it.7_KPIs_Outcomes.related_initiative_ref", "enterprise_it.6_Projects_Investments.project_id"),
        ("enterprise_it.8_CXO_Function_Interviews.business_function_ref", "enterprise_it.2_Business_Functions.function_id"),
        ("enterprise_it.8_CXO_Function_Interviews.portfolio_ref", "enterprise_it.3_IT_Portfolios_Organization.portfolio_id"),
        ("enterprise_it.8b_Interview_Statements.initiative_ref", "enterprise_it.6_Projects_Investments.project_id"),
        ("enterprise_it.8b_Interview_Statements.application_ref", "enterprise_it.4_Applications_Portfolio.application_id"),
        ("enterprise_it.8b_Interview_Statements.vendor_ref", "enterprise_it.11_Vendors_Contracts.vendor_id"),
        ("enterprise_it.8b_Interview_Statements.kpi_ref", "enterprise_it.7_KPIs_Outcomes.kpi_id"),
        ("enterprise_it.10_AI_Adoption_Usage.business_function_ref", "enterprise_it.2_Business_Functions.function_id"),
        ("enterprise_it.10_AI_Adoption_Usage.portfolio_ref", "enterprise_it.3_IT_Portfolios_Organization.portfolio_id"),
        ("enterprise_it.10_AI_Adoption_Usage.vendor_ref", "enterprise_it.11_Vendors_Contracts.vendor_id"),
        ("enterprise_it.12_Risks_Controls.affected_application_refs", "enterprise_it.4_Applications_Portfolio.application_id"),
        ("enterprise_it.12_Risks_Controls.business_function_ref", "enterprise_it.2_Business_Functions.function_id"),
        ("enterprise_it.12_Risks_Controls.risk_owner_ref", "enterprise_it.leaders.leader_id"),
        ("enterprise_it.11_Vendors_Contracts.supported_application_refs", "enterprise_it.4_Applications_Portfolio.application_id"),
        ("enterprise_it.11_Vendors_Contracts.supported_function_refs", "enterprise_it.2_Business_Functions.function_id"),
        ("data_analytics.1_Function_Analytics_Profile.function_ref", "enterprise_it.2_Business_Functions.function_id"),
        ("data_analytics.2_Platform_Tech_Stack.technical_owner_ref", "enterprise_it.leaders.leader_id"),
        ("data_analytics.3_Function_Platform_Map.function_ref", "enterprise_it.2_Business_Functions.function_id"),
        ("data_analytics.3_Function_Platform_Map.platform_ref", "data_analytics.2_Platform_Tech_Stack.platform_id"),
        ("data_analytics.4_Source_to_Consumption.function_ref", "enterprise_it.2_Business_Functions.function_id"),
        ("data_analytics.4_Source_to_Consumption.platform_ref", "data_analytics.2_Platform_Tech_Stack.platform_id"),
        ("data_analytics.5_Function_Volumetrics.function_ref", "enterprise_it.2_Business_Functions.function_id"),
        ("data_analytics.6_Findings_Maturity.function_ref", "enterprise_it.2_Business_Functions.function_id"),
        ("data_analytics.6_Findings_Maturity.platform_ref", "data_analytics.2_Platform_Tech_Stack.platform_id"),
        ("data_analytics.7_Initiatives_Roadmap.initiative_ref", "enterprise_it.6_Projects_Investments.project_id"),
        ("cloud_hybrid.4_Workload_Distribution.provider_private_cloud_estate", "cloud_hybrid.estate_registry.estate_name"),
        ("cloud_hybrid.6_Cloud_Operations_Economics.estate_ref", "cloud_hybrid.estate_registry.estate_id"),
        ("cloud_hybrid.6_Cloud_Operations_Economics.portfolio_ref", "enterprise_it.3_IT_Portfolios_Organization.portfolio_id"),
        ("cloud_hybrid.8_Cloud_Initiatives_Roadmap.owner_ref", "enterprise_it.leaders.leader_id"),
        ("cloud_hybrid.7_Cloud_Findings_Maturity.owner_ref", "enterprise_it.leaders.leader_id"),
        ("enterprise_it.11_Vendors_Contracts.renewal_owner_ref", "enterprise_it.leaders.leader_id"),
        ("enterprise_it.5_IT_Budget_Allocations.contract_ref", "enterprise_it.11_Vendors_Contracts.contract_id"),
    ]
    for src, dst in pairs:
        add(src, dst)
    (BASE / "metadata/relationship_hints.json").write_text(json.dumps(hints, indent=2), encoding="utf-8")


def create_messy_variant(data, maps):
    root = BASE / "csv_messy"
    root.mkdir(parents=True, exist_ok=True)
    apps = data["enterprise_it"]["4_Applications_Portfolio"]
    budget = data["enterprise_it"]["5_IT_Budget_Allocations"]
    contracts = data["enterprise_it"]["11_Vendors_Contracts"]
    mapping = {}
    regions = ["americas", "europe", "asia_pacific"]
    for idx, region in enumerate(regions):
        path = root / f"cmdb_{region}_applications.csv"
        headers = ["SkyHarbor CMDB export", "", "", "", "", ""]
        rows = [["generated synthetic messy extract", "", "", "", "", ""], ["Application", "CI Name", "Owner Name", "Svc", "Env", "Notes"]]
        for app in apps[idx * 160: idx * 160 + 210]:
            app_name = messy_app_name(app["Application / Platform Name *"])
            owner = messy_owner_name(app["Business Owner *"])
            hosting = messy_hosting(app["Hosting Model *"])
            criticality = RNG.choice(["Tier 1", "tier-1", "Critical", "P1", "1", "", "N/A", "unknown"])
            rows.append([app_name, app["application_id"], owner, app["Application Domain *"], hosting, criticality])
            if stable_int(app["application_id"]) % 97 == 0:
                rows.append([app_name.replace(" ", "-").upper()[:28], app["application_id"], owner, app["Application Domain *"], hosting.lower(), criticality])
        rows.append(["TOTAL", str(len(rows) - 2), "", "", "", "ignore"])
        write_raw_csv(path, rows)
        mapping[path.name] = {
            "Application": "Application / Platform Name *",
            "CI Name": "application_id",
            "Owner Name": "Business Owner *",
            "Svc": "Application Domain *",
            "Env": "Hosting Model *",
            "Notes": "Business Criticality *",
            "header_row": 3,
            "ignore_rows": ["title rows", "TOTAL row"],
        }
    path = root / "budget_cost_center_actuals.csv"
    rows = [["SkyHarbor finance export", "", "", "", ""], ["FY2027 cost center rollup", "", "", "", ""], ["Cost Centre", "Portfolio", "Supplier", "Amount USD", "Scenario"]]
    by_cc = Counter()
    for r in budget:
        if r["Fiscal Year *"] == "2027":
            by_cc[(r["Budget / Cost Center"], r["IT Portfolio *"], r["Vendor"])] += int(parse_num(r["Budget Amount *"]))
    for (cc, port, vendor), amount in list(by_cc.items())[:350]:
        amount_value = messy_money(amount)
        scenario = RNG.choice(["current budget", "Current Budget", "FY27 plan", "budget", ""])
        rows.append([cc, port, vendor_alias(vendor), amount_value, scenario])
    rows.append(["Grand Total", "", "", str(sum(by_cc.values())), "ignore"])
    write_raw_csv(path, rows)
    mapping[path.name] = {"Cost Centre": "Budget / Cost Center", "Portfolio": "IT Portfolio *", "Supplier": "Vendor", "Amount USD": "Budget Amount *", "Scenario": "Scenario *", "header_row": 3, "wrong_grain": "cost-center/vendor/portfolio, no application attribution"}
    path = root / "itsm_service_extract.csv"
    rows = [["Service", "App Name", "Incident Priority", "Open Count", "Service Owner"]]
    for app in apps[80:260]:
        rows.append([messy_app_name(app["Application / Platform Name *"]), app["Application / Platform Name *"].replace(" ", "-").upper()[:26], RNG.choice(["Tier 1", "P1", "Critical", "1", "sev1", ""]), str(RNG.randint(0, 42)), messy_owner_name(app["Business Owner *"])])
    write_raw_csv(path, rows)
    mapping[path.name] = {"Service": "Application / Platform Name *", "App Name": "application_alias", "Incident Priority": "Business Criticality *", "Open Count": "incident_count", "Service Owner": "Business Owner *"}
    path = root / "vendor_renewal_tracker.csv"
    rows = [["Vendor", "Agreement", "Renewal", "Notice", "Auto?", "Bench clause"]]
    for c in contracts[:90]:
        rows.append([vendor_alias(c["vendor_name"]), c["contract_name"], c["end_date"], c["notice_period_days"], yes_no_alias(c["auto_renew"]), c["benchmarking_clause"]])
    write_raw_csv(path, rows)
    mapping[path.name] = {"Vendor": "vendor_name", "Agreement": "contract_name", "Renewal": "end_date", "Notice": "notice_period_days", "Auto?": "auto_renew", "Bench clause": "benchmarking_clause"}
    write_raw_csv(root / "pivot_summary_ignore.csv", [["Pivot Table"], ["Rows", "Columns", "Values"], ["Portfolio", "Vendor", "Spend"]])
    write_raw_csv(root / "empty_export.csv", [])
    mapping["pivot_summary_ignore.csv"] = {"ignore_file": True, "reason": "pivot-style summary, not row-grain source"}
    mapping["empty_export.csv"] = {"ignore_file": True, "reason": "empty tab equivalent"}
    (root / "EXPECTED_MAPPING.json").write_text(json.dumps(enrich_expected_mapping(mapping), indent=2), encoding="utf-8")


def messy_app_name(name: str) -> str:
    if "Amadeus" in name or "Altéa" in name:
        return RNG.choice(["Amadeus Altéa DCS", "Altea Departure Control", "ALTEA-DCS"])
    words = name.split()
    return RNG.choice([" ".join(words[:4]), "-".join(words[:3]).upper(), name.replace(" Platform", ""), name])


def messy_owner_name(name: str) -> str:
    return RNG.choice([name, name.upper(), name.lower(), f" {name} ", name.replace(" ", "  "), "Unknown" if stable_int(name) % 31 == 0 else name])


def messy_hosting(value: str) -> str:
    aliases = {
        "Public cloud": ["Public cloud", "public-cloud", "Cloud", "pub cloud"],
        "Private cloud": ["Private cloud", "private-cloud", "pvt cloud"],
        "Hybrid": ["Hybrid", "hybrid/mixed", "mixed"],
        "SaaS": ["SaaS", "saas", "vendor hosted"],
        "On-premises": ["On-premises", "On Prem", "DC hosted"],
    }
    return RNG.choice(aliases.get(value, [value, value.lower(), "unknown"]))


def messy_money(amount: int) -> str:
    options = [str(amount), f"{amount:,}", f"${amount:,}", f"${amount / 1_000_000:.1f}M"]
    if stable_int(str(amount)) % 23 == 0:
        options.extend(["Unknown", "-", ""])
    return RNG.choice(options)


def vendor_alias(name: str) -> str:
    aliases = [name, name.upper(), name.replace("Microsoft", "MSFT"), name.replace("Amazon Web Services", "AWS"), name.replace("Google Cloud", "GCP")]
    return RNG.choice(aliases)


def yes_no_alias(value: str) -> str:
    return RNG.choice({"Yes": ["Yes", "Y", "true", "1"], "No": ["No", "N", "false", "0"]}.get(value, [value, "unknown"]))


def enrich_expected_mapping(mapping):
    enriched = {
        "mapping_scope": "synthetic messy extracts for raw_mapping_test; value rules are expected normalizations, not load blockers",
        "files": {},
    }
    value_rules = [
        {"canonical_column": "Business Criticality *", "canonical_value": "Critical", "source_value": "Tier 1|tier-1|P1|1|sev1", "normalization_rule": "criticality_alias_to_critical", "mapping_type": "normalized"},
        {"canonical_column": "Hosting Model *", "canonical_value": "Public cloud", "source_value": "public-cloud|Cloud|pub cloud", "normalization_rule": "hosting_alias_to_public_cloud", "mapping_type": "normalized"},
        {"canonical_column": "Hosting Model *", "canonical_value": "Private cloud", "source_value": "private-cloud|pvt cloud|DC hosted", "normalization_rule": "hosting_alias_to_private_or_dc", "mapping_type": "normalized"},
        {"canonical_column": "Budget Amount *", "canonical_value": "numeric_usd", "source_value": "$1.2M|1,200,000|Unknown|-|blank", "normalization_rule": "currency_parse_with_missing_status", "mapping_type": "normalized"},
        {"canonical_column": "Business Owner *", "canonical_value": "trimmed_person_name", "source_value": "uppercase|lowercase|extra_spaces|Unknown", "normalization_rule": "trim_casefold_and_missing_owner_status", "mapping_type": "inferred"},
        {"canonical_column": "Application / Platform Name *", "canonical_value": "canonical_application_name", "source_value": "hyphenated|truncated|product alias", "normalization_rule": "application_alias_dictionary_or_unresolved", "mapping_type": "inferred"},
    ]
    for file_name, spec in mapping.items():
        if spec.get("ignore_file"):
            enriched["files"][file_name] = {
                "ignore_file": True,
                "reason": spec.get("reason", ""),
                "column_mappings": [],
                "value_mappings": [],
            }
            continue
        column_mappings = []
        for source, canonical in spec.items():
            if source in {"header_row", "ignore_rows", "wrong_grain"}:
                continue
            column_mappings.append({
                "source_column": source,
                "canonical_column": canonical,
                "original_header": source,
                "normalization_rule": "snake_case_header_plus_domain_mapping",
                "mapping_type": "exact" if source == canonical else "inferred",
            })
        enriched["files"][file_name] = {
            "header_row": spec.get("header_row", 1),
            "ignore_rows": spec.get("ignore_rows", []),
            "wrong_grain": spec.get("wrong_grain", ""),
            "column_mappings": column_mappings,
            "value_mappings": value_rules,
        }
    return enriched


def write_raw_csv(path: Path, rows):
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerows(rows)


def write_all_csv(headers, data):
    for kind, sheets in data.items():
        for sheet, rows in sheets.items():
            write_csv(BASE / "csv" / kind / SHEET_CSV[kind][sheet], headers[kind][sheet], rows)


def update_workbooks(headers, data):
    for kind, workbook_path in WORKBOOKS.items():
        wb = load_workbook(workbook_path)
        for sheet, csv_name in SHEET_CSV[kind].items():
            if sheet not in data[kind]:
                continue
            ws = wb[sheet] if sheet in wb.sheetnames else wb.create_sheet(sheet)
            write_sheet(ws, headers[kind][sheet], data[kind][sheet])
        add_intake_guide_sheet(wb, kind)
        refresh_validation_summary(wb, data[kind])
        wb.save(workbook_path)
        wb.close()


def write_sheet(ws, headers, rows):
    for row in ws.iter_rows():
        for cell in row:
            cell.value = None
    for c, h in enumerate(headers, 1):
        cell = ws.cell(1, c, h)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1F4E78")
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        ws.column_dimensions[get_column_letter(c)].width = min(max(len(h) + 2, 14), 44)
    active_col = headers.index("Active Rate") + 1 if "Active Rate" in headers else None
    for r_idx, row in enumerate(rows, 2):
        for c_idx, h in enumerate(headers, 1):
            if h == "Active Rate" and active_col:
                ws.cell(r_idx, c_idx, f'=IFERROR(IF(H{r_idx}>0,I{r_idx}/H{r_idx},""),"")')
            else:
                ws.cell(r_idx, c_idx, typed_value(row.get(h, "")))
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions


def typed_value(value):
    if value in ("", None):
        return None
    if isinstance(value, (int, float, date, datetime)):
        return value
    text = str(value)
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", text):
        return datetime.strptime(text, "%Y-%m-%d").date()
    if re.fullmatch(r"-?\d+", text):
        return int(text)
    if re.fullmatch(r"-?\d+\.\d+", text):
        return float(text)
    return text


def add_intake_guide_sheet(wb, kind):
    title = "INTAKE_GUIDE"
    if title in wb.sheetnames:
        del wb[title]
    ws = wb.create_sheet(title, 1)
    rows = [
        ["Section", "Client expert / owner", "Best source documents", "Interview prompts", "Sign-off evidence before load"],
        ["Scope and grain", "Client data steward plus relevant IT/business owner", "System exports, data dictionaries, template extracts, current assessment decks", "Is this one row per source object, observation, budget line, or statement? What rows should be ignored?", "Named owner confirms row grain, time period, and source system."],
        ["Enterprise IT", "CIO office, technology finance, portfolio leads, enterprise architecture, application owners", "IT budget workbook, project portfolio export, CMDB/APM, vendor register, KPI packs, audit/risk register", "Which facts are system-of-record, estimates, disputed, or interview-only? Which totals must tie out and which measures are non-additive?", "CIO/finance/data steward signs off source file list, worksheet list, required-field meaning, and budget/reconciliation caveats."],
        ["Data and analytics", "CDAO office, platform owners, BI/product leads, data governance, business analytics leaders", "BI inventory, data catalog, lineage exports, platform usage, semantic metric dictionary, backlog/roadmap", "Where do definitions conflict? Which KPIs are governed? Which platform mappings are incomplete but still useful?", "CDAO or delegate approves glossary assumptions, known gaps, and unresolved mapping exceptions."],
        ["Cloud and hybrid", "CTO/infrastructure, cloud platform teams, FinOps, SRE/DR, cybersecurity", "Cloud billing exports, CMDB hosting fields, landing-zone inventory, DR test evidence, cost/tag reports, migration plans", "Which workload counts are authoritative? Which cost periods should not be added? Which controls are never tested?", "Infrastructure/FinOps owner approves billing period, allocation basis, and contract-backed versus internal/noncontracted spend treatment."],
        ["Interviews", "Executive sponsor, chief of staff, portfolio/product leads, operations leaders", "Interview notes, workshop transcripts, decision logs, steering committee minutes", "What has conviction but no funding? What is funded but weakly visible? What evidence would change the decision?", "Interview owner signs off use of statements as synthetic/current-state evidence with source-confidence labels."],
        ["Raw load gate", "Client sponsor plus Abarva operator", "Completed workbook pack, CSV mirrors, manifest, validation report, source-file hash ledger", "Are there any worksheets excluded from raw load? Are any files still drafts? Who approves loading unchanged raw text?", "Written sign-off captured before PostgreSQL load. Loading is blocked until corrupt/unreadable files and duplicate normalized headers are resolved."],
    ]
    for r_idx, row in enumerate(rows, 1):
        for c_idx, value in enumerate(row, 1):
            cell = ws.cell(r_idx, c_idx, value)
            cell.alignment = Alignment(wrap_text=True, vertical="top")
            if r_idx == 1:
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = PatternFill("solid", fgColor="7030A0")
    widths = [24, 34, 42, 48, 46]
    for i, width in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = width
    ws.freeze_panes = "A2"


def refresh_validation_summary(wb, workbook_data):
    if "VALIDATION_SUMMARY" not in wb.sheetnames:
        return
    ws = wb["VALIDATION_SUMMARY"]
    row = ws.max_row + 2
    ws.cell(row, 1, "V3 row counts")
    ws.cell(row, 1).font = Font(bold=True)
    row += 1
    for sheet, rows in sorted(workbook_data.items()):
        ws.cell(row, 1, "V3 Loadable sheet")
        ws.cell(row, 2, sheet)
        ws.cell(row, 3, len(rows))
        row += 1


def update_metadata(headers, data):
    manifest = {
        "dataset_id": "skyharbor_global_synthetic_current_state_v3",
        "synthetic": True,
        "seed": SEED,
        "version": "v3",
        "workbooks": [],
        "non_additive_measures": [
            "FY2026 prior-year actual budget is a separate declared total and must not be added to FY2027 budget.",
            "contract annual value is a vendor-attributed contract-backed subset of FY2027 budget and must not be treated as total IT spend.",
        ],
        "raw_load_contract": {
            "table_grain": "one raw PostgreSQL table per source CSV/workbook sheet",
            "clean_csv_tables": 28,
            "raw_column_type": "text",
            "business_transformation_before_load": False,
            "technical_lineage_columns": ["_source_file", "_source_sheet", "_source_row_number", "_source_row_jsonb", "_load_run_id", "_loaded_at", "_row_hash"],
            "blocking_gate": "client sign-off plus technical readability/header-disambiguation checks only; business quality findings do not block raw landing",
        },
        "client_signoff_required_before_load": True,
    }
    coldict = []
    load_order = []
    for kind, sheets in data.items():
        wb_file = WORKBOOKS[kind].name
        wb_entry = {"key": kind, "file": wb_file, "sheets": []}
        for sheet, rows in sheets.items():
            csv_path = f"csv/{kind}/{SHEET_CSV[kind][sheet]}"
            entry = {"sheet": sheet, "csv": csv_path, "row_count": len(rows), "row_grain": grain(sheet), "source_workbook": wb_file}
            wb_entry["sheets"].append(entry)
            load_order.append(entry)
            types = infer_types(headers[kind][sheet], rows)
            for h in headers[kind][sheet]:
                coldict.append({
                    "workbook_key": kind,
                    "source_workbook": wb_file,
                    "source_sheet": sheet,
                    "source_column": h,
                    "postgres_column": snake(h),
                    "inferred_type": types[h],
                    "row_grain": grain(sheet),
                    "likely_dimension": types[h] in {"text", "date"} and "description" not in h.lower(),
                    "likely_measure": types[h] in {"integer", "numeric", "percent"},
                })
        manifest["workbooks"].append(wb_entry)
    write_json(BASE / "metadata/dataset_manifest.json", manifest)
    write_json(BASE / "metadata/column_dictionary.json", coldict)
    write_json(BASE / "metadata/load_order.json", {"schemas": ["raw_enterprise_it", "raw_data_analytics", "raw_cloud_hybrid"], "order": load_order})


def infer_types(headers, rows):
    out = {}
    for h in headers:
        vals = [r.get(h, "") for r in rows if r.get(h, "") != ""][:100]
        if not vals:
            out[h] = "text"
        elif all(re.fullmatch(r"-?\d+", str(v)) for v in vals):
            out[h] = "integer"
        elif all(re.fullmatch(r"-?\d+(\.\d+)?", str(v)) for v in vals):
            out[h] = "numeric"
        elif all(re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(v)) for v in vals):
            out[h] = "date"
        elif "rate" in h.lower() or "percent" in h.lower():
            out[h] = "percent"
        else:
            out[h] = "text"
    return out


def grain(sheet):
    return {
        "8b_Interview_Statements": "one interview statement",
        "11_Vendors_Contracts": "one vendor contract",
        "12_Risks_Controls": "one risk/control record",
    }.get(sheet, "one source row")


def pct_ratio(count, total):
    return round(count / total, 4) if total else 0


def mention_plausibility(statements):
    fields = {
        "initiative": "initiative_mentioned",
        "application": "application_mentioned",
        "platform": "platform_mentioned",
        "vendor": "vendor_mentioned",
        "kpi": "kpi_mentioned",
    }
    counts_by_row = [sum(1 for col in fields.values() if r.get(col)) for r in statements]
    return {
        "rates": {field: pct_ratio(sum(1 for r in statements if r.get(col)), len(statements)) for field, col in fields.items()},
        "no_structured_mention_rate": pct_ratio(sum(1 for c in counts_by_row if c == 0), len(statements)),
        "zero_or_one_structured_entity_rate": pct_ratio(sum(1 for c in counts_by_row if c <= 1), len(statements)),
        "three_plus_structured_entity_rate": pct_ratio(sum(1 for c in counts_by_row if c >= 3), len(statements)),
        "initiative_mentions": Counter(r.get("initiative_mentioned", "") for r in statements if r.get("initiative_mentioned")),
    }


def project_inversion_cohorts(projects, statements):
    mentions = Counter(r.get("initiative_mentioned", "") for r in statements if r.get("initiative_mentioned"))
    nonzero_mentions = sorted(mentions.values())
    high_cutoff = nonzero_mentions[int(len(nonzero_mentions) * 0.75)] if nonzero_mentions else 0
    low_cutoff = nonzero_mentions[int(len(nonzero_mentions) * 0.25)] if nonzero_mentions else 0
    budgets = sorted(int(parse_num(p.get("Approved Budget", "0"))) for p in projects)
    upper_middle_budget = budgets[int(len(budgets) * 0.60)] if budgets else 0
    high_conviction_underfunded = []
    well_funded_low_conviction = []
    bad_status = {"On hold", "Awaiting decision", "At risk"}
    bad_funding = {"Unfunded", "Partially funded", "Approved with constraint"}
    for p in projects:
        name = p["Initiative / Project Name *"]
        mention_count = mentions.get(name, 0)
        approved = int(parse_num(p.get("Approved Budget", "0")))
        if mention_count >= high_cutoff and (p.get("Status *") in bad_status or p.get("Funding Status") in bad_funding):
            high_conviction_underfunded.append({
                "initiative": name,
                "mentions": mention_count,
                "approved_budget": approved,
                "status": p.get("Status *", ""),
                "funding_status": p.get("Funding Status", ""),
                "sponsor": p.get("Business Sponsor *", ""),
                "consequence": p.get("Major Risk / Constraint", ""),
            })
        if approved >= upper_middle_budget and mention_count <= low_cutoff and (
            "Directional" in p.get("KPIs / Outcomes Affected", "") or "limited executive visibility" in p.get("Expected Business / Technology Value *", "")
        ):
            well_funded_low_conviction.append({
                "initiative": name,
                "mentions": mention_count,
                "approved_budget": approved,
                "status": p.get("Status *", ""),
                "funding_status": p.get("Funding Status", ""),
                "kpi_linkage": p.get("KPIs / Outcomes Affected", ""),
            })
    return high_conviction_underfunded, well_funded_low_conviction


def messy_value_inconsistency_present():
    root = BASE / "csv_messy"
    values = defaultdict(set)
    for path in root.glob("*.csv"):
        if path.name in {"empty_export.csv", "pivot_summary_ignore.csv"}:
            continue
        with path.open(newline="", encoding="utf-8") as f:
            rows = list(csv.reader(f))
        for row in rows:
            for value in row:
                text = (value or "").strip()
                if text:
                    values[text.lower()].add(value)
    has_case_or_spacing_alias = any(len(forms) > 1 for forms in values.values())
    expected = json.loads((root / "EXPECTED_MAPPING.json").read_text())
    has_value_rules = any(
        item.get("mapping_type") in {"normalized", "inferred", "unresolved"}
        for spec in expected.get("files", {}).values()
        for item in spec.get("value_mappings", [])
    )
    return has_case_or_spacing_alias and has_value_rules


def validate_v2(data):
    issues = []
    budget = data["enterprise_it"]["5_IT_Budget_Allocations"]
    fy2027 = [r for r in budget if r["Fiscal Year *"] == "2027"]
    fy2026 = [r for r in budget if r["Fiscal Year *"] == "2026"]
    if sum(int(parse_num(r["Budget Amount *"])) for r in fy2027) != FY2027_TOTAL:
        issues.append("FY2027 budget reconciliation failed")
    if sum(int(parse_num(r["Budget Amount *"])) for r in fy2026) != FY2026_TOTAL:
        issues.append("FY2026 budget reconciliation failed")
    vendor_budget = Counter()
    for r in fy2027:
        if r.get("Vendor"):
            vendor_budget[r["Vendor"]] += int(parse_num(r["Budget Amount *"]))
    vendor_contract = Counter()
    for r in data["enterprise_it"]["11_Vendors_Contracts"]:
        vendor_contract[r["vendor_name"]] += int(parse_num(r["annual_value"]))
    contract_total = sum(vendor_contract.values())
    contract_coverage = contract_total / FY2027_TOTAL
    contract_backed = sum(int(parse_num(r.get("contract_backed_amount", "0"))) for r in fy2027)
    internal_noncontracted = sum(int(parse_num(r.get("internal_noncontracted_amount", "0"))) for r in fy2027)
    if not (0.60 <= contract_coverage <= 0.65):
        issues.append(f"contract coverage outside 60-65%: {contract_coverage:.2%}")
    if contract_total != contract_backed:
        issues.append(f"contract annual value does not tie to vendor-attributed spend: {contract_total} != {contract_backed}")
    if contract_backed + internal_noncontracted != FY2027_TOTAL:
        issues.append("contract-backed plus internal/noncontracted spend does not equal FY2027 budget")
    if any(
        int(parse_num(r.get("annual_value", "0"))) == int(parse_num(r.get("total_committed_value", "0"))) == int(parse_num(r.get("committed_annual_spend", "0"))) == int(parse_num(r.get("actual_annual_spend", "0")))
        for r in data["enterprise_it"]["11_Vendors_Contracts"]
    ):
        issues.append("contract annual/committed/actual values contain an identical-value row")
    risk_rows = data["enterprise_it"]["12_Risks_Controls"]
    blank_controls = sum(1 for r in risk_rows if not r.get("control_last_tested_date"))
    if not (0.20 <= blank_controls / len(risk_rows) <= 0.30):
        issues.append("risk never-tested control ratio outside 20-30%")
    for r in risk_rows:
        if not r.get("control_last_tested_date") and (r.get("control_test_result") != "never_tested" or r.get("control_test_evidence_ref")):
            issues.append(f"never-tested control has date/result/evidence contradiction: {r.get('risk_id')}")
        if r.get("control_last_tested_date") and r.get("control_test_result") not in {"passed", "partially_passed", "failed", "ineffective", "unknown"}:
            issues.append(f"dated control has invalid result: {r.get('risk_id')}")
    statements = data["enterprise_it"]["8b_Interview_Statements"]
    if len(statements) < 960:
        issues.append("interview statement count below 20 per 48 interviews")
    statements_by_interview = Counter(r.get("interview_id") for r in statements)
    missing_interview_minimum = [r["interview_id"] for r in data["enterprise_it"]["8_CXO_Function_Interviews"] if statements_by_interview[r["interview_id"]] < 20]
    if missing_interview_minimum:
        issues.append(f"interviews below 20 statements: {missing_interview_minimum[:5]}")
    mention_report = mention_plausibility(statements)
    rate_bounds = {
        "initiative": (0.38, 0.47),
        "application": (0.23, 0.32),
        "platform": (0.13, 0.22),
        "vendor": (0.18, 0.27),
        "kpi": (0.13, 0.22),
    }
    for field, (lo, hi) in rate_bounds.items():
        rate = mention_report["rates"][field]
        if not (lo <= rate <= hi):
            issues.append(f"{field} mention rate outside target: {rate:.1%}")
    if not (0.18 <= mention_report["no_structured_mention_rate"] <= 0.27):
        issues.append(f"no structured mention rate outside target: {mention_report['no_structured_mention_rate']:.1%}")
    if mention_report["zero_or_one_structured_entity_rate"] < 0.70:
        issues.append("zero-or-one structured entity rate below 70%")
    if mention_report["three_plus_structured_entity_rate"] > 0.10:
        issues.append("three-plus structured entity rate above 10%")
    high_conviction_underfunded, well_funded_low_conviction = project_inversion_cohorts(data["enterprise_it"]["6_Projects_Investments"], statements)
    if len(high_conviction_underfunded) < 3:
        issues.append("fewer than 3 high-conviction underfunded initiatives")
    if len(well_funded_low_conviction) < 3:
        issues.append("fewer than 3 well-funded low-conviction initiatives")
    if not (90 <= len(data["enterprise_it"]["11_Vendors_Contracts"]) <= 130):
        issues.append("vendor contract count outside 90-130")
    if any(r["vendor_name"] == "TerminalWorks Legacy Support" for r in data["enterprise_it"]["11_Vendors_Contracts"]):
        issues.append("deliberately unmatched statement vendor has a contract record")
    if len(data["enterprise_it"]["7_KPIs_Outcomes"]) != 960:
        issues.append("KPI temporal depth is not 960 rows")
    if len(data["cloud_hybrid"]["4_Workload_Distribution"]) != 720:
        issues.append("workload temporal depth is not 720 rows")
    if len(data["cloud_hybrid"]["6_Cloud_Operations_Economics"]) != 240:
        issues.append("cloud economics temporal depth is not 240 rows")
    if len(data["enterprise_it"]["10_AI_Adoption_Usage"]) != 480:
        issues.append("AI adoption temporal depth is not 480 rows")
    relationship_hints = json.loads((BASE / "metadata/relationship_hints.json").read_text())
    if len(relationship_hints) < 40:
        issues.append("relationship_hints.json has fewer than 40 entries")
    if not messy_value_inconsistency_present():
        issues.append("messy corpus lacks expected within-file value inconsistency rules/examples")
    validation = json.loads((BASE / "validation/validation_report.json").read_text())
    sheet_rows = {SHEET_CSV[kind][sheet].replace(".csv", ""): len(rows) for kind, sheets in data.items() for sheet, rows in sheets.items()}
    validation.update({
        "status": "pass" if not issues else "fail",
        "issues": issues,
        "version": "v3",
        "row_counts": {
            "enterprise_context": len(data["enterprise_it"]["1_Enterprise_Context"]),
            "functions": len(data["enterprise_it"]["2_Business_Functions"]),
            "portfolios": len(data["enterprise_it"]["3_IT_Portfolios_Organization"]),
            "applications": len(data["enterprise_it"]["4_Applications_Portfolio"]),
            "budget_rows": len(budget),
            "projects": len(data["enterprise_it"]["6_Projects_Investments"]),
            "kpis": len(data["enterprise_it"]["7_KPIs_Outcomes"]),
            "interviews": len(data["enterprise_it"]["8_CXO_Function_Interviews"]),
            "interview_statement_rows": len(statements),
            "feeds": len(data["enterprise_it"]["9_Operational_Usage_Feeds"]),
            "ai_rows": len(data["enterprise_it"]["10_AI_Adoption_Usage"]),
            "vendor_contract_rows": len(data["enterprise_it"]["11_Vendors_Contracts"]),
            "risk_control_rows": len(risk_rows),
            "clean_csv_tables": sum(len(sheets) for sheets in SHEET_CSV.values()),
            "clean_csv_rows": sum(sheet_rows.values()),
        },
        "sheet_row_counts": sheet_rows,
        "fy2027_budget_total": sum(int(parse_num(r["Budget Amount *"])) for r in fy2027),
        "fy2026_prior_year_actual_total": sum(int(parse_num(r["Budget Amount *"])) for r in fy2026),
        "contract_annual_value_total": contract_total,
        "contract_coverage_of_fy2027_budget": round(contract_coverage, 4),
        "contract_backed_fy2027_spend": contract_backed,
        "internal_noncontracted_fy2027_spend": internal_noncontracted,
        "mention_distribution": {
            "rates": mention_report["rates"],
            "no_structured_mention_rate": mention_report["no_structured_mention_rate"],
            "zero_or_one_structured_entity_rate": mention_report["zero_or_one_structured_entity_rate"],
            "three_plus_structured_entity_rate": mention_report["three_plus_structured_entity_rate"],
            "top_initiatives": mention_report["initiative_mentions"].most_common(12),
        },
        "high_conviction_underfunded": high_conviction_underfunded[:8],
        "well_funded_low_conviction": well_funded_low_conviction[:8],
        "interview_statement_minimum": {"required_per_interview": 20, "minimum_observed": min(statements_by_interview.values()) if statements_by_interview else 0},
        "interview_statement_rows": len(statements),
        "vendor_contract_rows": len(data["enterprise_it"]["11_Vendors_Contracts"]),
        "risk_control_rows": len(risk_rows),
        "relationship_hint_count": len(relationship_hints),
        "messy_extract_files": len(list((BASE / "csv_messy").glob("*"))),
        "client_signoff_required_before_load": True,
    })
    write_json(BASE / "validation/validation_report.json", validation)
    (BASE / "validation/validation_report.md").write_text("# Validation Report\n\nStatus: **{}**\n\n- FY2027 budget: ${:,}\n- FY2026 prior-year actuals: ${:,}\n- Contract annual value: ${:,} ({:.1%} of FY2027 budget)\n- Contract-backed FY2027 spend: ${:,}\n- Internal/noncontracted FY2027 spend: ${:,}\n- Interview statements: {} (minimum per interview: {})\n- Vendor contracts: {}\n- Risk/control rows: {}\n- Relationship hints: {}\n- Clean raw CSV tables: {}\n- Clean raw CSV rows: {}\n\n## Mention Distribution\n\n{}\n\n## Issues\n{}".format(
        validation["status"],
        validation["fy2027_budget_total"],
        validation["fy2026_prior_year_actual_total"],
        validation["contract_annual_value_total"],
        validation["contract_coverage_of_fy2027_budget"],
        validation["contract_backed_fy2027_spend"],
        validation["internal_noncontracted_fy2027_spend"],
        validation["interview_statement_rows"],
        validation["interview_statement_minimum"]["minimum_observed"],
        validation["vendor_contract_rows"],
        validation["risk_control_rows"],
        validation["relationship_hint_count"],
        validation["row_counts"]["clean_csv_tables"],
        validation["row_counts"]["clean_csv_rows"],
        "\n".join(f"- {k}: {v:.1%}" for k, v in validation["mention_distribution"]["rates"].items()),
        "\n".join(f"- {i}" for i in issues) if issues else "- No unexplained failures.",
    ), encoding="utf-8")
    return validation


def write_reports(data, validation):
    readme = (BASE / "README.md").read_text(encoding="utf-8")
    readme = readme.replace("Package v1", "Package v3").replace("current-state assessment dataset", "current-state assessment dataset with v3 correction additions")
    readme += "\n## v3 Correction Additions\n\n- Every CXO/executive interview has at least 20 statement-level questions; IT/technology interviews include deeper coverage with no fixed cap.\n- Application and data-platform sheets include practical technical-depth fields such as version, hosting/deployment detail, users, transaction/job volume, storage, capacity, integrations, support model, and evidence source.\n- Mention fields are sparse and conviction-driven rather than 100% populated.\n- Contract annual value is a contract-backed subset of FY2027 spend, not total IT budget.\n- Controls use explicit `never_tested` state when no test date exists.\n- `INTAKE_GUIDE` worksheets describe interview-led and document-led collection plus client sign-off before raw loading.\n- `scripts/load_workbooks_to_postgres.py` lands 28 clean CSVs 1:1 as text with lineage and source-row JSON.\n"
    (BASE / "README.md").write_text(readme, encoding="utf-8")
    lines = [
        "# V3 Correction Crosswalk",
        "",
        "This report records the v3 correction additions and preserves the non-claim boundary: no PostgreSQL write, no canonical promotion, no deployment, no signed-in proof.",
        "",
        "| Addition | Status | Evidence |",
        "| --- | --- | --- |",
        f"| Long-form interview statements | PASS | {validation['interview_statement_rows']} rows in enterprise_it/8b_Interview_Statements. |",
        "| Stable IDs and refs | PASS | Entity sheets and reference-bearing rows include stable IDs/refs while retaining human-readable names. |",
        f"| Vendor contracts | PASS | {validation['vendor_contract_rows']} contract rows; annual value ${validation['contract_annual_value_total']:,}, {validation['contract_coverage_of_fy2027_budget']:.1%} of FY2027 IT budget, tied to contract-backed spend. |",
        f"| Risk/control register | PASS | {validation['risk_control_rows']} rows; never-tested controls remain between 20% and 30%. |",
        f"| Interview depth | PASS | Minimum {validation['interview_statement_minimum']['minimum_observed']} statements per interview; IT interviews are allowed deeper coverage. |",
        "| Practical application/platform depth | PASS | Application and platform sheets include version, hosting/deployment, capacity, usage, storage, integration, support, upgrade posture, and evidence-source fields. |",
        "| Plausibility gates | PASS | Mention sparsity, funding/conviction inversions, contract coverage, control/date consistency, and messy value variance are validated. |",
        "| Client sign-off gate | PASS | Manifest and INTAKE_GUIDE state that raw loading requires client sign-off and only technical readability/header issues block the load. |",
        "| Temporal depth | PASS | KPI rows 960, workload rows 720, cloud economics rows 240, AI adoption rows 480, and FY2026 prior-year budget rows added. |",
        f"| Relationship hints | PASS | {validation['relationship_hint_count']} relationships with cardinality and join confidence. |",
        f"| Messy variant | PASS | csv_messy includes degraded extracts and EXPECTED_MAPPING.json answer key. |",
    ]
    (BASE / "reports/V3_CORRECTION_CROSSWALK.md").write_text("\n".join(lines), encoding="utf-8")
    write_airline_research_note(validation)
    synthesis = (BASE / "reports/CURRENT_STATE_SYNTHESIS.md").read_text(encoding="utf-8")
    synthesis += "\n\n## V3 Flagship Findings Enabled\n\n- Executive conviction can now be counted from interview statements and compared with initiative funding.\n- Vendor leverage can be tested through contracts, renewals, auto-renew terms, benchmarking clauses, and budget-tied spend.\n- Trend questions can be asked across KPIs, budget, workload placement, cloud economics, and AI adoption.\n- Messy client extracts can be mapped against a clean answer key before any canonical transformation is attempted.\n"
    (BASE / "reports/CURRENT_STATE_SYNTHESIS.md").write_text(synthesis, encoding="utf-8")


def write_airline_research_note(validation):
    lines = [
        "# Airline Intake Research Notes",
        "",
        "This note uses public airline and aviation benchmarks to shape a fictional, synthetic $50B-class current-state package. It does not assert facts about any real client.",
        "",
        "## Public benchmark signals used",
        "",
        "- American Airlines reported full-year 2025 revenue of $54.6B, which supports the package scale as a realistic large-network-airline range. Source: https://news.aa.com/news/news-details/2026/American-Airlines-reports-fourth-quarter-and-full-year-2025-financial-results-CORP-FI-01/default.aspx",
        "- United describes more than 100,000 employees, 175M customers, 370+ destinations, seven domestic hubs, and 5,000+ daily departures, which supports the enterprise scale, hub model, and function breadth. Source: https://ir.united.com/",
        "- Delta's 2024 10-K describes operating revenue growth and large-airline financial scale, supporting the revenue and planning-horizon framing. Source: https://www.sec.gov/Archives/edgar/data/27904/000002790425000004/dal-20241231.htm",
        "- SITA 2025 airline IT insights highlight AI in operations control and data integration/consistency as a major barrier, supporting the AI, data-lineage, and operations-control intake topics. Source: https://www.sita.aero/resources/surveys-reports/air-transport-it-insights-2025/airlines/",
        "- IATA digital aircraft operations describes flight operations, air traffic management, ground operations, maintenance, supply chain/logistics, and asset transfer as digital-operations domains, supporting airline-specific workbook coverage. Source: https://www.iata.org/en/programs/ops-infra/techops/digital-aircraft-operations/",
        "",
        "## Practical extraction principle",
        "",
        "The workbook asks for fields that client teams can usually extract from existing documents or systems: CMDB/APM, application owner lists, architecture diagrams, budget and project portfolio exports, cloud billing/tag reports, BI/data catalog reports, vendor registers, risk/control evidence, DR test logs, incident/problem reports, steering committee minutes, and interview notes.",
        "",
        "## Load sign-off boundary",
        "",
        "Before loading, the client sponsor or delegate must sign off the file list, row grain, source period, known gaps, and synthetic/current-state caveats. Raw loading remains source-faithful; business mapping, normalization, and plausibility findings happen after landing.",
        "",
        f"Validation status at generation: {validation['status']}. Clean raw tables: {validation['row_counts']['clean_csv_tables']}. Clean raw rows: {validation['row_counts']['clean_csv_rows']}.",
    ]
    (BASE / "reports/AIRLINE_INTAKE_RESEARCH_NOTES.md").write_text("\n".join(lines), encoding="utf-8")


def write_json(path, payload):
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def write_loader_script_v3():
    loader = r'''#!/usr/bin/env python3
"""1:1 raw CSV loader for the SkyHarbor synthetic package.

The loader intentionally lands every source field as text, adds only technical
lineage, and performs no business normalization before loading.
"""
import argparse
import csv
import hashlib
import json
import os
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path

SCHEMA_BY_FOLDER = {
    "enterprise_it": "raw_enterprise_it",
    "data_analytics": "raw_data_analytics",
    "cloud_hybrid": "raw_cloud_hybrid",
}

TECHNICAL_COLUMNS = [
    "_source_file",
    "_source_sheet",
    "_source_row_number",
    "_source_row_jsonb",
    "_load_run_id",
    "_loaded_at",
    "_row_hash",
    "_synthetic_data_flag",
]

def snake(name):
    return re.sub(r"_+", "_", re.sub(r"[^A-Za-z0-9]+", "_", str(name).replace("*", "")).strip("_").lower()) or "column"

def table_name(path):
    return re.sub(r"^\d+[a-z]?_", "", snake(path.stem))

def normalized_headers(headers):
    seen = {}
    out = []
    for idx, header in enumerate(headers, 1):
        base = snake(header or f"blank_header_{idx}")
        seen[base] = seen.get(base, 0) + 1
        out.append(base if seen[base] == 1 else f"{base}_{seen[base]}")
    return out

def row_hash(row, headers):
    payload = json.dumps({h: row.get(h, "") for h in headers}, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()

def discover(csv_root, include_messy=False):
    root = Path(csv_root)
    plan = []
    for folder, schema in SCHEMA_BY_FOLDER.items():
        for path in sorted((root / folder).glob("*.csv")):
            with path.open(newline="", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                rows = list(reader)
                headers = reader.fieldnames or []
            plan.append({"schema": schema, "table": table_name(path), "path": path, "headers": headers, "columns": normalized_headers(headers), "rows": rows})
    if include_messy:
        messy_root = root.parent / "csv_messy" if root.name == "csv" else Path("csv_messy")
        for path in sorted(messy_root.glob("*.csv")):
            if path.name in {"EXPECTED_MAPPING.json"}:
                continue
            with path.open(newline="", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                rows = list(reader)
                headers = reader.fieldnames or []
            plan.append({"schema": "raw_mapping_test", "table": table_name(path), "path": path, "headers": headers, "columns": normalized_headers(headers), "rows": rows})
    return plan

def ddl_ident(name):
    return '"' + name.replace('"', '""') + '"'

def load_plan(conn, plan, load_run_id):
    with conn.cursor() as cur:
        for item in plan:
            schema = item["schema"]
            table = item["table"]
            cur.execute(f"CREATE SCHEMA IF NOT EXISTS {ddl_ident(schema)}")
            cur.execute(f"""
                CREATE TABLE IF NOT EXISTS {ddl_ident(schema)}._column_map (
                    _load_run_id uuid,
                    _source_file text,
                    _source_sheet text,
                    ordinal integer,
                    original_header text,
                    snake_name text,
                    required_flag boolean
                )
            """)
            source_defs = ", ".join(f"{ddl_ident(col)} text" for col in item["columns"])
            lineage_defs = ", ".join([
                '"_source_file" text',
                '"_source_sheet" text',
                '"_source_row_number" bigint',
                '"_source_row_jsonb" jsonb',
                '"_load_run_id" uuid',
                '"_loaded_at" timestamptz',
                '"_row_hash" text',
                '"_synthetic_data_flag" boolean',
            ])
            cur.execute(f"CREATE TABLE IF NOT EXISTS {ddl_ident(schema)}.{ddl_ident(table)} ({source_defs}, {lineage_defs})")
            cur.execute(f"DELETE FROM {ddl_ident(schema)}.{ddl_ident(table)} WHERE _load_run_id = %s", (load_run_id,))
            cur.execute(f"DELETE FROM {ddl_ident(schema)}._column_map WHERE _load_run_id = %s AND _source_file = %s", (load_run_id, str(item["path"])))
            for ordinal, (original, normalized) in enumerate(zip(item["headers"], item["columns"]), 1):
                cur.execute(
                    f"INSERT INTO {ddl_ident(schema)}._column_map (_load_run_id, _source_file, _source_sheet, ordinal, original_header, snake_name, required_flag) VALUES (%s,%s,%s,%s,%s,%s,%s)",
                    (load_run_id, str(item["path"]), item["path"].stem, ordinal, original, normalized, "*" in original),
                )
            names = item["columns"] + TECHNICAL_COLUMNS
            placeholders = ", ".join(["%s"] * len(names))
            insert_sql = f"INSERT INTO {ddl_ident(schema)}.{ddl_ident(table)} ({', '.join(ddl_ident(n) for n in names)}) VALUES ({placeholders})"
            loaded_at = datetime.now(timezone.utc)
            for source_row_number, row in enumerate(item["rows"], 2):
                raw_json = {h: row.get(h, "") for h in item["headers"]}
                values = [row.get(h, "") for h in item["headers"]] + [
                    str(item["path"]),
                    item["path"].stem,
                    source_row_number,
                    json.dumps(raw_json, ensure_ascii=False),
                    load_run_id,
                    loaded_at,
                    row_hash(row, item["headers"]),
                    True,
                ]
                cur.execute(insert_sql, values)
            for idx_col in ["_load_run_id", "_source_file", "_source_sheet", "_source_row_number", "_row_hash"]:
                cur.execute(f"CREATE INDEX IF NOT EXISTS {ddl_ident(table + '_' + idx_col.strip('_') + '_idx')} ON {ddl_ident(schema)}.{ddl_ident(table)} ({ddl_ident(idx_col)})")
            for col in item["columns"]:
                if col.endswith("_id") or col.endswith("_ref") or "period" in col or "date" in col:
                    cur.execute(f"CREATE INDEX IF NOT EXISTS {ddl_ident(table + '_' + col + '_idx')} ON {ddl_ident(schema)}.{ddl_ident(table)} ({ddl_ident(col)})")
            cur.execute(f"CREATE OR REPLACE VIEW {ddl_ident(schema)}.{ddl_ident('current_' + table)} AS SELECT * FROM {ddl_ident(schema)}.{ddl_ident(table)} WHERE _loaded_at = (SELECT MAX(_loaded_at) FROM {ddl_ident(schema)}.{ddl_ident(table)})")
    conn.commit()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv-root", default="csv")
    ap.add_argument("--database-url", default=os.environ.get("DATABASE_URL"))
    ap.add_argument("--load-run-id", default=str(uuid.uuid4()))
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--include-messy", action="store_true")
    args = ap.parse_args()
    plan = discover(args.csv_root, include_messy=args.include_messy)
    total_rows = sum(len(item["rows"]) for item in plan)
    if args.dry_run:
        for item in plan:
            print(f"DRY RUN {item['schema']}.{item['table']}: {len(item['rows'])} rows from {item['path']} ({len(item['headers'])} source columns as text)")
        print(f"DRY RUN summary: {len(plan)} tables, {total_rows} rows, load_run_id={args.load_run_id}")
        return
    if not args.database_url:
        raise SystemExit("DATABASE_URL or --database-url is required unless --dry-run is used")
    import psycopg
    with psycopg.connect(args.database_url) as conn:
        load_plan(conn, plan, args.load_run_id)
    print(f"Loaded {len(plan)} raw tables and {total_rows} rows with load_run_id={args.load_run_id}")

if __name__ == "__main__":
    main()
'''
    (BASE / "scripts/load_workbooks_to_postgres.py").write_text(loader, encoding="utf-8")


def patch_serving_views():
    path = BASE / "scripts/create_serving_views.sql"
    with path.open("a", encoding="utf-8") as f:
        f.write("""

-- V3 extension. Row grain: vendor contract. Measures: annual and committed value.
CREATE OR REPLACE VIEW serving_skyharbor.vendor_contract_exposure AS
SELECT vendor_id, vendor_name, category, renewal_decision_state, auto_renew, benchmarking_clause,
       SUM(annual_value)::numeric AS annual_value,
       SUM(total_committed_value)::numeric AS total_committed_value,
       MIN(end_date) AS nearest_end_date
FROM raw_enterprise_it."vendors_contracts"
GROUP BY vendor_id, vendor_name, category, renewal_decision_state, auto_renew, benchmarking_clause;

-- V3 extension. Row grain: risk domain/control status. Measures: count and never-tested controls.
CREATE OR REPLACE VIEW serving_skyharbor.risk_control_coverage AS
SELECT risk_domain, control_status, residual_severity,
       COUNT(*) AS risk_count,
       SUM(CASE WHEN control_last_tested_date IS NULL THEN 1 ELSE 0 END) AS never_tested_controls
FROM raw_enterprise_it."risks_controls"
GROUP BY risk_domain, control_status, residual_severity;

-- V3 extension. Row grain: KPI/quarter. Measures: current, prior, target.
CREATE OR REPLACE VIEW serving_skyharbor.kpi_trend_by_quarter AS
SELECT kpi_id, kpi_name, business_function, reporting_period, unit, direction,
       current_value, prior_value, target_value, confidence
FROM raw_enterprise_it."kpis_outcomes";

-- V3 extension. Row grain: fiscal year/scenario/portfolio. Measures: budget, forecast, actual.
CREATE OR REPLACE VIEW serving_skyharbor.budget_year_over_year AS
SELECT fiscal_year, scenario, it_portfolio,
       SUM(budget_amount)::numeric AS budget_amount,
       SUM(forecast_amount)::numeric AS forecast_amount,
       SUM(actual_amount)::numeric AS actual_amount
FROM raw_enterprise_it."it_budget_allocations"
GROUP BY fiscal_year, scenario, it_portfolio;
""")


def write_v2_validator(data):
    expected = {f"csv/{kind}/{SHEET_CSV[kind][sheet]}": len(rows) for kind, sheets in data.items() for sheet, rows in sheets.items()}
    script = f'''#!/usr/bin/env python3
import csv, json, re, zipfile
from collections import Counter
from pathlib import Path
from openpyxl import load_workbook

EXPECTED = {json.dumps(expected, indent=2)}
FY2027_TOTAL = {FY2027_TOTAL}
FY2026_TOTAL = {FY2026_TOTAL}
CONTRACT_COVERAGE_TARGET = {CONTRACT_COVERAGE_TARGET}

def rows(path):
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def num(v):
    return int(float(str(v or 0).replace(",", "").replace("$", "")))

def mention_report(statements):
    fields = {{
        "initiative": "initiative_mentioned",
        "application": "application_mentioned",
        "platform": "platform_mentioned",
        "vendor": "vendor_mentioned",
        "kpi": "kpi_mentioned",
    }}
    counts = [sum(1 for col in fields.values() if r.get(col)) for r in statements]
    return {{
        "rates": {{field: sum(1 for r in statements if r.get(col)) / len(statements) for field, col in fields.items()}},
        "no_mentions": sum(1 for c in counts if c == 0) / len(statements),
        "zero_or_one": sum(1 for c in counts if c <= 1) / len(statements),
        "three_plus": sum(1 for c in counts if c >= 3) / len(statements),
        "initiative_counts": Counter(r.get("initiative_mentioned", "") for r in statements if r.get("initiative_mentioned")),
    }}

def main():
    root = Path(".")
    issues = []
    for rel, expected in EXPECTED.items():
        actual = len(rows(root / rel))
        if actual != expected:
            issues.append(f"{{rel}} rows {{actual}} != {{expected}}")
    budget = rows(root / "csv/enterprise_it/5_it_budget_allocations.csv")
    fy2027 = sum(num(r["Budget Amount *"]) for r in budget if r["Fiscal Year *"] == "2027")
    fy2026 = sum(num(r["Budget Amount *"]) for r in budget if r["Fiscal Year *"] == "2026")
    if fy2027 != FY2027_TOTAL: issues.append(f"FY2027 budget {{fy2027}} != {{FY2027_TOTAL}}")
    if fy2026 != FY2026_TOTAL: issues.append(f"FY2026 budget {{fy2026}} != {{FY2026_TOTAL}}")
    fy2027_rows = [r for r in budget if r["Fiscal Year *"] == "2027"]
    contract_backed = sum(num(r.get("contract_backed_amount")) for r in fy2027_rows)
    internal_noncontracted = sum(num(r.get("internal_noncontracted_amount")) for r in fy2027_rows)
    vc = Counter()
    for r in rows(root / "csv/enterprise_it/11_vendors_contracts.csv"):
        vc[r["vendor_name"]] += num(r["annual_value"])
    contract_total = sum(vc.values())
    coverage = contract_total / FY2027_TOTAL
    if not (0.60 <= coverage <= 0.65): issues.append(f"contract coverage {{coverage:.2%}} outside 60-65%")
    if contract_total != contract_backed: issues.append("contract total does not tie to contract_backed_amount")
    if contract_backed + internal_noncontracted != FY2027_TOTAL: issues.append("contract-backed plus internal/noncontracted does not equal FY2027 budget")
    risks = rows(root / "csv/enterprise_it/12_risks_controls.csv")
    blank_ratio = sum(1 for r in risks if not r["control_last_tested_date"]) / len(risks)
    if not (0.20 <= blank_ratio <= 0.30): issues.append("risk blank control test ratio outside range")
    for r in risks:
        if not r["control_last_tested_date"] and (r["control_test_result"] != "never_tested" or r.get("control_test_evidence_ref")):
            issues.append(f"never-tested contradiction {{r.get('risk_id')}}")
    statements = rows(root / "csv/enterprise_it/8b_interview_statements.csv")
    by_interview = Counter(r["interview_id"] for r in statements)
    if min(by_interview.values()) < 20: issues.append("an interview has fewer than 20 statements")
    mr = mention_report(statements)
    bounds = {{"initiative": (0.38, 0.47), "application": (0.23, 0.32), "platform": (0.13, 0.22), "vendor": (0.18, 0.27), "kpi": (0.13, 0.22)}}
    for field, (lo, hi) in bounds.items():
        if not (lo <= mr["rates"][field] <= hi): issues.append(f"{{field}} mention rate outside target")
    if not (0.18 <= mr["no_mentions"] <= 0.27): issues.append("no structured mention rate outside target")
    if mr["zero_or_one"] < 0.70: issues.append("zero-or-one structured entity rate below 70%")
    if mr["three_plus"] > 0.10: issues.append("three-plus structured entity rate above 10%")
    projects = rows(root / "csv/enterprise_it/6_projects_investments.csv")
    high_mentions = [n for n, c in mr["initiative_counts"].most_common(10)]
    under = [p for p in projects if p["Initiative / Project Name *"] in high_mentions and (p["Status *"] in {{"On hold", "Awaiting decision", "At risk"}} or p["Funding Status"] in {{"Unfunded", "Partially funded", "Approved with constraint"}})]
    quiet_funded = [p for p in projects if p.get("v3_conviction_funding_note") == "well_funded_low_conviction" and mr["initiative_counts"].get(p["Initiative / Project Name *"], 0) <= 1]
    if len(under) < 3: issues.append("fewer than 3 high-conviction underfunded initiatives")
    if len(quiet_funded) < 3: issues.append("fewer than 3 well-funded low-conviction initiatives")
    hints = json.loads((root / "metadata/relationship_hints.json").read_text())
    if len(hints) < 40: issues.append("relationship hints below 40")
    mapping = json.loads((root / "csv_messy/EXPECTED_MAPPING.json").read_text())
    if not any(v.get("value_mappings") for v in mapping.get("files", {{}}).values()): issues.append("messy value mappings missing")
    manifest = json.loads((root / "metadata/dataset_manifest.json").read_text())
    if not manifest.get("client_signoff_required_before_load"): issues.append("client sign-off gate missing from manifest")
    for wb_path in ["workbooks/SkyHarbor_Global_Enterprise_IT_Current_State_SYNTHETIC_v3.xlsx","workbooks/SkyHarbor_Global_Data_Analytics_Current_State_SYNTHETIC_v3.xlsx","workbooks/SkyHarbor_Global_Cloud_Hybrid_Current_State_SYNTHETIC_v3.xlsx"]:
        wb = load_workbook(root / wb_path, read_only=True, data_only=False)
        if "SYNTHETIC_SCENARIO" not in wb.sheetnames[:5]: issues.append(f"missing scenario sheet in {{wb_path}}")
        if "INTAKE_GUIDE" not in wb.sheetnames: issues.append(f"missing INTAKE_GUIDE in {{wb_path}}")
        wb.close()
    status = "pass" if not issues else "fail"
    print(json.dumps({{"status": status, "issues": issues, "checked_csv_files": len(EXPECTED), "clean_csv_rows": sum(EXPECTED.values()), "relationship_hints": len(hints), "contract_coverage": round(coverage, 4), "minimum_interview_statements": min(by_interview.values())}}, indent=2))
    raise SystemExit(0 if not issues else 1)

if __name__ == "__main__":
    main()
'''
    (BASE / "scripts/validate_package.py").write_text(script, encoding="utf-8")
    replay = (BASE / "validation/VALIDATION_REPLAY.md").read_text(encoding="utf-8")
    replay += "\n\n## v3 Checks\n\nThe replay validator checks 28 clean CSV mirrors, FY2026/FY2027 budget separation, 60-65% contract-backed spend coverage, control/date consistency, sparse mention distributions, funding/conviction inversion cohorts, messy value mappings, workbook INTAKE_GUIDE sheets, and the client sign-off gate.\n"
    (BASE / "validation/VALIDATION_REPLAY.md").write_text(replay, encoding="utf-8")


def package_zip():
    normalize_xlsx_archives()
    if LOCAL_ZIP.exists():
        LOCAL_ZIP.unlink()
    with zipfile.ZipFile(LOCAL_ZIP, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for path in sorted(BASE.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(BASE)
            if "__pycache__" in rel.parts or path.suffix == ".pyc":
                continue
            if "_v1.xlsx" in path.name or "_v2.xlsx" in path.name or path.name == "V2_DEPTH_CROSSWALK.md":
                continue
            info = zipfile.ZipInfo(str(rel), date_time=(2027, 6, 30, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            z.writestr(info, path.read_bytes())
    shutil.copy2(LOCAL_ZIP, DOWNLOADS_ZIP)
    return hashlib.sha256(LOCAL_ZIP.read_bytes()).hexdigest()


def normalize_xlsx_archives():
    for workbook in WORKBOOKS.values():
        if not workbook.exists():
            continue
        tmp = workbook.with_suffix(".normalized.xlsx")
        with zipfile.ZipFile(workbook, "r") as src, zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED) as dst:
            for name in sorted(src.namelist()):
                info = zipfile.ZipInfo(name, date_time=(2027, 6, 30, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o644 << 16
                payload = src.read(name)
                if name == "docProps/core.xml":
                    payload = re.sub(
                        rb"<dcterms:created[^>]*>.*?</dcterms:created>",
                        b'<dcterms:created xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="dcterms:W3CDTF">2027-06-30T00:00:00Z</dcterms:created>',
                        payload,
                    )
                    payload = re.sub(
                        rb"<dcterms:modified[^>]*>.*?</dcterms:modified>",
                        b'<dcterms:modified xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="dcterms:W3CDTF">2027-06-30T00:00:00Z</dcterms:modified>',
                        payload,
                    )
                dst.writestr(info, payload)
        tmp.replace(workbook)


def main():
    headers, data = load_all()
    maps = add_ids_and_refs(headers, data)
    add_practical_technical_depth(headers, data)
    mark_project_inversions(headers, data)
    add_contracts(headers, data, maps)
    add_risks(headers, data, maps)
    add_temporal_depth(headers, data, maps)
    add_interview_statements(headers, data, maps)
    write_all_csv(headers, data)
    update_relationship_hints(maps)
    create_messy_variant(data, maps)
    update_metadata(headers, data)
    update_workbooks(headers, data)
    validation = validate_v2(data)
    write_loader_script_v3()
    patch_serving_views()
    write_v2_validator(data)
    write_reports(data, validation)
    sha = package_zip()
    print(json.dumps({"status": validation["status"], "zip": str(LOCAL_ZIP), "downloads_zip": str(DOWNLOADS_ZIP), "sha256": sha, "issues": validation["issues"]}, indent=2))


if __name__ == "__main__":
    main()

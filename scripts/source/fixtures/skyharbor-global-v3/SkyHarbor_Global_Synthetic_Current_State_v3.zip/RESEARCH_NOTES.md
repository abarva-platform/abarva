# Research Notes

Research was used only to calibrate realistic scale, terminology, and operating patterns. No company-specific data model, organization, confidential fact, executive name, or exact wording was copied into the synthetic SkyHarbor records.

## IATA - Global Outlook for Air Transport June 2025
- Publication year: 2025
- Calibration use: Calibrated airline industry demand, load-factor, cargo, and operating-scale context.
- No company-specific data copied directly: confirmed.
- URL: https://www.iata.org/en/publications/economics/reports/global-outlook-for-air-transport-june-2025/

## IATA - Industry Statistics fact sheet
- Publication year: 2026
- Calibration use: Calibrated passenger load factor and global aviation operating benchmark ranges.
- No company-specific data copied directly: confirmed.
- URL: https://www.iata.org/en/iata-repository/pressroom/fact-sheets/industry-statistics/

## American Airlines Group - 2025 Annual Report on Form 10-K
- Publication year: 2026
- Calibration use: Calibrated global network airline scale: revenue, aircraft, regional operations, hubs, and workforce magnitudes.
- No company-specific data copied directly: confirmed.
- URL: https://www.sec.gov/Archives/edgar/data/6201/000119312526187124/d151029dars.pdf

## Delta Air Lines - 2025 Form 10-K and investor profile
- Publication year: 2026
- Calibration use: Calibrated scale of large passenger networks, employee count, peak-day flights, destinations, and technology/business complexity.
- No company-specific data copied directly: confirmed.
- URL: https://s2.q4cdn.com/181345880/files/doc_financials/2025/q4/DAL-12-31-2025-10K-2-10-26-Filed.pdf

## United Airlines Holdings - 2025 Annual Report on Form 10-K
- Publication year: 2026
- Calibration use: Calibrated large hub-and-spoke network size, fleet, route, and operating-reliability context.
- No company-specific data copied directly: confirmed.
- URL: https://www.sec.gov/Archives/edgar/data/319687/000010051726000023/ual-20251231.htm

## Microsoft - Azure Cloud Adoption Framework: Azure landing zones
- Publication year: 2026
- Calibration use: Calibrated landing-zone, subscription, governance, identity, networking, and operations terminology.
- No company-specific data copied directly: confirmed.
- URL: https://learn.microsoft.com/en-us/azure/cloud-adoption-framework/ready/landing-zone/

## AWS - AWS Well-Architected Framework
- Publication year: 2026
- Calibration use: Calibrated cloud operations, reliability, security, cost optimization, and sustainability maturity language.
- No company-specific data copied directly: confirmed.
- URL: https://aws.amazon.com/architecture/well-architected/

## ServiceNow - Common Service Data Model documentation
- Publication year: 2026
- Calibration use: Calibrated CMDB/APM, service-modeling, and service-reporting terminology.
- No company-specific data copied directly: confirmed.
- URL: https://www.servicenow.com/docs/r/servicenow-platform/common-service-data-model-csdm/csdm-landing-page.html

## Microsoft - Microsoft 365 Copilot usage report
- Publication year: 2026
- Calibration use: Calibrated AI adoption report fields: enabled users, active users, activity, exports, and admin reporting.
- No company-specific data copied directly: confirmed.
- URL: https://learn.microsoft.com/en-us/microsoft-365/admin/activity-reports/microsoft-365-copilot-usage

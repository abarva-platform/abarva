# Requirements Crosswalk

This crosswalk is an evidence ledger for the generated SkyHarbor Global synthetic current-state package. It is intentionally package-local and does not claim Azure/PostgreSQL load, canonical promotion, deployment, or signed-in product proof.

## Scope Boundary

- Layer: source-like synthetic current-state workbooks, CSV mirrors, metadata, scripts, and reports.
- Explicit non-claims: no production activation, no canonical publication, no baseline activation, no data-plane load, no live product proof.
- Synthetic status: all enterprise data, people, records, interviews, operating conditions, projects, and financial details are fictional.

## Crosswalk

| Requirement Area | Status | Evidence |
| --- | --- | --- |
| Use latest recommended workbooks only | PASS | Copied the three templates from 01_LATEST_RECOMMENDED and did not populate earlier workbook iterations. Workbooks created: 3. |
| Preserve worksheet names, headers, formatting, validations, and formulas | PASS | Workbook integrity check confirmed no original worksheet was removed, required headers remained unchanged, validation counts were unchanged, and AI active-rate formulas were preserved/extended. |
| Create deterministic scenario model first | PASS | synthetic_master_data.json created with seed 20260802; all workbook rows generated from the same scenario model. |
| Fictional $50B-class global airline scenario | PASS | Scenario uses SkyHarbor Global Airlines Group with $52.8B revenue, 109,500 employees, 1,020 aircraft, 5,150 daily departures, 198M passengers, 335 destinations, 63 countries, and 8 hubs. |
| Public research notes | PASS | RESEARCH_NOTES.md records authoritative calibration sources and confirms no company-specific data was copied directly. |
| Business functions | PASS | 49 functions/subfunctions generated across commercial/customer, airline operations, corporate, and technology layers. |
| IT organization and portfolio model | PASS | 22 CIO/SVP/VP portfolios/subportfolios generated with fictional leaders, mandates, services, team sizes, budgets, priorities, projects, and constraints. |
| IT budget scenario | PASS | 1800 budget rows generated. Enterprise total reconciles exactly to $2,350,000,000; portfolio, OpEx/CapEx, and Run/Grow/Transform validations passed. |
| Application estate | PASS | 720 airline-specific applications/platforms generated with business function, owner, portfolio, hosting, product, criticality, lifecycle, planned action, and CMDB/APM availability. |
| Data and Analytics estate | PASS | Generated platform, function-platform, source-to-consumption, volumetric, maturity, and roadmap rows using the same master functions, apps, projects, platforms, and leaders. |
| Cloud and hybrid estate | PASS | Generated strategy, private infrastructure, public cloud, workload distribution, platform capability, economics, maturity, and roadmap rows. |
| Project and investment portfolio | PASS | 150 initiatives generated with status mix, budget, OpEx/CapEx, forecast, actuals, dependencies, risks, and AI component fields. |
| KPI and outcome model | PASS | 120 KPIs generated across operations, customer/commercial, corporate, and technology outcomes. |
| Executive and functional interviews | PASS | 48 completed interviews generated with distinctive role-specific narratives; duplicate narrative validation count: 0. |
| AI tools, agents, and adoption | PASS | 240 adoption rows generated with active users <= assigned seats <= purchased seats, active-rate formulas, cost, activity, value evidence, governance status, and risk fields. |
| Operational feed register | PASS | 19 feed rows generated across CMDB/APM, ITSM, ERP, cloud, observability, BI, AI, and internal telemetry, with mixed access states. |
| Realistic imperfection | PASS | Semantic imperfections are represented through estimated, disputed, partial, unknown, and pending-validation fields without malformed rows or structural corruption. |
| Instruction and scenario documentation | PASS | SYNTHETIC_SCENARIO, HOW_TO_USE, and VALIDATION_SUMMARY added to the beginning of each completed workbook; START_HERE updated with synthetic and non-mandatory-template caveats. |
| Cross-workbook consistency | PASS | Required orphan-reference count is 0; relationship_hints.json and validation reports document the checks. |
| Data-type rules | PASS | Workbook spot checks found typed dates/numbers, no error markers, and preserved/extended formulas for AI active rate. |
| PostgreSQL-ready outputs | PASS | 25 UTF-8 CSV mirrors created with dataset manifest, column dictionary, relationship hints, and load order. |
| Generic PostgreSQL loader | PASS | scripts/load_workbooks_to_postgres.py supports dry-run, 1:1 CSV loads into raw schemas, source metadata fields, snake_case names, and basic indexes. |
| Simple reconciled serving views | PASS | scripts/create_serving_views.sql includes compact exact-reporting views for budget, portfolio, project, apps, workload, cloud, data volumetrics, KPIs, AI, and service health. |
| Sample-question suite | PASS | reports/SAMPLE_QUESTIONS.md includes 120 questions across Intelligence, Data and Analytics, Cloud and Hybrid, Moves, Source, and Tower. |
| Current-state synthesis | PASS | reports/CURRENT_STATE_SYNTHESIS.md includes executive summary, current-state observations, risks, implications, gaps, validation questions, and six Mermaid diagrams. |
| Validation report | PASS | validation_report.json/html/md created; final status is pass with no unexplained failures. |
| Final output package | PASS | SkyHarbor_Global_Synthetic_Current_State_v1.zip created locally and copied to /Users/anand/Downloads. |

## Loadable Row Counts

| Workbook/Sheet | Rows |
| --- | ---: |
| cloud_hybrid/1_Cloud_Strategy_Placement | 16 |
| cloud_hybrid/2_Data_Center_Private_Cloud | 10 |
| cloud_hybrid/3_Public_Cloud_Estates | 12 |
| cloud_hybrid/4_Workload_Distribution | 180 |
| cloud_hybrid/5_Cloud_Platform_Capabilities | 80 |
| cloud_hybrid/6_Cloud_Operations_Economics | 120 |
| cloud_hybrid/7_Cloud_Findings_Maturity | 100 |
| cloud_hybrid/8_Cloud_Initiatives_Roadmap | 42 |
| data_analytics/1_Function_Analytics_Profile | 42 |
| data_analytics/2_Platform_Tech_Stack | 45 |
| data_analytics/3_Function_Platform_Map | 240 |
| data_analytics/4_Source_to_Consumption | 72 |
| data_analytics/5_Function_Volumetrics | 84 |
| data_analytics/6_Findings_Maturity | 336 |
| data_analytics/7_Initiatives_Roadmap | 55 |
| enterprise_it/10_AI_Adoption_Usage | 240 |
| enterprise_it/1_Enterprise_Context | 1 |
| enterprise_it/2_Business_Functions | 49 |
| enterprise_it/3_IT_Portfolios_Organization | 22 |
| enterprise_it/4_Applications_Portfolio | 720 |
| enterprise_it/5_IT_Budget_Allocations | 1800 |
| enterprise_it/6_Projects_Investments | 150 |
| enterprise_it/7_KPIs_Outcomes | 120 |
| enterprise_it/8_CXO_Function_Interviews | 48 |
| enterprise_it/9_Operational_Usage_Feeds | 19 |

## Financial Reconciliation

- Enterprise IT budget: $2,350,000,000
- Portfolio totals: {"Application Managed Services": 258500000, "Architecture and Integration": 94000000, "Corporate Applications": 376000000, "Cybersecurity": 235000000, "Data, Analytics and AI": 329000000, "Digital and Customer Technology": 282000000, "Infrastructure and Cloud": 517000000, "Network and Workplace": 188000000, "Technology Strategy, Finance and PMO": 70500000}
- Accounting totals: {"CapEx": 611000000, "OpEx": 1739000000}
- Investment-purpose totals: {"Grow": 399500000, "Run": 1363000000, "Transform": 587500000}

## Remaining Human Gates

- Load to PostgreSQL using the included loader only after an operator provides an authorized database target.
- Any canonical transformation, publication, baseline activation, product binding, ACA job, deployment, or signed-in proof remains a separate human-authorized lane.
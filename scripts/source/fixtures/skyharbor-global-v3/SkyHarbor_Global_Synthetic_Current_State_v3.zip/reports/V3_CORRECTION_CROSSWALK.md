# V3 Correction Crosswalk

This report records the v3 correction additions and preserves the non-claim boundary: no PostgreSQL write, no canonical promotion, no deployment, no signed-in proof.

| Addition | Status | Evidence |
| --- | --- | --- |
| Long-form interview statements | PASS | 1314 rows in enterprise_it/8b_Interview_Statements. |
| Stable IDs and refs | PASS | Entity sheets and reference-bearing rows include stable IDs/refs while retaining human-readable names. |
| Vendor contracts | PASS | 119 contract rows; annual value $1,480,500,000, 63.0% of FY2027 IT budget, tied to contract-backed spend. |
| Risk/control register | PASS | 80 rows; never-tested controls remain between 20% and 30%. |
| Interview depth | PASS | Minimum 20 statements per interview; IT interviews are allowed deeper coverage. |
| Practical application/platform depth | PASS | Application and platform sheets include version, hosting/deployment, capacity, usage, storage, integration, support, upgrade posture, and evidence-source fields. |
| Plausibility gates | PASS | Mention sparsity, funding/conviction inversions, contract coverage, control/date consistency, and messy value variance are validated. |
| Client sign-off gate | PASS | Manifest and INTAKE_GUIDE state that raw loading requires client sign-off and only technical readability/header issues block the load. |
| Temporal depth | PASS | KPI rows 960, workload rows 720, cloud economics rows 240, AI adoption rows 480, and FY2026 prior-year budget rows added. |
| Relationship hints | PASS | 42 relationships with cardinality and join confidence. |
| Messy variant | PASS | csv_messy includes degraded extracts and EXPECTED_MAPPING.json answer key. |
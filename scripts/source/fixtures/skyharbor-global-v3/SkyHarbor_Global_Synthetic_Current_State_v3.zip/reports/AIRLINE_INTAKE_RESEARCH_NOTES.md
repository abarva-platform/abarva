# Airline Intake Research Notes

This note uses public airline and aviation benchmarks to shape a fictional, synthetic $50B-class current-state package. It does not assert facts about any real client.

## Public benchmark signals used

- American Airlines reported full-year 2025 revenue of $54.6B, which supports the package scale as a realistic large-network-airline range. Source: https://news.aa.com/news/news-details/2026/American-Airlines-reports-fourth-quarter-and-full-year-2025-financial-results-CORP-FI-01/default.aspx
- United describes more than 100,000 employees, 175M customers, 370+ destinations, seven domestic hubs, and 5,000+ daily departures, which supports the enterprise scale, hub model, and function breadth. Source: https://ir.united.com/
- Delta's 2024 10-K describes operating revenue growth and large-airline financial scale, supporting the revenue and planning-horizon framing. Source: https://www.sec.gov/Archives/edgar/data/27904/000002790425000004/dal-20241231.htm
- SITA 2025 airline IT insights highlight AI in operations control and data integration/consistency as a major barrier, supporting the AI, data-lineage, and operations-control intake topics. Source: https://www.sita.aero/resources/surveys-reports/air-transport-it-insights-2025/airlines/
- IATA digital aircraft operations describes flight operations, air traffic management, ground operations, maintenance, supply chain/logistics, and asset transfer as digital-operations domains, supporting airline-specific workbook coverage. Source: https://www.iata.org/en/programs/ops-infra/techops/digital-aircraft-operations/

## Practical extraction principle

The workbook asks for fields that client teams can usually extract from existing documents or systems: CMDB/APM, application owner lists, architecture diagrams, budget and project portfolio exports, cloud billing/tag reports, BI/data catalog reports, vendor registers, risk/control evidence, DR test logs, incident/problem reports, steering committee minutes, and interview notes.

## Load sign-off boundary

Before loading, the client sponsor or delegate must sign off the file list, row grain, source period, known gaps, and synthetic/current-state caveats. Raw loading remains source-faithful; business mapping, normalization, and plausibility findings happen after landing.

Validation status at generation: pass. Clean raw tables: 28. Clean raw rows: 9656.
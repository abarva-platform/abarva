# Sample Question Suite

## Intelligence

1. What are the CIO's top priorities, and does the budget support them? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
2. Which business functions are most dependent on legacy platforms? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
3. Which investments appear poorly aligned to enterprise priorities? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
4. Where do executive views and measured evidence disagree? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
5. What are the CIO's top priorities, and does the budget support them? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
6. Which business functions are most dependent on legacy platforms? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
7. Which investments appear poorly aligned to enterprise priorities? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
8. Where do executive views and measured evidence disagree? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
9. What are the CIO's top priorities, and does the budget support them? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
10. Which business functions are most dependent on legacy platforms? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
11. Which investments appear poorly aligned to enterprise priorities? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
12. Where do executive views and measured evidence disagree? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
13. What are the CIO's top priorities, and does the budget support them? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
14. Which business functions are most dependent on legacy platforms? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
15. Which investments appear poorly aligned to enterprise priorities? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
16. Where do executive views and measured evidence disagree? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
17. What are the CIO's top priorities, and does the budget support them? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
18. Which business functions are most dependent on legacy platforms? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
19. Which investments appear poorly aligned to enterprise priorities? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
20. Where do executive views and measured evidence disagree? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.

## Data and Analytics

1. How is Finance served from source systems through reports? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
2. Which functions depend on the Teradata estate? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
3. Where are ETL scale and reliability most problematic? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
4. Which marts overlap or have unclear authority? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
5. How is Finance served from source systems through reports? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
6. Which functions depend on the Teradata estate? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
7. Where are ETL scale and reliability most problematic? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
8. Which marts overlap or have unclear authority? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
9. How is Finance served from source systems through reports? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
10. Which functions depend on the Teradata estate? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
11. Where are ETL scale and reliability most problematic? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
12. Which marts overlap or have unclear authority? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
13. How is Finance served from source systems through reports? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
14. Which functions depend on the Teradata estate? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
15. Where are ETL scale and reliability most problematic? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
16. Which marts overlap or have unclear authority? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
17. How is Finance served from source systems through reports? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
18. Which functions depend on the Teradata estate? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
19. Where are ETL scale and reliability most problematic? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
20. Which marts overlap or have unclear authority? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.

## Cloud and Hybrid

1. What percentage of Tier 1 applications runs in private versus public cloud? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
2. Which data-center exits affect critical operational platforms? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
3. Which cloud estates lack mature policy, tagging, or resilience? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
4. Where is public-cloud spend growing without proportional workload adoption? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
5. What percentage of Tier 1 applications runs in private versus public cloud? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
6. Which data-center exits affect critical operational platforms? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
7. Which cloud estates lack mature policy, tagging, or resilience? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
8. Where is public-cloud spend growing without proportional workload adoption? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
9. What percentage of Tier 1 applications runs in private versus public cloud? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
10. Which data-center exits affect critical operational platforms? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
11. Which cloud estates lack mature policy, tagging, or resilience? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
12. Where is public-cloud spend growing without proportional workload adoption? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
13. What percentage of Tier 1 applications runs in private versus public cloud? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
14. Which data-center exits affect critical operational platforms? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
15. Which cloud estates lack mature policy, tagging, or resilience? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
16. Where is public-cloud spend growing without proportional workload adoption? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
17. What percentage of Tier 1 applications runs in private versus public cloud? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
18. Which data-center exits affect critical operational platforms? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
19. Which cloud estates lack mature policy, tagging, or resilience? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
20. Where is public-cloud spend growing without proportional workload adoption? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.

## Moves

1. Which transformation moves should be considered first? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
2. Which dependencies must be resolved before an EDW modernization? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
3. What would be required to modernize irregular-operations decision support? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
4. Which initiative should be reframed or consolidated? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
5. Which transformation moves should be considered first? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
6. Which dependencies must be resolved before an EDW modernization? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
7. What would be required to modernize irregular-operations decision support? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
8. Which initiative should be reframed or consolidated? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
9. Which transformation moves should be considered first? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
10. Which dependencies must be resolved before an EDW modernization? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
11. What would be required to modernize irregular-operations decision support? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
12. Which initiative should be reframed or consolidated? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
13. Which transformation moves should be considered first? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
14. Which dependencies must be resolved before an EDW modernization? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
15. What would be required to modernize irregular-operations decision support? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
16. Which initiative should be reframed or consolidated? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
17. Which transformation moves should be considered first? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
18. Which dependencies must be resolved before an EDW modernization? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
19. What would be required to modernize irregular-operations decision support? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
20. Which initiative should be reframed or consolidated? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.

## Source

1. Which managed-service contracts should be evaluated? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
2. Which application towers are candidates for sourcing? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
3. What data would be required for a cloud or application-services sourcing event? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
4. Which vendor concentration risks should influence a sourcing strategy? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
5. Which managed-service contracts should be evaluated? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
6. Which application towers are candidates for sourcing? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
7. What data would be required for a cloud or application-services sourcing event? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
8. Which vendor concentration risks should influence a sourcing strategy? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
9. Which managed-service contracts should be evaluated? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
10. Which application towers are candidates for sourcing? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
11. What data would be required for a cloud or application-services sourcing event? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
12. Which vendor concentration risks should influence a sourcing strategy? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
13. Which managed-service contracts should be evaluated? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
14. Which application towers are candidates for sourcing? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
15. What data would be required for a cloud or application-services sourcing event? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
16. Which vendor concentration risks should influence a sourcing strategy? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
17. Which managed-service contracts should be evaluated? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
18. Which application towers are candidates for sourcing? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
19. What data would be required for a cloud or application-services sourcing event? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
20. Which vendor concentration risks should influence a sourcing strategy? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.

## Tower

1. What is IT spend by portfolio? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
2. What is OpEx versus CapEx? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
3. What is run versus change? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
4. What is application count by lifecycle and hosting? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
5. What is AI active rate by function? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
6. What is cloud spend by provider? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
7. What is IT spend by portfolio? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
8. What is OpEx versus CapEx? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
9. What is run versus change? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
10. What is application count by lifecycle and hosting? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
11. What is AI active rate by function? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
12. What is cloud spend by provider? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
13. What is IT spend by portfolio? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
14. What is OpEx versus CapEx? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
15. What is run versus change? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
16. What is application count by lifecycle and hosting? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
17. What is AI active rate by function? Use the SkyHarbor synthetic records for Q1 evidence and cite source sheets.
18. What is cloud spend by provider? Use the SkyHarbor synthetic records for Q2 evidence and cite source sheets.
19. What is IT spend by portfolio? Use the SkyHarbor synthetic records for Q3 evidence and cite source sheets.
20. What is OpEx versus CapEx? Use the SkyHarbor synthetic records for Q4 evidence and cite source sheets.
